% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 1, Exercise 1
% Author: Gabriele Nuccio

clc
clear
close all

applyDefaultSettings();
format long g;

%% 1.1
% Coordinates of five lagrangian points

% 3D Earth-Moon Circular Restricted Three Body Problem
% Data
mu = 0.012150;

% Circumferences
r1 = @(x,y) sqrt((x+mu).^2 + y.^2);
r2 = @(x,y) sqrt((x+mu-1).^2 + y.^2);

% Potential and derivative
U = @(x,y) 1/2 * (x.^2 + y.^2) + (1-mu)/r1(x,y) + mu/r2(x,y) + 1/2 * mu * (1-mu);
% Define the derivatives wrt x and y 
dUdx = @(x, y) x - (1-mu)*(x+mu)./((x+mu).^2 + y.^2).^(3/2) - mu*(x-(1-mu))./((x-(1-mu)).^2 + y.^2).^(3/2);
dUdy = @(x, y) y - (1-mu)*y./((x+mu).^2 + y.^2).^(3/2) - mu*y./((x-(1-mu)).^2 + y.^2).^(3/2);

% Compute the Lagrangian Points
triangularPoints = lagrangianPoints('triangular', dUdx, dUdy);
collinearPoints = lagrangianPoints('collinear', dUdx, dUdy);

% Improved Plot
figure('Units', 'normalized', 'Position', [0.2, 0.2, 0.6, 0.45]);
hold on
grid on
axis([-1.5 2.5 -1.5 1.5])

% Update collinear points colors
plot(collinearPoints(1), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'DisplayName','Colinear Points');
plot(collinearPoints(2), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'HandleVisibility','off');
plot(collinearPoints(3), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'HandleVisibility','off');

% Update triangular points colors
plot(triangularPoints(1,1), triangularPoints(1,2), 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.85, 0.33, 0.1],'MarkerSize', 10, 'DisplayName','Triangular Points');
plot(triangularPoints(2,1), triangularPoints(2,2), 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.85, 0.33, 0.1],'MarkerSize', 10, 'HandleVisibility','off');

% Earth and Moon
plot(-mu, 0, 'o','MarkerEdgeColor','k', 'MarkerFaceColor', [0, 0, 1],'MarkerSize', 15,'HandleVisibility','off');
plot(1-mu, 0, 'o','MarkerFaceColor', [0.9, 0.9, 0.9], 'MarkerEdgeColor', 'k', 'MarkerSize', 12,'HandleVisibility','off');

% Plot circumferences of r = 1 and centered in P1 (Earth) and P2 (Moon)
theta = linspace(0, 2*pi, 100);  r = 1;
xEarth = -mu + r * cos(theta);  yEarth = r * sin(theta); 
xMoon = (1 - mu) + r * cos(theta);  yMoon = r * sin(theta); 
plot(xEarth, yEarth, '--', 'Color', [0.3 0.3 0.3], 'LineWidth', 1, 'HandleVisibility', 'off');
plot(xMoon, yMoon, '--', 'Color', [0.3 0.3 0.3], 'LineWidth', 1, 'HandleVisibility', 'off');

% Plot lines of dUdx
xvec = linspace(-1.1, 2.1, 1000);
dUdx = xvec - (1-mu)*(xvec+mu)./abs(xvec+mu).^3 - mu*(xvec+mu-1)./abs(xvec+mu-1).^3;
dUdx(dUdx > 15 | dUdx < -15) = NaN; % Avoid vertical lines where the function is discontinuous
plot(xvec, dUdx, '--', 'Color', [0.5 0.5 0.5], 'LineWidth', 1, 'HandleVisibility', 'off');

% Add labels for Lagrangian Points, Earth, and Moon
text(collinearPoints(1) - 0.22, 0, 'L_1', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(collinearPoints(2) + 0.1, 0, 'L_2', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(collinearPoints(3) - 0.23, 0, 'L_3', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(triangularPoints(1,1) + 0.07, triangularPoints(1,2) + 0.15, 'L_4', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(triangularPoints(2,1) + 0.07, triangularPoints(2,2) - 0.18, 'L_5', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(-mu - 0.1, -0.19, 'Earth', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');
text(1 - mu - 0.1, -0.19, 'Moon', 'FontSize', 20, 'Color', 'k', 'Interpreter', 'tex');

% Axis properties
axis equal;
xlim([-1.5, 2.5]);
xlabel('x [DU]', 'FontSize', 24);
ylabel('y [DU]', 'FontSize', 24);
zlabel('z [DU]', 'FontSize', 24);


% C constant of the Lagrangian points
x_L = [collinearPoints(1) 0; collinearPoints(2) 0; collinearPoints(3) 0; triangularPoints(1,:); triangularPoints(2,:)];
C_L = zeros(1,5);
for i = 1:5
    C_L(i) = 2*U(x_L(i,1), x_L(i,2));
end

%% EX 1.2
clc
close all
% Find the peiodic HALO orbit

% Defiine initial conditions
x0 = 1.068792441776;
y0 = 0;
z0 = 0.071093328515;
vx0 = 0;
vy0 = 0.319422926485;
vz0 = 0;
xx0 = [x0; y0; z0; vx0; vy0; vz0];
mu = 0.012150;

% Define a propagation time
tf = 5.0; 

% Define a target Jacobi constant for the Halo orbit
C_targ = 3.09;

% No correction
[~,~,~,xx_F]  = propagate3D(0,xx0,tf,mu,false);  % flag set to false to continue the propagation up to final time
[~,~,~,xx_B]  = propagate3D(0,xx0,-tf,mu,false); % flag set to false to continue the propagation up to final time

figure
hold on
plot3(xx_F(:,1),xx_F(:,2),xx_F(:,3),'LineWidth',2)
plot3(xx_B(:,1),xx_B(:,2),xx_B(:,3),'LineWidth',2)

xlabel('x [DU]')
ylabel('y [DU]')
zlabel('z [DU]')

legend('Forward Perturbation', 'Backward Perturbation')

% Correction of the perturbed solution
% Initialization of errors 
err_vxf = 1; 
err_vzf = 1; 
err_y = 1;
err_C = 1; 

Nmax    = 100;   % Set a maximum number of iterations
iter    = 0;    % Initialize the iteration counter
tol     = 1e-12; % Set the desired tolerance

% Set the update to the first guess of the velocity
x0_new = x0;
z0_new = z0;
vy0_new = vy0;
vxf_ref = 0;
vzf_ref = 0;
xx0_new = [x0_new, y0, z0_new, vx0, vy0_new, vz0];

% Define a propagation time
tf = 5.0;

% Find the new corrected state
[xx0_new, iter, C_new, te] = correction(Nmax, tol, iter, tf, mu, xx0_new, C_targ);

x0_new = xx0_new(1);
y0_new = xx0_new(2);
z0_new = xx0_new(3);
vx0_new = xx0_new(4);
vy0_new = xx0_new(5);
vz0_new = xx0_new(6);

fprintf(' Number of iterations: %d',iter);

[~,~ ,te, xx_F, tt_F] = propagate3D(0,[x0_new;y0_new;z0_new;vx0_new;vy0_new;vz0_new], te,mu,false);
[~,~,te,xx_B, tt_B]  = propagate3D(0,[x0_new;y0_new;z0_new;vx0_new;vy0_new;vz0_new],-te,mu,false); % flag set to false to continue the propagation up to final time

figure
hold on
plot3(xx_F(:,1),xx_F(:,2),xx_F(:,3),'LineWidth',2)
plot3(xx_B(:,1),xx_B(:,2),xx_B(:,3),'LineWidth',2)
plot(-mu, 0, 'o','MarkerEdgeColor','k', 'MarkerFaceColor', [0, 0, 1],'MarkerSize', 15,'HandleVisibility','off');
plot(1-mu, 0, 'o','MarkerFaceColor', [0.9, 0.9, 0.9], 'MarkerEdgeColor', 'k', 'MarkerSize', 12,'HandleVisibility','off');
plot(collinearPoints(1), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'DisplayName','Colinear Points');
plot(collinearPoints(2), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'HandleVisibility','off');
plot(collinearPoints(3), 0, 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.1, 0.7, 0.3],'MarkerSize', 10, 'HandleVisibility','off');
plot(triangularPoints(1,1), triangularPoints(1,2), 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.85, 0.33, 0.1],'MarkerSize', 10, 'DisplayName','Triangular Points');
plot(triangularPoints(2,1), triangularPoints(2,2), 'o','MarkerEdgeColor','k','MarkerFaceColor', [0.85, 0.33, 0.1],'MarkerSize', 10, 'HandleVisibility','off');
xlabel('x [DU]')
ylabel('y [DU]')
zlabel('z [DU]')
text(collinearPoints(1) - 0.22, 0, 'L_1', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(collinearPoints(2) + 0.1, 0, 'L_2', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(collinearPoints(3) - 0.23, 0, 'L_3', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(triangularPoints(1,1) + 0.07, triangularPoints(1,2) + 0.15, 'L_4', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(triangularPoints(2,1) + 0.07, triangularPoints(2,2) - 0.18, 'L_5', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(-mu - 0.1, -0.19, 'Earth', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
text(1 - mu - 0.1, -0.19, 'Moon', 'FontSize', 18, 'Color', 'k', 'Interpreter', 'tex');
legend('Forward Perturbation', 'Backward Perturbation')

figure
hold on
plot3(xx_F(:,1),xx_F(:,2),xx_F(:,3),'LineWidth',1, 'Color','b')
plot3(xx_B(:,1),xx_B(:,2),xx_B(:,3),'LineWidth',1, 'Color', 'b')

plot(collinearPoints(2), 0, 'Marker','o');

xlabel('x [-]')
ylabel('y [-]')
view([-15 20])
legend('HALO orbit', '','L2');
%% EX 1.3
% Numerical continuation, compute the families of halo
% orbits until C = 3.04

C_final = 3.04;

% Select an arbitrary number oh Halo orbits
C_vec = linspace(C_targ, C_final, 11);

% Set initial vector
x0 = 1.068792441776;
y0 = 0;
z0 = 0.071093328515;
vx0 = 0;
vy0 = 0.319422926485;
vz0 = 0;
xx0_new = [x0;y0;z0;vx0;vy0;vz0]; 


xScatterCell = cell(length(C_vec), 1); % Initialize a cell array

for i = 1:length(C_vec)
    % Reset iteration count for the correction algorithm
    iter = 0;

    % Apply correction
    [xx0_new, iter, C_new, te] = correction(Nmax, tol, iter, tf, mu, xx0_new, C_vec(i));
  
    % Propagate backward and forward
    [~, ~, te, xx_F, ~] = propagate3D(0, xx0_new, te, mu, false);
    [~, ~, te, xx_B, ~] = propagate3D(0, xx0_new, -te, mu, false);

    % Combine forward and backward propagation results
    xx = [xx_F; xx_B];

    % Store in the cell array
    xScatterCell{i} = xx;
end

% Concatenate all results into a single matrix
xScatter = vertcat(xScatterCell{:}); % Combine cell array contents

% PLOTS
figure();
clr = linspace(C_vec(1), C_vec(end), max(length(xScatter)));
scatter3(xScatter(:,1), xScatter(:,2), xScatter(:,3), 2, clr);
colorbar;
colormap('parula');
hold on
grid on
plot(-mu, 0, 'Marker','o', 'MarkerEdgeColor','b', 'MarkerFaceColor','b', 'MarkerSize',40);
plot(1-mu, 0, 'Marker','o', 'MarkerEdgeColor','[0.5 0.5 0.5]', 'MarkerFaceColor','[0.5 0.5 0.5]', 'MarkerSize',10);
plot(collinearPoints(1), 0, 'Marker','o');
plot(collinearPoints(2), 0, 'Marker','o');
plot(collinearPoints(3), 0, 'Marker','o');
plot(triangularPoints(1,1), triangularPoints(1,2), 'Marker','o');
plot(triangularPoints(2,1), triangularPoints(2,2), 'Marker','o');
xlabel('x [-]',FontSize=14)
ylabel('y [-]',FontSize=14)

figure();
hold on
clr = linspace(C_vec(1), C_vec(end), max(length(xScatter)));
scatter3(xScatter(:,1), xScatter(:,2), xScatter(:,3), 2, clr);
plot(collinearPoints(2), 0, 'Marker','o', 'MarkerSize',15);
colormap('parula');
cb = colorbar;
xlabel('x [DU]')
ylabel('y [DU]')
zlabel('z [DU]')
legend('', 'L2')

%% FUNCTION
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',24);
    set(groot, 'defaultAxesLabelFontSizeMultiplier', 1.2)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function points = lagrangianPoints(string, dUdx, dUdy)
% LAGRANGIANPOINTS Calculates the positions of Lagrangian points in a
% system with two primary bodies, based on the input parameters.
%
% Inputs:
%   - string: A string specifying the type of Lagrangian points to compute.
%       'collinear' - Calculates the collinear points (L1, L2, L3).
%       'triangular' - Calculates the triangular points (L4, L5).
%   - dUdx: A function handle for the derivative of the effective potential
%       with respect to x. Used to find collinear points (L1, L2, L3).
%   - mu: The mass ratio of the two primary body.
%
% Outputs:
%   - points: A matrix containing the x-coordinates of the calculated
%       Lagrangian points. 
%       For 'collinear': [x_L1; x_L2; x_L3]
%       For 'triangular': [x_L4; x_L5]
% Define the initial guesses
L1_guess = [0.5, 0];            % Point between Earth and Moon on x-axis
L2_guess = [1.5, 0];            % Point after the Moon on the x-axis
L3_guess = [-0.5, 0];           % Point before Earth on x-axis
L4_guess = [0.5, sqrt(3/2)];    % Initial guess for the triangular points
L5_guess = [0.5, -sqrt(3/2)];   % Initial guess for the triangular points


f = @(x) [dUdx(x(1),x(2)), dUdy(x(1),x(2))];
    if strcmpi('collinear', string)
        % COLLINEAR POINTS: L1, L2, L3
        % These points lie along the line connecting the two primary bodies.
        % Initial guesses for their positions are provided.
        
        % Set optimization options for high precision
        options1 = optimoptions('fsolve', ...
            'FunctionTolerance', 1e-10, 'StepTolerance', 1e-12, ...
            'OptimalityTolerance', 1e-10, 'MaxIterations', 500, ...
            'MaxFunctionEvaluations', 1000);

        % Solve for x-coordinates of L3, L1, and L2
        L3 = fsolve(f, L3_guess, options1); 
        L1 = fsolve(f, L1_guess, options1); 
        L2 = fsolve(f, L2_guess, options1); 
        points = [L1; L2; L3];
    end

    if strcmpi('triangular', string)
        % TRIANGULAR POINTS: L4, L5
        
        % Set options for the nonlinear solver
        options2 = optimoptions('fsolve', ...
            'FunctionTolerance', 1e-10, 'StepTolerance', 1e-12, ...
            'OptimalityTolerance', 1e-10, 'MaxIterations', 500, ...
            'MaxFunctionEvaluations', 1000);
        
        % Solve for the coordinates of L5 and L4
        L5 = fsolve(f, L5_guess, options2); % L5 is trailing the smaller primary
        L4 = fsolve(f, L4_guess, options2); % L4 is leading the smaller primary
        
        % Combine the results into a single output
        points = [L4; L5];
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xf, PHIf, tf, xx, tt] = propagate3D(t0, x0, tf, mu, varargin)
% PROPAGATE3D Propagates the state of a spacecraft in the Circular 
% Restricted Three-Body Problem (CR3BP) using numerical integration.
% Additionally, propagates the State Transition Matrix (STM) for sensitivity analysis.
%
% Inputs:
%   - t0: Initial time (scalar).
%   - x0: Initial state vector [x, y, z, vx, vy, vz] (6x1 vector).
%   - tf: Final time (scalar). This will be adjusted if an event (e.g., crossing the xz-plane) is detected.
%   - mu: Mass ratio of the CR3BP system.
%   - varargin (optional): 
%       * If provided, the first argument is evtFlag (boolean). 
%         - true: Enables event detection (e.g., xz-plane crossing). 
%         - false: Disables event detection.
%
% Outputs:
%   - xf: Final state vector [x, y, z, vx, vy, vz] at the end of propagation (6x1 vector).
%   - PHIf: Final State Transition Matrix (STM) (6x6 matrix).
%   - tf: Final time, adjusted if an event is detected (scalar).
%   - xx: Time history of the propagated state vector (nx6 matrix, where n is the number of time steps).
%   - tt: Time vector corresponding to the propagated states (nx1 vector).

    % Check if event detection flag is provided; default is true
    if nargin > 4
        evtFlag = varargin{1};
    else
        evtFlag = true;
    end

    % Time of flight
    tof = tf - t0;

    % Initialize State Transition Matrix (STM) at the initial time
    Phi0 = eye(6);

    % Append STM to the initial conditions
    x0Phi0 = [x0; Phi0(:)];
    
    % Set ODE solver options, including event detection
    options_STM = odeset('reltol', 1e-12, 'abstol', 1e-12, ...
                         'Events', @(t, x) xz_plane_crossing(t, x, evtFlag));

    % Perform numerical integration using ode78 
    [tt, xx] = ode78(@(t, x) CR3BP_STM(t, x, mu), [0 tof], x0Phi0, options_STM);

    % Extract the final state vector
    xf = xx(end, 1:6)'; % Final state at tf

    % Extract the final STM from the propagated data
    PHIf = reshape(xx(end, 7:end), 6, 6); % STM reshaped to 6x6 matrix

    tf = tt(end);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [value, isterminal, direction] = xz_plane_crossing(~,y,isTerminal)
% Event function - xz-plane crossing
    value = y(2);
    isterminal = isTerminal;
    direction = 0;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = CR3BP_STM(~, xx, mu)
% CR3BP_STM Computes the derivatives of the state and State Transition 
% Matrix (STM) for the Circular Restricted Three-Body Problem (CR3BP).
%
% Inputs:
%   - ~: Time (not used explicitly since CR3BP is autonomous).
%   - xx: Combined state vector and STM at the current time. 
%         The first 6 elements represent the state vector [x, y, z, vx, vy, vz].
%         The remaining elements represent the STM, stored as a 1D vector.
%   - mu: Mass ratio of the CR3BP system).
%
% Outputs:
%   - dxdt: Time derivative of the combined state and STM. 
%           The first 6 elements are the derivatives of the state vector.
%           The remaining elements are the derivatives of the STM, 
%           stored as a 1D vector.


% Extract state variables from the input vector
x = xx(1);    % x-coordinate of position
y = xx(2);    % y-coordinate of position
z = xx(3);    % z-coordinate of position
vx = xx(4);   % x-component of velocity
vy = xx(5);   % y-component of velocity
% vz = xx(6); % z-component of velocity (included in calculations but unused here)

% Reshape the remaining elements of xx into the STM (6x6 matrix)
Phi = reshape(xx(7:end), 6, 6);

% Compute distances to the two primary bodies
r1 = sqrt((x + mu)^2 + y^2 + z^2);         % Distance to the larger primary
r2 = sqrt((x + mu - 1)^2 + y^2 + z^2);     % Distance to the smaller primary

% Compute partial derivatives of the effective potential
dUdx = x - (1-mu)/r1^3 * (mu + x) + mu/r2^3 * (1 - mu - x);
dUdy = y - (1-mu)/r1^3 * y - mu/r2^3 * y;
dUdz = - (1-mu)/r1^3 * z - mu/r2^3 * z;

% Construct the A matrix (variational equations matrix)
A = [0, 0, 0, 1, 0, 0;
     0, 0, 0, 0, 1, 0;
     0, 0, 0, 0, 0, 1;
     (mu - 1)/r1^3 - mu/r2^3 + (3*mu*(2*mu + 2*x - 2)*(mu + x - 1))/(2*r2^5) - (3*(2*mu + 2*x)*(mu + x)*(mu - 1))/(2*r1^5) + 1, (3*mu*y*(mu + x - 1))/r2^5 - (3*y*(mu + x)*(mu - 1))/r1^5, (3*mu*z*(mu + x - 1))/r2^5 - (3*z*(mu + x)*(mu - 1))/r1^5, 0, 2, 0;
     (3*mu*y*(2*mu + 2*x - 2))/(2*r2^5) - (3*y*(2*mu + 2*x)*(mu - 1))/(2*r1^5), (mu - 1)/r1^3 - mu/r2^3 - (3*y^2*(mu - 1))/r1^5 + (3*mu*y^2)/r2^5 + 1, (3*mu*y*z)/r2^5 - (3*y*z*(mu - 1))/r1^5, -2, 0, 0;
     (3*mu*z*(2*mu + 2*x - 2))/(2*r2^5) - (3*z*(2*mu + 2*x)*(mu - 1))/(2*r1^5), (3*mu*y*z)/r2^5 - (3*y*z*(mu - 1))/r1^5, (mu - 1)/r1^3 - mu/r2^3 - (3*z^2*(mu - 1))/r1^5 + (3*mu*z^2)/r2^5, 0, 0, 0];

% Compute the derivative of the STM
Phidot = A * Phi;

% Initialize the output vector
dxdt = zeros(42, 1);

% Populate the state derivatives
dxdt(1:3) = xx(4:6);          % Velocity components
dxdt(4)   = dUdx + 2*vy;      % Acceleration in x
dxdt(5)   = dUdy - 2*vx;      % Acceleration in y
dxdt(6)   = dUdz;             % Acceleration in z

% Populate the STM derivatives (flattened into a vector)
dxdt(7:end) = Phidot(:);      % STM derivatives
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function C = JacobiConst(xx)
% Find the Jacobi Constant from the values of the state computing the
% potential

x = xx(1);
y = xx(2);
z = xx(3);
vx =xx(4);
vy = xx(5);
vz = xx(6);

mu = 0.012150; %Earth-Moon equivalent mass 
r1 = sqrt((x + mu)^2 + y^2 + z^2);
r2 = sqrt((x + mu - 1)^2 + y^2 +z^2);
v= sqrt(vx^2 + vy^2 + vz^2);

OM = 1/2*(x^2 + y^2) + (1-mu)/r1 + mu/r2 + 1/2*mu*(1-mu);

C = 2*OM -v^2;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [xx0_new, iter, C_new, te] = correction(Nmax, tol, iter, tf, mu, xx0, C_targ)
% CORRECTION Applies a differential correction algorithm to adjust the 
% initial conditions of a trajectory in the CR3BP system.
%
% Inputs:
%   - Nmax: Maximum number of iterations allowed for the correction process.
%   - tol: Tolerance for convergence.
%   - iter: iteration count.
%   - tf: Target final time of propagation.
%   - mu: Mass ratio of the CR3BP system.
%   - xx0: Initial state vector [x0, y0, z0, vx0, vy0, vz0].
%   - C_targ: Target Jacobi constant value for the trajectory.
%
% Outputs:
%   - xx0_new: Corrected initial state vector [x0, y0, z0, vx0, vy0, vz0].
%   - iter: Number of iterations performed.
%   - C_new: Jacobi constant value for the corrected trajectory.
%   - te: Event time when the trajectory satisfies the desired conditions.


% Extract initial conditions
x0_new = xx0(1);     % Initial x position
y0 = xx0(2);         % Initial y position (fixed in the correction)
z0_new = xx0(3);     % Initial z position
vx0 = xx0(4);        % Initial x velocity (fixed in the correction)
vy0_new = xx0(5);    % Initial y velocity
vz0 = xx0(6);        % Initial z velocity

% Initialization of errors
err_vxf = 1;  
err_vzf = 1;  
err_y = 1;    
err_C = 1;   

% Iterative correction process
while (abs(err_vxf) > tol || abs(err_vzf) > tol || abs(err_C) > tol || abs(err_y) > tol) && iter < Nmax
    
    % Propagate the trajectory up to the current final time
    [xf, PHI, te] = propagate3D(0, [x0_new; y0; z0_new; vx0; vy0_new; vz0], tf, mu);
    xx0_new = [x0_new; y0; z0_new; vx0; vy0_new; vz0];
    
    % Compute the Jacobi constant for the new trajectory
    C_new = JacobiConst(xx0_new);
    
    % Linearization of the state using the variational equations
    dxdt = CR3BP_STM(te, [xf; PHI(:)], mu);

    % Linearization of the Jacobi constant with respect to the state
    DfunC = @(x, y, z, vx, vy, vz) [
        2*x + ((2*mu + 2*x)*(2*mu - 2)) / (2*((mu + x)^2 + y^2 + z^2)^(3/2)) - ...
        (mu*(2*mu + 2*x - 2)) / (((mu + x - 1)^2 + y^2 + z^2)^(3/2)), ...
        2*y + (y*(2*mu - 2)) / (((mu + x)^2 + y^2 + z^2)^(3/2)) - ...
        (2*mu*y) / (((mu + x - 1)^2 + y^2 + z^2)^(3/2)), ...
        (z*(2*mu - 2)) / (((mu + x)^2 + y^2 + z^2)^(3/2)) - ...
        (2*mu*z) / (((mu + x - 1)^2 + y^2 + z^2)^(3/2)), ...
        -2*vx, -2*vy, -2*vz
    ];
    DfunC_el = DfunC(xx0_new(1), xx0_new(2), xx0_new(3), xx0_new(4), xx0_new(5), xx0_new(6));
    
    % Assemble the 4x4 correction matrix
    A = [PHI(2,1), PHI(2,3), PHI(2,5), dxdt(2);   % Row for y position correction
         PHI(4,1), PHI(4,3), PHI(4,5), dxdt(4);   % Row for x-velocity correction
         PHI(6,1), PHI(6,3), PHI(6,5), dxdt(6);   % Row for z-velocity correction
         DfunC_el(1), DfunC_el(3), DfunC_el(5), 0]; % Row for Jacobi constant correction
    
    % Define the constant term for the corrections
    b = [-xf(2), -xf(4), -xf(6), C_targ - C_new]';
    
    % Solve the system of equations to compute corrections
    d = A \ b;
   
    % Apply corrections to the initial conditions
    x0_new = x0_new + d(1);
    z0_new = z0_new + d(2);
    vy0_new = vy0_new + d(3);
    tf = tf + d(4);
    
    % Compute the updated errors
    err_vxf = abs(xf(4));          
    err_y = abs(xf(2));             
    err_vzf = abs(xf(6));           
    err_C = abs(C_new - C_targ);    

    % Increment the iteration counter
    iter = iter + 1;

end

% Final corrected initial conditions
xx0_new = [x0_new; y0; z0_new; vx0; vy0_new; vz0];
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

