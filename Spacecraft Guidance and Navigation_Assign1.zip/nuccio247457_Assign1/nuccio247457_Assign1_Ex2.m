% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 1, Exercise 2
% Author: Gabriele Nuccio

clc
clearvars
close all

% Load the SPICE kernels
cspice_kclear();
applyDefaultSettings();
cspice_furnsh('ex02.tm');

%% 2.1
% Initial Data
alpha = 0.2*pi;
beta = 1.41;
delta = 4; % Time of Flight
ti = 2; % Initial Time [-]

m_s = 3.28900541e5; % Scaled mass of the Sun [-]
rho = 3.88811143e2; % Scaled Sun - (Earth - Moon) distance [-]
om_s = -9.25195985e-1; % Scaled angular velocity of the Sun [-]
om_em = 2.66186135e-06; % Earth - Moon angular velocity [-]
l_em = 3.84405e08; % Earth-Moon distance[m]
VU = 1.02454018e03; % Velocity Unit[m/s]
h_i = 167; % Altitude of departure orbit [km]
h_f = 100; % Altitude of arrival orbit [km]
DU = 3.84405000e5; % Distance Unit[km]
TU = 4.34256461; % Time Unit[days]

% Find radiuses of Earth and Moon
rEarth = cspice_bodvrd('Earth', 'RADII', 3);
rEarth = rEarth(1);
rMoon = cspice_bodvrd('Moon', 'RADII', 3);
rMoon = rMoon(1);

% Find mu
GM_E = cspice_bodvrd('Earth', 'GM',1);
GM_M = cspice_bodvrd('Moon', 'GM',1);
mu = GM_M/(GM_E + GM_M);


% Find initial guess to be propagated
r0 = (rEarth + h_i)/DU;
rf = (rMoon + h_f)/DU;

x0 = r0*cos(alpha) - mu;
y0 = r0*sin(alpha);
v0 = beta * sqrt((1-mu)/r0);
x0_dot = -(v0 - r0) * sin(alpha);
y0_dot = (v0 - r0) * cos(alpha);

% Initial guess vector
xx0 = [x0; y0; x0_dot; y0_dot];

% struct of parameters
parameters.mu = mu;
parameters.r0 = r0;
parameters.rf = rf;
parameters.rho = rho;
parameters.ms = m_s;
parameters.om_s = om_s;

% compute the final time
tf = ti + delta;
tic
% Propagate the Four Body Problem
[tt,xx] = propagate4BP(ti,xx0,tf,parameters);

% Find the circumference coordinates to plot them
theta = linspace(0, 2*pi, 1000);
xInitialCirc = r0 * cos(theta) - mu;
yInitialCirc = r0 * sin(theta);
xFinalCirc = rf * cos(theta) - mu +1;
yFinalCirc = rf * sin(theta);
xInitialCircECI = r0 * cos(theta);
yInitialCircECI = r0 * sin(theta);
xFinalCircECI =  cos(theta);
yFinalCircECI = sin(theta);

% Rotate the vector from rotating frame to ECI frame
xECI  = rot2ECI(tt,xx,mu);

% Create a figure with two subplots
figure();

% Subplot 1: Trajectory in the rotating frame
subplot(1, 2, 1); % Create the first subplot
hold on;
plot(xx(:, 1), xx(:, 2), 'LineWidth', 2); % Transfer orbit in the rotating frame
plot(xInitialCirc, yInitialCirc, '--k', 'LineWidth', 2); % Parking orbit
plot(xFinalCirc, yFinalCirc, '--r', 'LineWidth', 2); % Target orbit
axis equal;
xlabel('x [DU]');
ylabel('y [DU]');
title('Rotating Frame');
legend('Transfer Orbit', 'Parking Orbit', 'Target Orbit');
grid on;

% Subplot 2: Trajectory in the ECI frame
subplot(1, 2, 2); % Create the second subplot
hold on;
plot(xECI(:, 1), xECI(:, 2), 'LineWidth', 2); % Transfer orbit in the ECI frame
plot(xInitialCircECI, yInitialCircECI, '--k', 'LineWidth', 2); % Parking orbit
plot(xFinalCircECI, yFinalCircECI, '--r', 'LineWidth', 2); % Target orbit
axis equal;
xlabel('x [DU]');
ylabel('y [DU]');
title('ECI Frame');
legend('Transfer Orbit', 'Parking Orbit', 'Moon Orbit Around Earth');
grid on;

%% OPTIMIZATION - SIMPLE SHOOTING 2.2 a)
% Set Options
options = optimoptions('fmincon', 'Display', 'iter-detailed', 'Algorithm', 'active-set','ConstraintTolerance', 1e-10, 'OptimalityTolerance', 1e-10, 'FiniteDifferenceStepSize',1e-12);

% Define Initial Guess
x0 = [xx0; ti; tf];

% Define the cost function
costFun = @(x) cost_function(parameters,x);

% Define the Non Linear Constraints
nonLinCon = @(x) constraints(parameters, x);
[x_opt, DV_tot] = fmincon(costFun, x0, [], [], [], [], [], [], nonLinCon, options);



% Plot Solution:
[tt, xx] = propagate4BP(x_opt(5), x_opt(1:4), x_opt(6), parameters);

[c, ceq] = nonLinCon(x_opt);
ceqDim = [ceq(3) * DU*1e3, ceq(4) * VU];

% Rotate from rotating to ECI
xECIsimple  = rot2ECI(tt,xx,mu);

% Create a figure with two subplots
figure();

% Subplot 1: Rotating frame trajectory with circumferences
subplot(1, 2, 1); % Create the first subplot
hold on;
plot(xx(:, 1), xx(:, 2), 'LineWidth', 2); % Transfer orbit in the rotating frame
grid on;
axis equal;

% Plot circumferences of r0 and rf centered on P1 (Earth) and P2 (Moon)
theta = linspace(0, 2 * pi, length(xx));  
xEarth = -mu + r0 * cos(theta);  
yEarth = r0 * sin(theta);
xMoon = (1 - mu) + rf * cos(theta);  
yMoon = rf * sin(theta);

plot(xEarth, yEarth, '--k', 'LineWidth', 2); % Parking orbit (Earth-centered)
plot(xMoon, yMoon, '--r', 'LineWidth', 2); % Target orbit (Moon-centered)

legend('Transfer Orbit', 'Parking Orbit', 'Target Orbit');
xlabel('x [DU]');
ylabel('y [DU]');
title('Rotating Frame');

% Subplot 2: Trajectory in the ECI frame
subplot(1, 2, 2); % Create the second subplot
hold on;
plot(xECIsimple(:, 1), xECIsimple(:, 2), 'LineWidth', 2); % Transfer orbit in the ECI frame
plot(xInitialCircECI, yInitialCircECI, '--k', 'LineWidth', 2); % Parking orbit (Earth-centered)
plot(xFinalCircECI, yFinalCircECI, '--r', 'LineWidth', 2); % Target orbit (Moon-centered)

axis equal;
xlabel('x [DU]');
ylabel('y [DU]');
legend('Transfer Orbit', 'Parking Orbit', 'Moon Orbit Around Earth');
title('ECI Frame');

%% 2.2 b - SIMPLE SHOOTING WITH STM

ti = 2;
delta = 4;
tf = ti + delta;

nonLinCon2 = @(x) constraints2(parameters, x);
% Set options
options2 = optimoptions('fmincon', 'Algorithm', 'active-set', 'ConstraintTolerance', 1e-10, 'OptimalityTolerance', 1e-10,'SpecifyObjectiveGradient',true,'SpecifyConstraintGradient',true, 'Display','iter-detailed', 'FiniteDifferenceStepSize',1e-12); 
[x_opt_STM, DV_tot_STM] = fmincon(@(x) cost_function2(parameters,x), [xx0 ; ti ; tf], [],[],[],[],[],[], nonLinCon2, options2);

[cSTM, ceqSTM] = nonLinCon2(x_opt_STM);
ceqSTMDim = [ceqSTM(3) * DU*1e3; ceqSTM(4) * VU];
% Collect the optimal initial state
xx0_opt_STM= x_opt_STM(1:4);
ti = x_opt_STM(5);
tf = x_opt_STM(6);

% Propagate the optimal initial state
[tt_STM,xx_STM,Phi] = propagate4BP_STM(ti, xx0_opt_STM, tf, parameters);

xECIsimpleSTM  = rot2ECI(tt_STM,xx_STM,mu);
% PLOTS
% Create a figure with two subplots
figure;

% Subplot 1: Plot in the rotating frame
subplot(1, 2, 1); % This places the first plot in a 1x2 grid, first position
hold on;
plot(xx_STM(:,1), xx_STM(:,2), 'LineWidth', 2);  % Transfer orbit
plot(xEarth, yEarth, '--k', 'LineWidth', 2);     % Parking orbit (Earth orbit)
plot(xMoon, yMoon, '--r', 'LineWidth', 2);       % Target orbit (Moon orbit)
xlabel('x [DU]');
ylabel('y [DU]');
legend('Transfer Orbit', 'Parking Orbit', 'Target Orbit');
axis equal;

% Subplot 2: Plot in the ECI frame
subplot(1, 2, 2); % This places the second plot in a 1x2 grid, second position
hold on;
plot(xECIsimpleSTM(:,1), xECIsimpleSTM(:,2), 'LineWidth', 2);  % Transfer orbit in ECI frame
plot(xInitialCircECI, yInitialCircECI, '--k', 'LineWidth', 2);  % Parking orbit in ECI frame
plot(xFinalCircECI, yFinalCircECI, '--r', 'LineWidth', 2);  % Target orbit in ECI frame
axis equal;
xlabel('x [DU]');
ylabel('y [DU]');
legend('Transfer Orbit', 'Parking Orbit', 'Moon Orbit Around Earth');


%% MULTIPLE SHOOTING - 2.3

% Redefine initial and final time 
N = 4; % Number of Nodes
ti = 2;
tf = 6;

% Define vector of radius
R = [rEarth, rMoon];

t = zeros(N,1);

for j = 1:N
    t(j) = ti + (j-1)/(N-1) * (tf - ti);
end

% Define the nodes
x_mult = zeros(4,N);
x_mult(:,1) = xx0;

for j = 2 : N
 [~,xx] = propagate4BP(t(j-1), x_mult(:,j-1), t(j), parameters);
 x_mult(:,j) = xx(end,:)';
end

% Initial guess for Multiple Shooting
x0_mult = zeros(4*N+2,1);
x0_mult(1:4*N) = reshape(x_mult, 4*N, 1);
x0_mult(4*N+1) = ti;
x0_mult(4*N+2) = tf;

% Set options
options3 = optimoptions('fmincon', 'Algorithm', 'active-set', 'SpecifyObjectiveGradient',true,'SpecifyConstraintGradient',true, 'Display','iter-detailed', 'MaxFunctionEvaluations',1e6, 'ConstraintTolerance',1e-7, 'OptimalityTolerance',1e-10, 'MaxIterations',10000); 
[x_mult_opt, DV_tot_mult] = fmincon(@(x) MultiShootingCost(parameters,x), x0_mult, [],[],[],[],[],[], @(x) constraintsMulti(parameters,x, R, DU), options3);

nonLinConMult =  @(x) constraintsMulti(parameters,x, R, DU);
[cMult, ceqMult] = nonLinConMult(x_mult_opt);
ceqDimMult = [ceqMult(15) * DU*1e3; ceqMult(16) * VU];

t_intervals = cell(N-1, 1); % Cell array for time vectors
x_intervals = cell(N-1, 1); % Cell array for state vectors

% Extract initial and final times from optimization results
t_in_m = x_mult_opt(end-1);
t_fin_m = x_mult_opt(end);

% Compute time vector for each interval
t = linspace(t_in_m, t_fin_m, N);

% Loop over intervals to propagate states and store results
for j = 1:N-1
    % Propagate the state for the current interval
    [tt, xx, ~] = propagate4BP_STM(t(j), x_mult_opt(4*j-3:4*j), t(j+1), parameters);
    
    t_intervals{j} = tt;    % Time vector for the interval
    x_intervals{j} = xx(:, 1:4); % State vector for the interval (first 4 columns)
end

% Concatenate results from all intervals
tvecRotMult = vertcat(t_intervals{:}); % Concatenate time vectors
xPlotMult = vertcat(x_intervals{:});    % Concatenate state vectors

% PLOT
figure();

% Subplot 1: Optimal trajectory in the rotating frame
subplot(1, 2, 1); % Create a 1x2 grid of plots, select the first one
hold on;
plot(xPlotMult(:, 1), xPlotMult(:, 2));
plot(xEarth, yEarth, '--k', 'LineWidth', 2);
plot(xMoon, yMoon, '--r', 'LineWidth', 2);
for j = 1:floor((length(x_mult_opt)) / 4) - 1
    plot(x_mult_opt(4 * j + 1), x_mult_opt(4 * j + 2), 'Marker', 'o', 'MarkerSize', 7, 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
end
plot(x_mult_opt(1), x_mult_opt(2), 'Marker', 'o', 'MarkerSize', 7, 'Color', [0.5 0.5 0.5], 'LineWidth', 2);
xlabel('x [DU]');
ylabel('y [DU]');
title('Optimal Trajectory in Rotating Frame');
legend('Transfer Orbit', 'Parking Orbit', 'Target Orbit', 'Nodes');
axis equal;
xPlotMult = xPlotMult(:,1:4);
xECImult  = rot2ECI(tvecRotMult,xPlotMult,mu);
% Subplot 2: Optimal trajectory in the ECI frame
subplot(1, 2, 2); % Select the second plot in the 1x2 grid
hold on;
plot(xECImult(:, 1), xECImult(:, 2), 'LineWidth', 1);
plot(xInitialCircECI, yInitialCircECI, '--k', 'LineWidth', 2);
plot(xFinalCircECI, yFinalCircECI, '--r', 'LineWidth', 2);
for i = 1:N - 1
    optStateEciMS = rot2ECI(t_intervals{i}, x_intervals{i}, mu);
    plot(optStateEciMS(:, 1), optStateEciMS(:, 2));
    plot(optStateEciMS(1, 1), optStateEciMS(1, 2), 'o', 'Color', [0.5 0.5 0.5]);
end
xlabel('x [DU]');
ylabel('y [DU]');
title('Optimal Trajectory in ECI Frame');
legend('Transfer Orbit', 'Parking Orbit', 'Moon Orbit Around Earth', '', '', '', 'Nodes');
axis equal;

%% 2.4
clc

% DATA INITIALIZATION
tformat = 'YYYY-MON-DD-HR:MN:SC.####::TDB';
t_i_tdb = 'September 28 00:00:00.000 TDB 2024';
t_i_n = x_opt_STM(5);
t_f_n = x_opt_STM(6);


moonRevPeriod = 2 * pi / om_em;

et_l = cspice_str2et(t_i_tdb);
et_u = et_l + moonRevPeriod;
tref = cspice_timout(et_u,tformat);

theta_target = om_s * t_i_n ;
theta_target = wrapTo2Pi(theta_target);

labels = {'Sun';
          'Earth';
          'Moon';
          'Venus';
          'Mercury';
          'Mars Barycenter';
          'Jupiter Barycenter';
          'Saturn Barycenter';
          'Uranus Barycenter';
          'Neptune Barycenter';
          'Pluto Barycenter'};

bodies = nbody_init(labels);

frame = 'J2000';
center = 'EARTH';

et = linspace(et_l, et_u, 5000);

% FIND THE INITIAL EPOCH AND PLOT OF TIME EVOLUTION OF THE ANGLE
center_th = 'EMB';
fun =  @(et) thetaFinder(theta_target, et, bodies, frame, center_th);

et_i = fzero(fun,[(et_l+et_u)/2 et_u]);
t_i = cspice_et2utc(et_i,'C', 4);

figure
plot(et,fun(et))
hold on
plot(et_i, fun(et_i),'ro','MarkerSize',10)
hold on
yline(0, '--');

et_f = et_i + (t_f_n-t_i_n) * TU * 24 * 3600;
t_f = cspice_et2utc(et_f,'C', 4);

% PROPAGATION WITH NBODY PROPAGATOR OF THE INITIAL STATE IN ECI FRAME
initialStateEMBscaled = xx0_opt_STM;

initialStateEMBECIscaled = rot2ECI(x_opt_STM(5), initialStateEMBscaled', mu);
initialStateEMBECI= [initialStateEMBECIscaled(1:2) * DU, 0, initialStateEMBECIscaled(3:4) * VU*10^-3, 0];

options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[tt, state_nBody] = ode113(@(t,x) nbodyShiftRHS(t,x,bodies,frame,center), [et_i et_f], initialStateEMBECI, options);


% PLOT OF THE TWO TRAJECTORIES

figure
hold on
plot3(state_nBody(:,1),state_nBody(:,2),state_nBody(:,3),'LineWidth', 2)
plot(xECIsimpleSTM(:,1)*DU,xECIsimpleSTM(:,2)*DU,'LineWidth', 2)
plot(xFinalCircECI*DU, yFinalCircECI*DU, '--', 'LineWidth', 2);  % Target orbit in ECI frame
axis equal
xlabel('Position X [km]')
ylabel('Position Y [km]')
zlabel('Position Z [km]')
legend('N-Body Propagator', 'Simple Shooting with Gradients', 'Moon Orbit Around Earth')
%% FUNCTION
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',20);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = CR4BP(t, xx, parameters, STM)
    % CR4BP Defines the equations of motion for the Circular Restricted 
    % 4-Body Problem (CR4BP) with optional State Transition Matrix (STM) computation.
    %
    % Inputs:
    %   t         - Current time (scalar).
    %   xx        - State vector (4x1 or larger vector):
    %               [x, y, vx, vy] (4x1) if STM is not computed, or
    %               [x, y, vx, vy, PHI] (20x1) if STM is computed.
    %               PHI is the 4x4 State Transition Matrix (STM) reshaped as a vector.
    %   parameters - Structure containing problem-specific constants:
    %                mu   - Mass ratio between the two primary bodies,
    %                ms   - Mass of the smaller third body (e.g., a spacecraft),
    %                rho  - Distance parameter,
    %                om_s - Angular velocity of the smaller third body.
    %   STM       - Boolean flag (0 or 1):
    %               0 if the STM is not computed,
    %               1 if the STM is computed and included in `xx`.
    %
    % Outputs:
    %   dxdt      - Derivative of the state vector:
    %               [dx/dt, dy/dt, dvx/dt, dvy/dt] (4x1) if STM = 0, or
    %               [dx/dt, dy/dt, dvx/dt, dvy/dt, dPHI/dt] (20x1) if STM = 1.

    % Extract parameters
    mu = parameters.mu;      % Mass ratio
    ms = parameters.ms;      % Mass of the smaller third body
    rho = parameters.rho;    % Distance parameter
    om_s = parameters.om_s;  % Angular velocity of the smaller third body

    % Extract state variables
    x = xx(1);  % x-coordinate
    y = xx(2);  % y-coordinate
    vx = xx(3); % x-velocity
    vy = xx(4); % y-velocity

    % Compute partial derivatives of the effective potential (U)
    dUdx = x ...
        - (ms * cos(om_s * t)) / rho^2 ...
        - (mu * (mu + x - 1)) / ((mu + x - 1)^2 + y^2)^(3/2) ...
        + ((2 * mu + 2 * x) * (mu - 1)) / (2 * ((mu + x)^2 + y^2)^(3/2)) ...
        - (ms * (2 * x - 2 * rho * cos(om_s * t))) / (2 * ((x - rho * cos(om_s * t))^2 + (y - rho * sin(om_s * t))^2)^(3/2));
    
    dUdy = y ...
        - (ms * sin(om_s * t)) / rho^2 ...
        - (mu * y) / ((mu + x - 1)^2 + y^2)^(3/2) ...
        - (ms * (2 * y - 2 * rho * sin(om_s * t))) / (2 * ((x - rho * cos(om_s * t))^2 + (y - rho * sin(om_s * t))^2)^(3/2)) ...
        + (y * (mu - 1)) / ((mu + x)^2 + y^2)^(3/2);

    if STM == 0
        % If STM is not computed, output the equations of motion for position and velocity only
        dxdt = zeros(4, 1); % Initialize the state derivative vector
        
        % Assign velocity components
        dxdt(1:2) = xx(3:4); % dx/dt = vx, dy/dt = vy
        
        % Assign acceleration components
        dxdt(3) = dUdx + 2 * vy; % dvx/dt (acceleration in x-direction)
        dxdt(4) = dUdy - 2 * vx; % dvy/dt (acceleration in y-direction)
    else
        % If STM is computed, include the dynamics of the STM

        % Reshape the STM vector into a 4x4 matrix
        Phi = reshape(xx(5:end), 4, 4);

        % Assemble the Jacobian matrix A(t) = dfdx (4x4 matrix)
        dfdx = [
            0,  0,  1, 0;
            0,  0,  0, 1;
            (mu - 1)/((mu + x)^2 + y^2)^(3/2) - mu/((mu + x - 1)^2 + y^2)^(3/2) - ms/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2) ...
                - (3*(mu + x)^2*(mu - 1))/((mu + x)^2 + y^2)^(5/2) + (3*ms*(x - rho*cos(om_s*t))^2)/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2) ...
                + (3*mu*(2*mu + 2*x - 2)*(mu + x - 1))/(2*((mu + x - 1)^2 + y^2)^(5/2)) + 1, ...
            (3*ms*(2*x - 2*rho*cos(om_s*t))*(2*y - 2*rho*sin(om_s*t)))/(4*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2)) ...
                + (3*mu*y*(mu + x - 1))/((mu + x - 1)^2 + y^2)^(5/2) - (3*y*(2*mu + 2*x)*(mu - 1))/(2*((mu + x)^2 + y^2)^(5/2)), ...
            0, 2;
            (3*ms*(2*x - 2*rho*cos(om_s*t))*(2*y - 2*rho*sin(om_s*t)))/(4*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2)) ...
                + (3*mu*y*(2*mu + 2*x - 2))/(2*((mu + x - 1)^2 + y^2)^(5/2)) - (3*y*(2*mu + 2*x)*(mu - 1))/(2*((mu + x)^2 + y^2)^(5/2)), ...
            (mu - 1)/((mu + x)^2 + y^2)^(3/2) - mu/((mu + x - 1)^2 + y^2)^(3/2) - ms/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2) ...
                - (3*y^2*(mu - 1))/((mu + x)^2 + y^2)^(5/2) + (3*ms*(y - rho*sin(om_s*t))^2)/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2) ...
                + (3*mu*y^2)/((mu + x - 1)^2 + y^2)^(5/2) + 1, ...
            -2, 0
        ];

        % Compute the derivative of the STM
        Phidot = dfdx * Phi;

        % Assemble the right-hand side, including the STM derivatives
        dxdt = zeros(20, 1); % Initialize the state derivative vector for 4 states + STM

        % Assign velocity components
        dxdt(1:2) = xx(3:4); % dx/dt = vx, dy/dt = vy
        
        % Assign acceleration components
        dxdt(3) = dUdx + 2 * vy; % dvx/dt
        dxdt(4) = dUdy - 2 * vx; % dvy/dt
        
        % Flatten the STM derivative matrix into a vector
        dxdt(5:end) = Phidot(:);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx, PHIf] = propagate4BP_STM(t0, x0, tf, parameters)
    % propagate4BP_STM Propagates the state and State Transition Matrix (STM)
    % in the Circular Restricted 4-Body Problem (CR4BP).
    %
    % Inputs:
    %   t0         - Initial time (scalar).
    %   x0         - Initial state vector [x, y, vx, vy] (4x1 vector):
    %                x  = Initial x-coordinate in the rotating frame,
    %                y  = Initial y-coordinate in the rotating frame,
    %                vx = Initial x-velocity in the rotating frame,
    %                vy = Initial y-velocity in the rotating frame.
    %   tf         - Final time for propagation (scalar).
    %   parameters - Structure containing problem-specific constants:
    %                mu   - Mass ratio between the two primary bodies,
    %                ms   - Mass of the smaller third body (e.g., a spacecraft),
    %                rho  - Distance parameter,
    %                om_s - Angular velocity of the smaller third body.
    %
    % Outputs:
    %   tt   - Time vector (nx1 vector) of propagation times.
    %   xx   - State vector (nx4 matrix):
    %          Each row corresponds to the state [x, y, vx, vy] at a time step.
    %   PHIf - Final State Transition Matrix (4x4 matrix) at time tf.

    % Initialize the State Transition Matrix (STM) at the initial time t0
    Phi0 = eye(4); % Identity matrix, since STM is identity at t0

    % Append the flattened STM (Phi0) to the initial conditions
    
    x0Phi0 = [x0; Phi0(:)];
    
    % Set the integration options for high accuracy
    optset = odeset('reltol', 1e-12, 'abstol', 1e-12); % Relative and absolute tolerances
    [tt, xx] = ode78(@(t, x) CR4BP(t, x, parameters, 1), [t0 tf], x0Phi0, optset);
    
    % Extract the final State Transition Matrix (STM) at time tf
    % The last row of xx contains [x, y, vx, vy, Phi(:)]
    % Reshape the flattened Phi vector into a 4x4 matrix
    PHIf = reshape(xx(end, 5:end), 4, 4);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx] = propagate4BP(t0, x0, tf, parameters)
    % PROPAGATE4BP Propagates the state of a system under the Circular 
    % Restricted 4-Body Problem (CR4BP) dynamics.
    %
    % Inputs:
    %   t0        - Initial time for integration (scalar).
    %   x0        - Initial state vector [position; velocity] (6x1 vector).
    %   tf        - Final time for integration (scalar).
    %   parameters - struct containing system parameters 
    %                
    %
    % Outputs:
    %   tt        - Time vector (Nx1 vector) containing time points at 
    %               which the state is evaluated.
    %   xx        - State matrix (Nx6 matrix) where each row corresponds 
    %               to the state [position; velocity] at a given time.
    
    % Set ODE solver options for high precision
    optset = odeset('reltol', 1e-12, 'abstol', 1e-12);
    % Perform numerical integration
    [tt, xx] = ode78(@(t, x) CR4BP(t, x, parameters, 0), [t0 tf], x0, optset);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function XX = rot2ECI(tt, xx, mu)
    % ROT2ECI Converts the state vector from the rotating reference frame
    % to the Earth-Centered Inertial (ECI) frame.
    %
    % Inputs:
    %   tt - Time vector (Nx1 vector) corresponding to the times of the states in `xx`.
    %   xx - State matrix in the rotating frame (Nx4 matrix), where each row is 
    %        [x, y, vx, vy] (position and velocity in the rotating frame).
    %   mu - Gravitational parameter of the system, representing the mass ratio
    %        (e.g., for the Earth-Moon system).
    %
    % Outputs:
    %   XX - State matrix in the ECI frame (Nx4 matrix), where each row is 
    %        [X, Y, VX, VY] (position and velocity in the inertial frame).
    
    
    % Transform position components from rotating to ECI frame
    XX(:, 1) = (xx(:, 1) + mu) .* cos(tt) - xx(:, 2) .* sin(tt); % X position
    XX(:, 2) = (xx(:, 1) + mu) .* sin(tt) + xx(:, 2) .* cos(tt); % Y position
    
    % Transform velocity components from rotating to ECI frame
    XX(:, 3) = (xx(:, 3) - xx(:, 2)) .* cos(tt) - (xx(:, 4) + xx(:, 1) + mu) .* sin(tt); % VX velocity
    XX(:, 4) = (xx(:, 3) - xx(:, 2)) .* sin(tt) + (xx(:, 4) + xx(:, 1) + mu) .* cos(tt); % VY velocity
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [c, ceq] = constraints(parameters, x)
    % constraints Defines the equality and inequality constraints for an
    % optimization problem in the Circular Restricted 4-Body Problem (CR4BP).
    %
    % Inputs:
    %   parameters - Structure containing problem-specific constants:
    %                r0  - Initial distance constraint (scalar),
    %                rf  - Final distance constraint (scalar),
    %                mu  - Mass ratio between the two primary bodies.
    %   x          - Decision variable vector containing:
    %                x(1:4) - Initial state vector [x0, y0, vx0, vy0] (4x1 vector),
    %                x(5)   - Initial time t_i (scalar),
    %                x(6)   - Final time t_f (scalar).
    %
    % Outputs:
    %   c    - Inequality constraint vector (scalar or vector). 
    %          Here, no inequality constraints are defined, so `c` is simply
    %          the difference `t_i - t_f` to ensure `t_f > t_i`.
    %   ceq  - Equality constraint vector (4x1 vector):
    %          ceq(1) - Constraint ensuring the initial state lies on the initial orbit.
    %          ceq(2) - Constraint ensuring the initial velocity satisfies the dynamic condition.
    %          ceq(3) - Constraint ensuring the final state lies on the final orbit.
    %          ceq(4) - Constraint ensuring the final velocity satisfies the dynamic condition.

    % Extract parameters
    r0 = parameters.r0; % Initial distance constraint
    rf = parameters.rf; % Final distance constraint
    mu = parameters.mu; % Mass ratio

    % Extract initial state and times from decision variables
    xx0 = x(1:4);      % Initial state [x0, y0, vx0, vy0]
    x0 = xx0(1);       % Initial x-coordinate
    y0 = xx0(2);       % Initial y-coordinate
    x0_dot = xx0(3);   % Initial x-velocity
    y0_dot = xx0(4);   % Initial y-velocity
    t_i = x(5);        % Initial time
    t_f = x(6);        % Final time

    % Propagate the state from t_i to t_f
    [~, xxf] = propagate4BP(t_i, xx0, t_f, parameters); % xxf contains the states at all time steps

    % Extract the final state from the propagation result
    xf = xxf(end, 1);      % Final x-coordinate
    yf = xxf(end, 2);      % Final y-coordinate
    xf_dot = xxf(end, 3);  % Final x-velocity
    yf_dot = xxf(end, 4);  % Final y-velocity

    % Define equality constraints for the initial and final states
    % ceq1: Ensure the initial position lies on the orbit defined by r0
    ceq1 = (x0 + mu)^2 + y0^2 - r0^2;
    % ceq2: Ensure the initial velocity satisfies the dynamic condition
    ceq2 = (x0 + mu) * (x0_dot - y0) + y0 * (y0_dot + x0 + mu);
    % ceq3: Ensure the final position lies on the orbit defined by rf
    ceq3 = (xf + mu - 1)^2 + yf^2 - rf^2;
    % ceq4: Ensure the final velocity satisfies the dynamic condition
    ceq4 = (xf + mu - 1) * (xf_dot - yf) + yf * (yf_dot + xf + mu - 1);

    % Assemble the equality constraints into a single vector
    ceq = [ceq1; ceq2; ceq3; ceq4];
    % Ensure that the initial time is less than or equal to the final time
    % This is written as `t_i - t_f <= 0` or `c = t_i - t_f`
    c = t_i - t_f;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dv_tot = cost_function(parameters, x)
    % cost_function Calculates the total delta-v required for a trajectory in the
    % Circular Restricted 4-Body Problem (CR4BP).
    %
    % Inputs:
    %   parameters - Structure containing problem-specific constants:
    %                mu  - Mass ratio between the two primary bodies,
    %                r0  - Initial orbital radius of the spacecraft (scalar),
    %                rf  - Final orbital radius of the spacecraft (scalar).
    %   x          - Decision variable vector containing:
    %                x(1:4) - Initial state vector [x0, y0, vx0, vy0] (4x1 vector),
    %                x(5)   - Initial time t_i (scalar),
    %                x(6)   - Final time t_f (scalar).
    %
    % Outputs:
    %   dv_tot - Total delta-v (change in velocity) required for the transfer
    %            between the initial and final orbits (scalar).
    %
    % Description:
    %   The function calculates the total delta-v required for a transfer trajectory 
    %   between two orbits in the CR4BP. It includes:
    %   1. The delta-v required to match the initial orbit's velocity.
    %   2. The delta-v required to match the final orbit's velocity after propagation.

    % Extract parameters
    mu = parameters.mu; % Mass ratio
    r0 = parameters.r0; % Initial orbital radius
    rf = parameters.rf; % Final orbital radius

    % Extract initial state and times from decision variables
    xx0 = x(1:4);        % Initial state [x0, y0, vx0, vy0]
    x0 = xx0(1);         % Initial x-coordinate
    y0 = xx0(2);         % Initial y-coordinate
    x0_dot = xx0(3);     % Initial x-velocity
    y0_dot = xx0(4);     % Initial y-velocity
    t_i = x(5);          % Initial time
    t_f = x(6);          % Final time

    % Calculate the delta-v required at the initial orbit
    % dv1: Change in velocity to match the initial orbit's velocity
    
    dv1 = sqrt((x0_dot - y0)^2 + (y0_dot + x0 + mu)^2) - sqrt((1 - mu) / r0);

    % Propagate the state from t_i to t_f
    [~, xxf] = propagate4BP(t_i, xx0, t_f, parameters); % xxf contains the states at all time steps

    % Extract the final state from the propagation result
    xf = xxf(end, 1);       % Final x-coordinate
    yf = xxf(end, 2);       % Final y-coordinate
    xf_dot = xxf(end, 3);   % Final x-velocity
    yf_dot = xxf(end, 4);   % Final y-velocity

    % Calculate the delta-v required at the final orbit
    % dv2: Change in velocity to match the final orbit's velocity
    
    dv2 = sqrt((xf_dot - yf)^2 + (yf_dot + xf + mu - 1)^2) - sqrt(mu / rf);

    % Calculate the total delta-v
    dv_tot = dv1 + dv2;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dv_tot, grad] = cost_function2(parameters, x)
    % COST_FUNCTION2 Computes the total delta-v and its gradient for a transfer orbit
    % in the Circular Restricted 4-Body Problem (CR4BP).
    %
    % Inputs:
    %   parameters - Structure containing problem-specific constants:
    %                mu  - Mass ratio between the two primary bodies,
    %                r0  - Radius of the initial circular orbit,
    %                rf  - Radius of the final circular orbit.
    %   x          - Design variable vector [x0, y0, vx0, vy0, t_i, t_f], where:
    %                x0, y0     - Initial position in the rotating frame,
    %                vx0, vy0   - Initial velocity in the rotating frame,
    %                t_i, t_f   - Initial and final time of the transfer.
    %
    % Outputs:
    %   dv_tot     - Total delta-v (scalar).
    %   grad       - Gradient of the total delta-v with respect to design variables
    %                [∂dv_tot/∂x0, ∂dv_tot/∂y0, ∂dv_tot/∂vx0, ∂dv_tot/∂vy0,
    %                ∂dv_tot/∂t_i, ∂dv_tot/∂t_f] (optional, computed if requested).

    % Extract parameters
    mu = parameters.mu;  % Mass ratio between the two primary bodies
    r0 = parameters.r0;  % Radius of the initial circular orbit
    rf = parameters.rf;  % Radius of the final circular orbit
  
    % Extract the initial state and time variables
    xx0 = x(1:4);   % Initial state vector [x0, y0, vx0, vy0]
    xi = xx0(1);    % Initial x-coordinate
    yi = xx0(2);    % Initial y-coordinate
    vxi = xx0(3);   % Initial x-velocity
    vyi = xx0(4);   % Initial y-velocity
    t_i = x(5);     % Initial time
    t_f = x(6);     % Final time

    % Propagate the state from t_i to t_f using the state transition matrix
    [~, xxf, PHI] = propagate4BP_STM(t_i, xx0, t_f, parameters);

    % Extract the final state from the propagation
    xf = xxf(end, 1);    % Final x-coordinate
    yf = xxf(end, 2);    % Final y-coordinate
    vxf = xxf(end, 3);   % Final x-velocity
    vyf = xxf(end, 4);   % Final y-velocity
    
    xx2 = [xf, yf, vxf, vyf]'; % Final state vector
    
    % Compute the gradient if requested
    if nargout > 1
        % Compute the partial derivatives of dv1 with respect to the initial state
        dfdx = 1 / sqrt((vxi - yi)^2 + (vyi + xi + mu)^2) * ...
               [vyi + xi + mu; yi - vxi; vxi - yi; vyi + xi + mu] + ...
               PHI' * 1 / sqrt((vxf - yf)^2 + (vyf + xf + mu - 1)^2) * ...
               [vyf + xf + mu - 1; yf - vxf; vxf - yf; vyf + xf + mu - 1];

        % Compute the partial derivatives of dv2 with respect to the final state
        dDvfdxf = 1 / sqrt((vxf - yf)^2 + (vyf + xf + mu - 1)^2) * ...
                  [vyf + xf + mu - 1; yf - vxf; vxf - yf; vyf + xf + mu - 1];

        % Compute the time derivatives
        ds_ti = CR4BP(t_i, xx0, parameters, 0); % State derivative at t_i
        dfdti = -dDvfdxf' * PHI * ds_ti;    % Partial derivative with respect to t_i

        ds_tf = CR4BP(t_f, xx2, parameters, 0); % State derivative at t_f
        dfdtf = dDvfdxf' * ds_tf;           % Partial derivative with respect to t_f

        % Combine all gradients
        grad = [dfdx; dfdti; dfdtf];
    end

    % Compute the delta-v at the initial point
    dv1 = sqrt((vxi - yi)^2 + (vyi + xi + mu)^2) - sqrt((1 - mu) / r0);

    % Compute the delta-v at the final point
    dv2 = sqrt((vxf - yf)^2 + (vyf + xf + mu - 1)^2) - sqrt(mu / rf);

    % Compute the total delta-v
    dv_tot = dv1 + dv2;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [c, ceq, dC, dCeq] = constraints2(parameters, x)
    % CONSTRAINTS2 Computes the equality constraints and their gradients for an orbit transfer problem.
    %
    % Inputs:
    %   parameters - Structure containing problem-specific constants:
    %                mu  - Mass ratio between the two primary bodies,
    %                r0  - Radius of the initial circular orbit,
    %                rf  - Radius of the final circular orbit.
    %   x          - Design variable vector [x0, y0, vx0, vy0, t_i, t_f], where:
    %                x0, y0     - Initial position in the rotating frame,
    %                vx0, vy0   - Initial velocity in the rotating frame,
    %                t_i, t_f   - Initial and final time of the transfer.
    %
    % Outputs:
    %   c          - Inequality constraints (empty in this case, as there are none).
    %   ceq        - Equality constraints as a column vector.
    %   dC         - Gradient of the inequality constraints with respect to the design variables
    %                (empty in this case, as there are no inequality constraints).
    %   dCeq       - Gradient of the equality constraints with respect to the design variables.
    

    % Extract parameters
    mu = parameters.mu;  % Mass ratio between the two primary bodies
    r0 = parameters.r0;  % Radius of the initial circular orbit
    rf = parameters.rf;  % Radius of the final circular orbit

    % Extract initial state and time variables
    xx0 = x(1:4);  % Initial state vector [x0, y0, vx0, vy0]
    xi = xx0(1);   % Initial x-coordinate
    yi = xx0(2);   % Initial y-coordinate
    vxi = xx0(3);  % Initial x-velocity
    vyi = xx0(4);  % Initial y-velocity
    t_i = x(5);    % Initial time
    t_f = x(6);    % Final time

    % Propagate the state from t_i to t_f using the state transition matrix
    [~, xxf, PHI] = propagate4BP_STM(t_i, xx0, t_f, parameters);

    % Extract the final state from the propagation
    xf = xxf(end, 1);    % Final x-coordinate
    yf = xxf(end, 2);    % Final y-coordinate
    vxf = xxf(end, 3);   % Final x-velocity
    vyf = xxf(end, 4);   % Final y-velocity

    % Final state vector
    xx2 = [xf, yf, vxf, vyf]';

    % Define equality constraints based on orbital mechanics
    ceq1 = (xi + mu)^2 + yi^2 - r0^2;                     % Initial position constraint (circular orbit)
    ceq2 = (xi + mu) * (vxi - yi) + yi * (vyi + xi + mu);   % Initial velocity constraint (circular orbit)
    ceq3 = (xf + mu - 1)^2 + yf^2 - rf^2;                   % Final position constraint (circular orbit)
    ceq4 = (xf + mu - 1) * (vxf - yf) + yf * (vyf + xf + mu - 1); % Final velocity constraint (circular orbit)

    % Combine the constraints into a single column vector
    ceq = [ceq1; ceq2; ceq3; ceq4];

    % No inequality constraints in this case, so c is an empty array
    c = t_i - t_f;  % This ensures that the initial time t_i and final time t_f are equal

    % Compute gradients if requested (nargout > 2)
    if nargout > 2
        % Compute state derivatives at initial and final times using CR4BP dynamics
        ds1 = CR4BP(t_i, xx0, parameters, 0);  % Initial state derivative of the transfer trajectory
        ds2 = CR4BP(t_f, xx2, parameters, 0);  % Final state derivative of the transfer trajectory

        % Compute the gradient of the equality constraints with respect to the initial state (xi, yi, vxi, vyi)
        dCeqdx1 = [2*(xi + mu), 2*yi, 0, 0;
                   vxi, vyi, xi + mu, yi];  % Gradient for constraint ceq1 and ceq2

        % Compute the gradient of the equality constraints with respect to the final state (xf, yf, vxf, vyf)
        dCeqdx2 = [2*(xf + mu - 1), 2*yf, 0, 0;
                   vxf, vyf, xf + mu - 1, yf];  % Gradient for constraint ceq3 and ceq4

        % Combine the gradients to form the overall constraint Jacobian matrix
        dCeq = [dCeqdx1, zeros(2, 2);   % Partial derivatives for initial state constraints
                dCeqdx2 * PHI, -dCeqdx2 * PHI * ds1, dCeqdx2 * ds2]';  % Partial derivatives for final state constraints

        % Gradient of the inequality constraints 
        dC = [0 0 0 0 1 -1]';  % Gradient for the time equality constraint (t_i - t_f)

    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dv_tot, grad] = MultiShootingCost(parameters, x)
    % MultiShootingCost calculates the total delta-v and its gradient for a 
    % multiple shooting optimization problem.
    %
    % Inputs:
    %   parameters - struct containing parameters such as mu, r0, rf
    %   x - optimization variables vector, including initial and final states 
    %       and times for multiple shooting
    %
    % Outputs:
    %   dv_tot - total delta-v required for the transfer
    %   grad - gradient of the delta-v with respect to the optimization variables

    mu = parameters.mu; % Gravitational parameter
    r0 = parameters.r0; % Initial orbit radius
    rf = parameters.rf; % Final orbit radius

    % Number of time instants for multiple shooting
    N = (length(x) - 2) / 4;

    % Extract initial state (position and velocity) and final state
    x1 = x(1);      % Initial x position
    y1 = x(2);      % Initial y position
    vx1 = x(3);     % Initial x velocity
    vy1 = x(4);     % Initial y velocity

    xN = x(end-5);  % Final x position
    yN = x(end-4);  % Final y position
    vxN = x(end-3); % Final x velocity
    vyN = x(end-2); % Final y velocity

    % OBJECTIVE FUNCTION (Total Delta-v)
    % Calculate the initial and final delta-v components
    Dvi = sqrt((vx1 - y1)^2 + (vy1 + x1 + mu)^2) - sqrt((1 - mu) / r0);  % Initial delta-v
    Dvf = sqrt((vxN - yN)^2 + (vyN + xN + mu - 1)^2) - sqrt(mu / rf);      % Final delta-v

    % Total delta-v is the sum of initial and final delta-v components
    dv_tot = Dvi + Dvf;

    % If gradient is requested, calculate the gradient of the objective function
    if nargout > 1
        % Gradient with respect to initial state
        dfdx1 = 1 / sqrt((vx1 - y1)^2 + (vy1 + x1 + mu)^2) * ...
                [vy1 + x1 + mu; y1 - vx1; vx1 - y1; vy1 + x1 + mu];

        % Gradient with respect to final state
        dfdxN = 1 / sqrt((vxN - yN)^2 + (vyN + xN + mu - 1)^2) * ...
                [vyN + xN + mu - 1; yN - vxN; vxN - yN; vyN + xN + mu - 1];

        % Concatenate gradients for initial and final states
        grad = [dfdx1; zeros(N * 2, 1); dfdxN; 0; 0];
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [c, ceq, dC, dCeq] = constraintsMulti(parameters, x, R, DU)
    % constraintsMulti defines the non-linear constraints for a multiple shooting 
    % optimization scheme in the CR4BP problem. The constraints include:
    % - Initial and final position and velocity constraints
    % - Inequality constraints related to physical boundaries (Earth and Moon)
    % - Gradients of the constraints if required
    %
    % Inputs:
    %   parameters - struct containing problem parameters such as mu, r0, rf
    %   x - optimization vector (initial and final states, times, and intermediate states)
    %   R - vector containing the Earth and Moon radii [R_E, R_M]
    %   DU - scaling factor for distance units
    %
    % Outputs:
    %   c - inequality constraints (positions relative to Earth and Moon)
    %   ceq - equality constraints (position and velocity matching, boundary conditions)
    %   dC - gradient of inequality constraints with respect to optimization variables
    %   dCeq - gradient of equality constraints with respect to optimization variables

    mu = parameters.mu;  % Gravitational parameter
    r0 = parameters.r0;  % Initial orbit radius
    rf = parameters.rf;  % Final orbit radius

    % Extract Earth and Moon radii
    R_E = R(1);  % Earth radius
    R_M = R(2);  % Moon radius

    % Number of time instants for multiple shooting (derived from length of x)
    N = (length(x) - 2) / 4;

    % Extract initial and final times, positions, and velocities
    t1 = x(end-1);   % Initial time
    tN = x(end);     % Final time
    x1 = x(1);       % Initial x position
    y1 = x(2);       % Initial y position
    vx1 = x(3);      % Initial x velocity
    vy1 = x(4);      % Initial y velocity

    xN = x(end-5);   % Final x position
    yN = x(end-4);   % Final y position
    vxN = x(end-3);  % Final x velocity
    vyN = x(end-2);  % Final y velocity

    % Linearly interpolate time for each shooting interval
    t = linspace(t1, tN, N);  % Interpolated time vector

    % Initialize equality constraint vector for positions and velocities
    ceq = zeros(4*N, 1);

    % Initial radial position and velocity constraints (parking orbit)
    ceq(end-3) = (x1 + mu)^2 + y1^2 - r0^2;  % Radial distance constraint
    ceq(end-2) = (x1 + mu) * (vx1 - y1) + y1 * (vy1 + x1 + mu);  % Velocity constraint

    % Final radial position and velocity constraints (target orbit)
    ceq(end-1) = (xN + mu - 1)^2 + yN^2 - rf^2;  % Radial distance constraint
    ceq(end) = (xN + mu - 1) * (vxN - yN) + yN * (vyN + xN + mu - 1);  % Velocity constraint

    % Inequality constraints for positions relative to Earth and Moon (boundary conditions)
    c = zeros(2*N + 1, 1);  % Initialize inequality constraint vector
    c(1:2, 1) = [(R_E/DU)^2 - (x1 + mu)^2 - y1^2;  % Earth boundary constraint
                (R_M/DU)^2 - (x1 + mu - 1)^2 - y1^2];  % Moon boundary constraint

    % Propagate states and apply constraints for each shooting interval
    for j = 1:N-1
        % Extract current and next state in the optimization vector
        xxjj = x(4*j + 1 : 4*j + 4);  % Next state
        xxj = x(4*j-3 : 4*j);  % Current state

        % Propagate state over the current interval using the CR3BP dynamics
        [~, xx] = propagate4BP(t(j), xxj, t(j+1), parameters);

        % Set continuity constraint between consecutive intervals (matching positions and velocities)
        ceq(4*j-3 : 4*j) = xx(end, 1:4)' - xxjj;  % Matching positions and velocities at the interval boundary

        % Update inequality constraints for position bounds relative to Earth and Moon
        xj = xxjj(1);  % Current x position
        yj = xxjj(2);  % Current y position
        c(2*j+1 : 2*j+2) = [(R_E/DU)^2 - (xj + mu)^2 - yj^2;  % Earth boundary constraint for this interval
                            (R_M/DU)^2 - (xj + mu - 1)^2 - yj^2];  % Moon boundary constraint for this interval
    end 

    % Final time constraint (initial time must be less than final time)
    c(end) = t1 - tN;

    % Calculate gradients if requested (using partial derivatives)
    if nargout > 2
        % Initialize gradient vectors for the constraints
        Q1 = zeros(4*(N-1), 1);
        QN = zeros(4*(N-1), 1);
        
        % Initialize Jacobian matrices for the constraints
        dCeq = zeros(3*N + 4, 4*N + 2);
        dC = zeros(2*N + 1, 4*N + 2);
        
        for j = 1:N-1
            % Extract current interval state for gradient calculation
            xxj = x(4*j-3 : 4*j);  % Current state
            xj = xxj(1);  % Current x position
            yj = xxj(2);  % Current y position

            % Propagate state and get RHS of the CR3BP system at this interval
            [~, xx, PHI] = propagate4BP_STM(t(j), xxj, t(j+1), parameters);  % State and STM
            RHSj = CR4BP(t(j), xxj, parameters, 0);  % Right-hand side of the CR3BP system
            RHSjj = CR4BP(t(j+1), xx(end, :), parameters, 0);  % Right-hand side at the next interval

            % Compute continuity constraint gradients (matching positions and velocities)
            Q1(4*j-3 : 4*j) = -(N-j)/(N-1) * PHI * RHSj + (N-j-1)/(N-1) * RHSjj;  % Continuity for current interval
            QN(4*j-3 : 4*j) = -(j-1)/(N-1) * PHI * RHSj + j/(N-1) * RHSjj;  % Continuity for next interval

            % Update Jacobians for equality constraints (matching positions and velocities)
            dCeq(4*j-3: 4*j, 4*j+1:  4*j + 4) = -eye(4);  % Matching positions and velocities
            dCeq(4*j-3: 4*j, 4*j-3 : 4*j) = PHI;  % State-to-state derivative

            % Update Jacobians for inequality constraints (Earth and Moon boundaries)
            dC(2*j-1: 2*j, 4*j-3:  4*j) = [-2*(xj + mu), -2*yj, 0, 0;  % Earth boundary constraint Jacobian
                                           -2*(xj + mu - 1), -2*yj, 0, 0];  % Moon boundary constraint Jacobian
        end

        % Final inequality constraint Jacobian contributions (Earth and Moon)
        dC(2*N-1:2*N, 4*N-3:4*N) = [-2*(xN + mu), -2*yN, 0, 0;  % Earth boundary final Jacobian
                                    -2*(xN + mu - 1), -2*yN, 0, 0];  % Moon boundary final Jacobian
        dC(end, end-1:end) = [1 -1];  % Time constraint Jacobian

        % Combine the Jacobian matrices
        dC = dC';  % Transpose Jacobian for inequality constraints
        dCeq(1:4*(N-1), end-1:end) = [Q1, QN];  % Combine continuity gradients

        % Final Jacobian for equality constraints
        dPHI1dx1 = [2*(x1 + mu), 2*y1, 0, 0; vx1, vy1, (x1 + mu), y1];  % Initial state Jacobian
        dPHI2dx2 = [2*(xN + mu - 1), 2*yN, 0, 0; vxN, vyN, (xN + mu - 1), yN];  % Final state Jacobian
        dPHI = [dPHI1dx1, zeros(2, 3*N+2); zeros(2, 3*N), dPHI2dx2, zeros(2,2)];  % Total Jacobian
        dCeq(end-3:end, :) = dPHI;  % Add Jacobian to the equality constraint gradients

        % Transpose the equality constraint Jacobian matrix
        dCeq = dCeq';
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = nbodyShiftRHS(t, x, bodies, frame, center)
%NBODYSHIFTRHS Evaluates the right-hand-side of a N-body propagator
%   Evaluates the right-hand-side of a newtonian N-body propagator.
%   The integration centre is the can be decided by the user changing the 
%   body contained into the struct center.
%
% Inputs:
%   t      : [1,1] ephemeris time (ET SPICE), seconds past J2000 (TDB)
%   x      : [6,1] cartesian state vector wrt desired object
%   bodies : [1,n] cell-array created with function nbody_init
%
% Outputs:
%   dxdt   : [6,1] RHS, newtonian gravitational acceleration only

if not( strcmpi(frame, 'ECLIPJ2000') || strcmpi(frame, 'J2000') )
    msg = 'Invalid integration reference frame, select either J2000 or ECLIPJ2000';
    error(msg);
end

dxdt = zeros(6,1);
dxdt(1:3) = x(4:6);

% Extract the object position from state x

rr_center_obj = x(1:3);

% Extract GM of central body GM0

for i = 1:length(bodies)
    value = strcmpi(center,bodies{i}.name);
    if value == 1
        center_index = i;
        GM0 = bodies{i}.GM;
    end
end


% Compute contribution to acceleration of central body
dist2 = dot(rr_center_obj, rr_center_obj);
dist = sqrt(dist2);

aa_grav_center =  - GM0 * rr_center_obj /(dist*dist2);

% Loop over all bodies (except GM0)
    
for i = 1:length(bodies)

    if i ~= center_index

        % Retrieve position and velocity of i-th celestial body wrt desired
        % center in inertial frame:
        rv_center_body = cspice_spkezr(bodies{i}.name, t, frame, 'NONE', center);
        
        % Extract object position wrt. i-th celestial body
        rho = rv_center_body(1:3);

        rr_body_obj = rr_center_obj - rv_center_body(1:3);

        % Compute non-inertial terms as in the slides (d, rho, q, f):
        d = rr_body_obj ;

        q = dot(rr_center_obj,(rr_center_obj-2*rho)) / dot(rho, rho);

        f = q * (3 + 3*q + q^2) / (1 + (1 + q) ^ (3/2));

        dist2_d = dot(d,d);
        dist_d = sqrt(dist2_d);
        
        % Compute their contribution to acceleration:
        aa_grav_i = -bodies{i}.GM / (dist2_d * dist_d) * (rr_center_obj + rho * f) ;

        dxdt(4:6) = dxdt(4:6) + aa_grav_i;
    end
    
end

% Sum up acceleration to right-hand-side
dxdt(4:6) = dxdt(4:6) + aa_grav_center;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function fun = thetaFinder(theta_target, et_vec, bodies, frame, center)
% This function calculates the angular difference (theta) between the Sun 
% and the Moon relative to a central body (Earth or another planet) in a 
% specified reference frame. It then computes the difference between the 
% computed angular difference and a target angular difference (theta_target).

% INPUTS:
%   theta_target - Target angular difference between the Sun and Moon [rad]
%   et_vec       - Array of ephemeris times [s]
%   bodies       - Cell array containing the body structures (e.g., Sun, Earth, Moon)
%   frame        - Reference frame for the positions (e.g., 'J2000', 'EME2000')
%   center       - Central body for the positions (e.g., 'EARTH')

% OUTPUT:
%   fun - Difference between the computed theta angle and the target angle

% Initialize arrays to store positions of the Sun and Moon in the ECI frame
sunPosECI = zeros(3, length(et_vec));  % Sun's position in ECI frame
moonPosECI = zeros(3, length(et_vec)); % Moon's position in ECI frame

% Loop through the ephemeris times and compute positions of Sun and Moon
for i = 1:length(et_vec)
    % Get the Sun's position in the specified reference frame relative to the center
    sunPosECI(:, i) = cspice_spkpos(bodies{1}.name, et_vec(i), frame, 'NONE', center);
    
    % Get the Moon's position in the specified reference frame relative to the center
    moonPosECI(:, i) = cspice_spkpos(bodies{3}.name, et_vec(i), frame, 'NONE', center);
end

% Extract only the x and y coordinates (2D plane) for Sun and Moon
sunPosEMB = sunPosECI(1:2, :); 
moonPosEMB = moonPosECI(1:2, :);

% Compute the angle of the Sun's position relative to the x-axis
theta_sun = atan2(sunPosEMB(2, :), sunPosEMB(1, :));

% Compute the angle of the Moon's position relative to the x-axis
theta_moon = atan2(moonPosEMB(2, :), moonPosEMB(1, :));

% Compute the angular difference between the Sun and Moon
theta = theta_sun - theta_moon;

% Wrap the angle theta between 0 and 2*pi for consistency
theta = wrapTo2Pi(theta);

% Compute the difference between the computed angle and the target angle
fun = theta - theta_target;

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [bodies] = nbody_init(labels)
%NBODY_INIT Initialize planetary data for n-body propagation
%   Given a set of labels of planets and/or barycentres, returns a
%   cell array populated with structures containing the body label and the
%   associated gravitational constant.
%
%
% Author
%   Name: ALESSANDRO 
%   Surname: MORSELLI
%   Research group: DART
%   Department: DAER
%   University: Politecnico di Milano 
%   Creation: 26/09/2021
%   Contact: alessandro.morselli@polimi.it
%   Copyright: (c) 2021 A. Morselli, Politecnico di Milano. 
%                  All rights reserved.
%
%
% Notes:
%   This material was prepared to support the course 'Satellite Guidance
%   and Navigation', AY 2021/2022.
%
%
% Inputs:
%   labels : [1,n] cell-array with object labels
%
% Outputs:
%   bodies : [1,n] cell-array with struct elements containing the following
%                  fields
%                  |
%                  |--bodies{i}.name -> body label
%                  |--bodies{i}.GM   -> gravitational constant [km**3/s**2]
%
%
% Prerequisites:
%   - MICE (Matlab SPICE)
%   - Populated kernel pool (PCK kernels)
%

% Initialize output
bodies = cell(size(labels));

% Loop over labels
for i = 1:length(labels)
    % Store body label
    bodies{i}.name = labels{i};
    % Store body gravitational constant
    bodies{i}.GM   = cspice_bodvrd(labels{i}, 'GM', 1);
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
