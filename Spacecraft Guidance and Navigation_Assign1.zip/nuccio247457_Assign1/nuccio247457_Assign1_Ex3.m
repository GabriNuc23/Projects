% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 1, Exercise 3
% Author: Gabriele Nuccio

clc
clearvars
close all


applyDefaultSettings();
format long g
rng default;
%% 3.1

% Initial Data
e_i = 0; % Initial Eccentricity [-]
i_i = 0; % Initial Inclination [rad]
h_i = 800; % Altitude of departure orbit [km]
h_f = 1000; % Altitude of arrival orbit [km]
i_f = deg2rad(0.75); % Final Inclination [rad]
delta_i = i_f - i_i; % Inclination Change [rad]
g0 = 9.81; % Earth gravitational constant [m/s^2]

R_E = 6378.1366; % Earth Radius [km]
mu = 398600.435; % Earth gravitational parameter [km^3/s^2]
rho0 =  750 + R_E; % Reference radius for debris flux [km]
k1 = 1e-5; % Debris spatial density constant 1 [DU^-1]
k2 = 1e-4; % Debris spatial density constant 2 [DU^2]
m0 = 1000; % Initial mass [kg]
Tmax = 3; % Maximum thrust [N]
Isp = 3120; % Specific Impulse [s]
DU = 7178.1366; % Distance Unit [km]
MU = m0; % Mass Unit [kg]

% Compute the Spatial Density q
q = @(rho) k1./(k2 + ((rho-rho0)/DU).^2);

% Define the vector of altitudes to plot the density
h_vec = linspace(h_i - 100, h_f + 100, 1000);
rho_vec = R_E + h_vec;

% Plot the debris density
figure();
plot(rho_vec-R_E, q(rho_vec), 'LineWidth',3);
xline(800, '--k','LineWidth',4)
xline(750, '--r', 'LineWidth',4)
xline(1000, '--b', 'LineWidth',4)
legend('', 'Initial Altitude', 'Reference Altitude', 'Final Altitude')
xlabel('Radius Interval [km]')
ylabel('Debris Spatial Density [$DU^{-3}$]')
% xlim([rho_vec(1), rho_vec(end)]);

% Compute intial and final state
r_i = R_E + h_i;
r_f = R_E + h_f;

r_i_vec = [r_i, 0, 0]';
v_i_vec = [0, sqrt(mu/r_i), 0]';
r_f_vec = [r_f, 0, 0]';
v_f_vec = [0, sqrt(mu/r_f) * cos(delta_i), sqrt(mu/r_f) * sin(delta_i)]';

InitialStateDim = [r_i_vec; v_i_vec];
FinalStateDim = [r_f_vec; v_f_vec];

%% 3.2
% Adimensionalize
r_i_vec_norm = r_i_vec/DU;
r_f_vec_norm = r_f_vec/DU;
TU = sqrt(DU^3/mu);
VU = DU/TU;
h_i = h_i/DU;
h_f = h_f/DU;
v_i_vec_norm = v_i_vec/VU;
v_f_vec_norm = v_f_vec/VU;
m0 = m0/MU;

% Adimensionalized State
InitialState = [r_i_vec_norm; v_i_vec_norm;m0];
FinalState = [r_f_vec_norm; v_f_vec_norm];

% Adimensionalized Parameters
Isp = Isp/TU;
Tmax = Tmax * TU^2/MU * 1/(DU*1e3);
mu = 1;
g0 = g0 * (TU^2)/(DU * 1e3);
rho0 = rho0/DU;

%% 3.4

% Define initial guess for final time
tf0 = 20 * pi;
t0 = 0;

% Vector of parameters
parameters(1) = Tmax;
parameters(2) = mu;
parameters(3) = Isp;
parameters(4) = g0;
parameters(5) = k1;
parameters(6) = k2;
parameters(7) = rho0;



[lambda_guess, tf_guess] = objectiveFunction(tf0, InitialState, FinalState, parameters);


% Compute the error with respect to Final state
[tt, xx] = eulerLagrangePropagator(t0, InitialState, lambda_guess, tf_guess, parameters);
errore = xx(end,1:6)'- FinalState;
errPos = norm(errore(1:3)) * DU;
errVel = norm(errore(4:6)) * VU * 1e3;
r = xx(:,1:3);
v = xx(:,4:6);
m = xx(:,7);
lambda_r = xx(:,8:10);
lambda_v = xx(:,11:13);
lambda_m = xx(:,14);

H = zeros(length(tt),1);

% Compute the Hamiltonian 
for i = 1:length(tt)
   r_n = norm(r(i,:));
   lambda_v_n = norm(lambda_v(i,:));
   q = k1/(k2 + (r_n - rho0)^2);
   H(i) = q + dot(lambda_r(i,:), v(i,:)) - mu/r_n^3 * dot(lambda_v(i,:), r(i,:)) - Tmax/m(i) * lambda_v_n - lambda_m(i) * Tmax/(Isp * g0);
end

figure();
plot(tt, H)
xlabel('Time [TU]');
ylabel('Hamiltonian [$DU^{-3}$]');

% Compute the alpha direction
alpha = - lambda_v./(vecnorm(lambda_v'))';

alphaNTW = zeros(length(tt),3);
for j = 1:length(tt)
   rVec = xx(j,1:3)';
   vVec = xx(j,4:6)';
   
   alphaNTW(j,:) = rotECItoNTW(rVec, vVec, alpha(j,:)');
end

figure();
plot(tt, alphaNTW(:,1))
hold on
plot(tt, alphaNTW(:,2))
plot(tt, alphaNTW(:,3))
xlabel('Time [TU]');
ylabel('Alpha [-]');
legend('N Component', 'T Component', 'W Component')

figure();
plot3(xx(:,1), xx(:,2), xx(:,3));
xlabel('X Position [DU]')
ylabel('Y Position [DU]')
zlabel('Z Position [DU]')
%% 3.5

% Define the vector of Thrust
T_end = 2.860 * TU ^ 2 / (MU * DU * 10^3);
TVec = linspace(Tmax, T_end, 10);
guess = [lambda_guess; tf_guess];

% Define options
options2 = optimoptions('fsolve', 'OptimalityTolerance', 1e-10, ...     % Tolerance for the first-order optimality
    'FunctionTolerance', 1e-10, ...       % Tolerance for the function value
    'StepTolerance', 1e-12, ...
    'Display','iter-detailed','Algorithm', 'trust-region-dogleg','MaxFunctionEvaluations', 10000, 'MaxIterations', 1000, 'SpecifyObjectiveGradient',true);

sol(:,1) = guess;      
fval(:,1) = zeros(8,1);

% Find the solutions for each Thrust
for i = 2 : length(TVec)

    parameters(1) = TVec(i);
    
    fun = @(var) equations(t0, InitialState, FinalState, var, parameters);

    [sol(:,i), fval(:,i)] = fsolve(fun,guess,options2);

    guess=sol(:,i);
    
end

% Compute the error with respect to Final state
[tt5, xx5] = eulerLagrangePropagator(t0, InitialState, guess(1:7), guess(8), parameters);

errore5 = xx5(end,1:6)'- FinalState;
errPos5 = norm(errore5(1:3))*DU;
errVel5 = norm(errore5(4:6))*VU*1e3;

lambda_v2 = xx5(:,11:13);
alpha2 = - lambda_v2./(vecnorm(lambda_v2'))';
alphaNTW2 = zeros(length(tt5),3);
for j = 1:length(tt5)
   rVec = xx5(j,1:3)';
   vVec = xx5(j,4:6)';
   
   alphaNTW2(j,:) = rotECItoNTW(rVec, vVec, alpha2(j,:)');
end

figure();
plot(tt5, alphaNTW2(:,1))
hold on
plot(tt5, alphaNTW2(:,2))
plot(tt5, alphaNTW2(:,3))
xlabel('Time [TU]');
ylabel('Alpha [-]');
legend('N Component', 'T Component', 'W Component')
%% FUNCTIONS
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',20);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = eulerLagrangeEquation(~, x, parameters)
% eulerLagrangeEquation Computes the time derivatives of states, costates, and STM
%                       using the Euler-Lagrange equations for optimal control.
%
% Inputs:
%   ~           - Placeholder for time variable (not used, as the equations are autonomous).
%   x           - Combined state vector, including:
%                 [state; costate; flattened state-transition matrix (STM)]:
%                 - state: [r (position); v (velocity); m (mass)]
%                 - costate: [lambda_r; lambda_v; lambda_m]
%                 - flattened STM: 14x14 matrix reshaped into a column vector.
%   parameters  - Array of problem-specific parameters, including:
%                 parameters(1) = Tmax (maximum thrust),
%                 parameters(2) = mu (gravitational parameter),
%                 parameters(3) = Isp (specific impulse),
%                 parameters(4) = g0 (standard gravity),
%                 parameters(5) = k1 (density scaling factor 1),
%                 parameters(6) = k2 (density scaling factor 2),
%                 parameters(7) = rho0 (reference density).
%
% Outputs:
%   dxdt        - Time derivatives of the combined state vector, including:
%                 [state derivatives; costate derivatives; STM derivatives]

% Extract parameters
Tmax = parameters(1);
mu = parameters(2);
Isp = parameters(3);
g0 = parameters(4);
k1 = parameters(5);
k2 = parameters(6);
rho0 = parameters(7);

% Extract states and costates from x
r = x(1:3);
v = x(4:6);
m = x(7);
lambda_r = x(8:10);
lambda_v = x(11:13);
% lambda_m = x(14);

r_norm = norm(r);
lambda_v_norm = norm(lambda_v);

% Initialize dxdt (size matches x)
dxdt = zeros(210,1);

% Compute state derivatives
dxdt(1:3) = v;
dxdt(4:6) = -mu/(r_norm^3) * r - Tmax/m * lambda_v/(lambda_v_norm);
dxdt(7) = -Tmax/(Isp*g0);

% Compute density gradient term dq/dx
dqdx = [(2*k1*r(1)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2));
        (2*k1*r(2)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2));
        (2*k1*r(3)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2))];

% Compute costate derivatives
dxdt(8:10) = - 3 * mu/(r_norm^5) * (dot(r,lambda_v)) * r + mu/r_norm^3 * lambda_v - dqdx;
dxdt(11:13) = -lambda_r;
dxdt(14) = - lambda_v_norm * Tmax/(m^2);

% Extract the STM (State-Transition Matrix) from x and reshape it
PHI0 = reshape(x(15:end),14,14);

% Compute the Jacobian of the system
J = jacobian(x(1:14), parameters);

% Compute the derivative of the STM
PHIdot = J*PHI0;

% Flatten the STM derivative and store it in dxdt
dxdt(15:end) = PHIdot(:);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx, PHIf] = eulerLagrangePropagator(t0, xx0, lambda0, tf, parameters)
% eulerLagrangePropagator Propagates the state, costates, and state-transition matrix
%                         using the Euler-Lagrange equations over a given time interval.
%
% Inputs:
%   t0          - Initial time (e.g., 0).
%   xx0         - Initial state vector (e.g., position, velocity, and mass).
%   lambda0     - Initial costate vector (e.g., adjoint variables for state variables).
%   tf          - Final time (time interval [t0, tf] will be used for propagation).
%   parameters  - Struct or array containing problem-specific parameters needed for propagation.
%
% Outputs:
%   tt          - Time vector corresponding to the solution trajectory.
%   xx          - Solution trajectory, including states, costates, and flattened STM.
%                 Each row corresponds to a time step, and the columns represent:
%                 [state; costate; flattened state-transition matrix (STM)].
%   PHIf        - Final state-transition matrix (STM), reshaped from the propagated trajectory.

   % Initialize state-transition matrix (STM) as the identity matrix
    Phi0 = eye(14);
   % Set options for the ODE solver
    optset = odeset('reltol', 1e-12, 'abstol', 1e-12);

     % Combine initial state, costates, and flattened STM into the initial guess vector
    InitialGuess = [xx0; lambda0; Phi0(:)];

     % Define the system of ODEs to be solved using Euler-Lagrange equations
    fun = @(t,x) eulerLagrangeEquation(t,x, parameters);

    % Integrate the system of ODEs over the interval [t0, tf] using ode113
    [tt, xx] = ode113(fun, [t0 tf], InitialGuess, optset);

    % Extract and reshape the final state-transition matrix (STM) from the solution
    PHIf = reshape(xx(end,15:end),14,14);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [fun, grad] = equations(t0, InitialState, FinalState, var, parameters)
% equations Defines the system of equations for the two-point boundary value problem 
%           and computes the gradient for optimization purposes.
%
% Inputs:
%   t0          - Initial time (typically set to 0).
%   InitialState - Initial state vector (e.g., initial position, velocity, mass, etc.).
%   FinalState  - Desired final state vector (e.g., target position and velocity).
%   var         - Vector of optimization variables [lambda0; tf], where:
%                   lambda0 - Initial costate vector (size depends on problem).
%                   tf      - Final time.
%   parameters  - Array of problem-specific parameters, including:
%                 parameters(1) = Tmax (maximum thrust),
%                 parameters(2) = mu (gravitational constant),
%                 parameters(3) = Isp (specific impulse),
%                 parameters(4) = g0 (standard gravity),
%                 parameters(5) = k1 (density scaling factor 1),
%                 parameters(6) = k2 (density scaling factor 2),
%                 parameters(7) = rho0 (reference density).
%
% Outputs:
%   fun         - Vector of residuals for the equations:
%                   - Boundary conditions for the state (position and velocity).
%                   - Transversality condition for lambda_m.
%                   - Hamiltonian condition for optimality.
%   grad        - Gradient (Jacobian) of the equations for optimization.


lambda0 = var(1:end-1);
tf = var(end);

Tmax = parameters(1);
mu = parameters(2);
Isp = parameters(3);
g0 = parameters(4);
k1 = parameters(5);
k2 = parameters(6);
rho0 = parameters(7);

% Propagate the Euler-Lagrange equations using the given inputs
[~,xx, PHIf] = eulerLagrangePropagator(t0, InitialState, lambda0, tf, parameters);

xf = xx(end,:)';

% Split the final state into components
r = xf(1:3);
v = xf(4:6);
m = xf(7);
lambda_r = xf(8:10);
lambda_v = xf(11:13);
lambda_m = xf(14);

r_norm = norm(r);
lambda_v_norm = norm(lambda_v);

% Compute density scaling factor
q = k1/(k2 + (r_norm - rho0)^2);

% Compute the Hamiltonian
H = q + dot(lambda_r, v) - mu/r_norm^3 * dot(lambda_v, r) - Tmax/m * lambda_v_norm - lambda_m * Tmax/(Isp * g0);

% Boundary condition residuals
Bound = xx(end,1:6)'- FinalState;

fun = [Bound;lambda_m;H];

% Compute the gradient (Jacobian) of the system
grad = objectiveJacobian(tf, xf, PHIf, parameters);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [lambda0, tf] = objectiveFunction(tf0, InitialState, FinalState, parameters)

% objectiveFunction Solves for the optimal initial costates (lambda0) and final time (tf)
%                   for a two-point boundary value problem using fsolve.
%
% Inputs:
%   tf0          - Initial guess for the final time.
%   InitialState - Initial state vector (e.g., position, velocity, mass, etc.).
%   FinalState   - Desired final state vector (e.g., target position, velocity, etc.).
%   parameters   - Struct containing problem parameters (e.g., constants, thrust limits, etc.).
%
% Outputs:
%   lambda0      - Optimal initial costate vector.
%   tf           - Optimal final time.

% Set initial time to 0
t0 = 0;
% Initialize exit flag for while loop
exitFlag = 0;

while exitFlag<=0
% Generation of random lambda vector from -250 to 250
lambdaRange = [-250 250];
lambda0 = zeros(7,1);
lambda0(1:6) = (lambdaRange(2)-lambdaRange(1)).*rand(6,1) +lambdaRange(1);
lambda0(7) = lambdaRange(2).*rand(1,1);



% Solve zero-finding problem to find tf and lambda
fun = @(sol) equations(t0, InitialState, FinalState, sol, parameters);
   % Define options for fsolve
options = optimoptions('fsolve', 'MaxFunctionEvaluations', 10000, 'MaxIterations', 10000, 'Display','iter-detailed',...
    'Algorithm', 'levenberg-marquardt', 'SpecifyObjectiveGradient',true, 'FunctionTolerance',1e-10, 'OptimalityTolerance',1e-10, 'StepTolerance',1e-12);

[var, ~, exitFlag] = fsolve(fun, [lambda0; tf0], options);

% Verify if the final time (var(8)) satisfies the desired range
% If not, reset the exitFlag to reattempt the computation
    if var(8) < 20*pi || var(8) > 22*pi
        exitFlag = 0;  
    end
    rng shuffle;
end
% Extract final results
tf = var(end);
lambda0 = var(1:end-1);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function v_ntw = rotECItoNTW(r_eci, v_eci, vec)
   
    
    T = v_eci / norm(v_eci);

    N = cross(r_eci, v_eci);
    N = N / norm(N);
  
    W = cross(N, T);
  
    R_eci_to_ntw = [N, T, W];

    v_ntw = R_eci_to_ntw' * vec;  % R_eci_to_ntw' è la trasposta della matrice di rotazione
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function J = jacobian(state, parameters)
% 
% This function computes the Jacobian matrix of the dynamic system.
%
% Inputs:
% - state: A vector containing the state variables of the system. It includes:
%   state(1) -> x: Position in the x-direction
%   state(2) -> y: Position in the y-direction
%   state(3) -> z: Position in the z-direction
%   state(7) -> m: Mass of the object
%   state(11) -> lvx: Velocity in the x-direction
%   state(12) -> lvy: Velocity in the y-direction
%   state(13) -> lvz: Velocity in the z-direction
%
% - parameters: A vector containing system parameters, such as:
%   parameters(1) -> T: Thrust or some system-specific force constant
%   parameters(2) -> mu: Gravitational parameter or another constant
%   parameters(5) -> k1: A system-specific constant related to forces
%   parameters(6) -> k2: A system-specific constant related to forces
%   parameters(7) -> rho0: A reference density or radius parameter
%
% Output:
% - J: A 14x14 Jacobian matrix where each element is the partial derivative of a system's
%      equations with respect to a specific state variable. 


x = state(1);
y = state(2);
z = state(3);
m = state(7);
lvx = state(11);
lvy = state(12);
lvz = state(13);

T = parameters(1);
mu = parameters(2);
k1 = parameters(5);
k2 = parameters(6);
rho0 = parameters(7);

J = [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0;
 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0;
-(mu*(- 2*x^2 + y^2 + z^2))/(x^2 + y^2 + z^2)^(5/2),(3*mu*x*y)/(x^2 + y^2 + z^2)^(5/2), (3*mu*x*z)/(x^2 + y^2 + z^2)^(5/2), 0, 0, 0, (T*lvx)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), 0, 0, 0, -(T*(lvy^2 + lvz^2))/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), (T*lvx*lvy)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), (T*lvx*lvz)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), 0;
(3*mu*x*y)/(x^2 + y^2 + z^2)^(5/2), -(mu*(x^2 - 2*y^2 + z^2))/(x^2 + y^2 + z^2)^(5/2), (3*mu*y*z)/(x^2 + y^2 + z^2)^(5/2), 0, 0, 0, (T*lvy)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), 0, 0, 0, (T*lvx*lvy)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), -(T*(lvx^2 + lvz^2))/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), (T*lvy*lvz)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), 0;
(3*mu*x*z)/(x^2 + y^2 + z^2)^(5/2), (3*mu*y*z)/(x^2 + y^2 + z^2)^(5/2), -(mu*(x^2 + y^2 - 2*z^2))/(x^2 + y^2 + z^2)^(5/2), 0, 0, 0, (T*lvz)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), 0, 0, 0, (T*lvx*lvz)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), (T*lvy*lvz)/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), -(T*(lvx^2 + lvy^2))/(m*(lvx^2 + lvy^2 + lvz^2)^(3/2)), 0;
 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0;
(15*mu*x^2*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) - (3*mu*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(5/2) - (2*k1*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(1/2)) + (2*k1*x^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (6*lvx*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (2*k1*x^2*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*x^2*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (2*k1*x*y)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvx*mu*y)/(x^2 + y^2 + z^2)^(5/2) - (3*lvy*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*x*y*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*x*y*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*x*y*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (2*k1*x*z)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvx*mu*z)/(x^2 + y^2 + z^2)^(5/2) - (3*lvz*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*x*z*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*x*z*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*x*z*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), 0, 0, 0, 0, 0, 0, 0, (mu*(- 2*x^2 + y^2 + z^2))/(x^2 + y^2 + z^2)^(5/2), -(3*mu*x*y)/(x^2 + y^2 + z^2)^(5/2), -(3*mu*x*z)/(x^2 + y^2 + z^2)^(5/2), 0;
(2*k1*x*y)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvx*mu*y)/(x^2 + y^2 + z^2)^(5/2) - (3*lvy*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*x*y*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*x*y*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*x*y*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (15*mu*y^2*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) - (3*mu*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(5/2) - (2*k1*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(1/2)) + (2*k1*y^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (6*lvy*mu*y)/(x^2 + y^2 + z^2)^(5/2) + (2*k1*y^2*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*y^2*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (2*k1*y*z)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvy*mu*z)/(x^2 + y^2 + z^2)^(5/2) - (3*lvz*mu*y)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*y*z*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*y*z*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*y*z*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), 0, 0, 0, 0, 0, 0, 0, -(3*mu*x*y)/(x^2 + y^2 + z^2)^(5/2), (mu*(x^2 - 2*y^2 + z^2))/(x^2 + y^2 + z^2)^(5/2), -(3*mu*y*z)/(x^2 + y^2 + z^2)^(5/2), 0;
(2*k1*x*z)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvx*mu*z)/(x^2 + y^2 + z^2)^(5/2) - (3*lvz*mu*x)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*x*z*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*x*z*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*x*z*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (2*k1*y*z)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (3*lvy*mu*z)/(x^2 + y^2 + z^2)^(5/2) - (3*lvz*mu*y)/(x^2 + y^2 + z^2)^(5/2) + (15*mu*y*z*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) + (2*k1*y*z*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*y*z*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), (15*mu*z^2*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(7/2) - (3*mu*(lvx*x + lvy*y + lvz*z))/(x^2 + y^2 + z^2)^(5/2) - (2*k1*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(1/2)) + (2*k1*z^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)) - (6*lvz*mu*z)/(x^2 + y^2 + z^2)^(5/2) + (2*k1*z^2*(rho0 - (x^2 + y^2 + z^2)^(1/2)))/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^2*(x^2 + y^2 + z^2)^(3/2)) - (8*k1*z^2*(rho0 - (x^2 + y^2 + z^2)^(1/2))^2)/((k2 + (rho0 - (x^2 + y^2 + z^2)^(1/2))^2)^3*(x^2 + y^2 + z^2)), 0, 0, 0, 0, 0, 0, 0, -(3*mu*x*z)/(x^2 + y^2 + z^2)^(5/2), -(3*mu*y*z)/(x^2 + y^2 + z^2)^(5/2), (mu*(x^2 + y^2 - 2*z^2))/(x^2 + y^2 + z^2)^(5/2), 0;
0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0;
0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0;
0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0;
0, 0, 0, 0, 0, 0, (2*T*(lvx^2 + lvy^2 + lvz^2)^(1/2))/m^3, 0, 0, 0, -(T*lvx)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), -(T*lvy)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), -(T*lvz)/(m^2*(lvx^2 + lvy^2 + lvz^2)^(1/2)), 0];

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = dynamics(~, x, parameters)
% eulerLagrangeEquation Computes the time derivatives of states, costates
%                       using the Euler-Lagrange equations for optimal control.
%
% Inputs:
%   ~           - Placeholder for time variable (not used, as the equations are autonomous).
%   x           - Combined state vector, including:
%                 [state; costate]:
%                 - state: [r (position); v (velocity); m (mass)]
%                 - costate: [lambda_r; lambda_v; lambda_m]
%                 
%   parameters  - Array of problem-specific parameters, including:
%                 parameters(1) = Tmax (maximum thrust),
%                 parameters(2) = mu (gravitational parameter),
%                 parameters(3) = Isp (specific impulse),
%                 parameters(4) = g0 (standard gravity),
%                 parameters(5) = k1 (density scaling factor 1),
%                 parameters(6) = k2 (density scaling factor 2),
%                 parameters(7) = rho0 (reference density).
%
% Outputs:
%   dxdt        - Time derivatives of the combined state vector, including:
%                 [state derivatives; costate derivatives]


Tmax = parameters(1);
mu = parameters(2);
Isp = parameters(3);
g0 = parameters(4);
k1 = parameters(5);
k2 = parameters(6);
rho0 = parameters(7);

r = x(1:3);
v = x(4:6);
m = x(7);
lambda_r = x(8:10);
lambda_v = x(11:13);
%lambda_m = x(14);

r_norm = norm(r);
lambda_v_norm = norm(lambda_v);

dxdt = zeros(14,1);

dxdt(1:3) = v;
dxdt(4:6) = -mu/(r_norm^3) * r - Tmax/m * lambda_v/(lambda_v_norm);
dxdt(7) = -Tmax/(Isp*g0);

dqdx = [(2*k1*r(1)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2));
        (2*k1*r(2)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2));
        (2*k1*r(3)*(rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2)))/((k2 + (rho0 - (r(1)^2 + r(2)^2 + r(3)^2)^(1/2))^2)^2*(r(1)^2 + r(2)^2 + r(3)^2)^(1/2))];

dxdt(8:10) = - 3 * mu/(r_norm^5) * (dot(r,lambda_v)) * r + mu/r_norm^3 * lambda_v - dqdx;
dxdt(11:13) = -lambda_r;
dxdt(14) = - lambda_v_norm * Tmax/(m^2);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function grad = objectiveJacobian(t, state, STM, parameters)
    
% objectiveJacobian computes the Jacobian matrix of an objective function for 
% a dynamical system. The function incorporates the state transition matrix (STM) 
% and the system dynamics to compute the gradient.

% Inputs:
%   t          - Scalar, the current time in the system (e.g., seconds).
%   state      - Vector (n x 1), the current state of the system, where n is 
%                the number of state variables.
%   STM        - Matrix (n x n), the State Transition Matrix that maps small 
%                variations in the initial state to the current state.
%   parameters - Struct or vector containing additional parameters required for 
%                the system dynamics.

% Outputs:
%   grad       - Matrix (n+1 x n+1), the computed gradient matrix of the 
%                objective function. This includes contributions from both the
%                state transition matrix and the system dynamics

% Extract relevant submatrices from the State Transition Matrix (STM)
    STM_rlr = STM(1:3, 8:10);
    STM_rlv = STM(1:3, 11:13);
    STM_rlm = STM(1:3, 14);

    

    STM_vlr = STM(4:6, 8:10);
    STM_vlv = STM(4:6, 11:13);
    STM_vlm = STM(4:6, 14);

    

    STM_lmlr = STM(14, 8:10);
    STM_lmlv = STM(14, 11:13);
    STM_lmlm = STM(14, 14);
    
  % Combine extracted STM components for mass-related dynamics
    STM_lml = [STM_lmlr STM_lmlv STM_lmlm];
   
  % Compute the system dynamics using the provided function 'dynamics'
    dxdt = dynamics(t, state, parameters);
  % Initialize the gradient contributions from the system dynamics
    f = zeros(7,1);
    f(1:6) = dxdt(1:6);
    f(7) = dxdt(14);

  % Compute the differential Hamiltonian contributions (dH)
    dH = dxdt(1:7)' * STM(8:14,8:14) - dxdt(8:14)'*STM(1:7,8:14);
    
  % Assemble the full gradient matrix
    grad = [STM_rlr STM_rlv STM_rlm f(1:3);
            STM_vlr STM_vlv STM_vlm f(4:6);
            STM_lml                 f(7);
            dH                          0];
end
