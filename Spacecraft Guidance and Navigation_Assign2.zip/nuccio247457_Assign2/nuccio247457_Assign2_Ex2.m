% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 2, Exercise 2
% Author: Gabriele Nuccio

clc
clearvars
close all

cspice_kclear();
applyDefaultSettings();
format long g;
cspice_furnsh('assignment02.tm');

addpath(genpath('sgp4\'))
addpath(genpath('tle\'))

%% 2.1
arcsec2rad = pi/(180*3600);
typerun    = 'u';  % user-provided inputs to SGP4 Matlab function
opsmode    = 'a';  % afspc approach ('air force space command')
whichconst =  72;  % WGS72 constants (radius, gravitational parameter)

scID = 36036; % ID Spacecraft

% Initialize data in UTC
t0 = '2024-11-18T20:30:00.000';
tf = '2024-11-18T22:15:00.000';

% Epoch
et0=cspice_str2et(t0);
etf=cspice_str2et(tf);

% Compute the reference data from TLE
SMOS = read_3LE(scID, 'tle\36036.3le', whichconst);
[year, month, day, hour, min, sec] = invjday(SMOS.jdsatepoch, SMOS.jdsatepochf);

SMOS_epoch_str = sprintf('%d-%02d-%02dT%02d:%02d:%02.6f',[year, month, day, hour, min, sec]);
etref = cspice_str2et(SMOS_epoch_str);

% Use sgp4 to compute the position and velocity in TEME
[SMOS,posTEME,velTEME] = sgp4(SMOS, 0.0);

% Find the ddpsi and ddeps
ddpsi = -0.114752*arcsec2rad; %  [rad]
ddeps = -0.007529*arcsec2rad; %  [rad]
ttt = cspice_unitim(etref, 'ET', 'TDT')/cspice_jyear()/100;

% Transform TEME to ECI vectors
aTEME = [0;0;0];
[rECI, vECI, aECI] = teme2eci(posTEME, velTEME, aTEME, ttt, ddpsi, ddeps);
x0ECI = [rECI;vECI];

% Station names
station1.name = 'KOUROU';
station2.name = 'TROLL';
station3.name = 'SVALBARD';

% Measurement time
station1.shift = 60; %[s] - KOUROU
station2.shift = 30; %[s] - TROLL
station3.shift = 60; %[s] - SVALBARD

min_El_KOUROU = 6; %[deg]
min_El_TROLL = 0; %[deg]
min_El_SVALBARD = 8; %[deg]

options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[~, xxKEP0] = ode113(@(t,x)Kepler(t,x,SMOS), [etref et0], x0ECI, options);
x0 = xxKEP0(end,:)';

[Az_KOUROU, El_KOUROU, rll_sat_KOUROU, et_vecWin1, ~] = antennaPointing(station1, etref, et0, etf, x0, SMOS, 'Kepler', 0);
[Az_TROLL, El_TROLL, rll_sat_TROLL, et_vecWin2, ~] = antennaPointing(station2, etref, et0, etf, x0, SMOS, 'Kepler', 0);
[Az_SVALBARD, El_SVALBARD, rll_sat_SVALBARD, et_vecWin3, ~] = antennaPointing(station3, etref, et0, etf, x0, SMOS, 'Kepler', 0);


% Compute the visibility windows
visWinKOUROU = El_KOUROU > min_El_KOUROU;
visWinSVALBARD = El_SVALBARD > min_El_SVALBARD;
visWinTROLL = El_TROLL > min_El_TROLL;

et_vis1 = et_vecWin1(visWinKOUROU);
et_vis2 = et_vecWin2(visWinTROLL);
et_vis3 = et_vecWin3(visWinSVALBARD);

tformat = 'YYYY-MM-DDTHR:MN:SC.###::UTC';
vis1t0 = cspice_timout(et_vis1(1), tformat);
vis1tf = cspice_timout(et_vis1(end), tformat);

vis2t0 = cspice_timout(et_vis2(1), tformat);
vis2tf = cspice_timout(et_vis2(end), tformat);

vis3t0 = cspice_timout(et_vis3(1), tformat);
vis3tf = cspice_timout(et_vis3(end), tformat);

% KOUROU
figure()
subplot(1,2,1);
hold on
yyaxis left % Left axis for azimuth
plot(et_vecWin1 / cspice_spd(), Az_KOUROU, 'DisplayName', 'Azimuth')
plot(et_vis1 / cspice_spd(), Az_KOUROU(visWinKOUROU), 'DisplayName', 'Visible Azimuth', 'Color',[216, 191, 216] / 255, 'LineStyle','-')
ylabel('Azimuth [deg]','Color','k') 
ax = gca;
ax.YColor = 'k';


yyaxis right % Right axis for elevation
plot(et_vecWin1 / cspice_spd(), El_KOUROU, 'DisplayName', 'Elevation')
plot(et_vis1 / cspice_spd(), El_KOUROU(visWinKOUROU), 'DisplayName', 'Visible Elevation', 'Color',[85, 107, 47] / 255, 'LineStyle','-')
ylabel('Elevation [deg]','Color','k') 
ax.YColor = 'k';

title('KOUROU')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');


subplot(1,2,2);
plot(Az_KOUROU(visWinKOUROU), El_KOUROU(visWinKOUROU), 'o')
axis([-180, 180, 0, 90])


xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')
title('KOUROU Azimuth and Elevation')


figure
subplot(1,2,1);
hold on
% TROLL
yyaxis left % Left axis for azimuth
plot(et_vecWin2 / cspice_spd(), Az_TROLL, 'DisplayName', 'Azimuth')
plot(et_vis2 / cspice_spd(), Az_TROLL(visWinTROLL), 'DisplayName', 'Visible Azimuth', 'Color',[216, 191, 216] / 255, 'LineStyle','-')
ylabel('Azimuth [deg]','Color','k') 
ax = gca;

ax.YColor = 'k';

yyaxis right % Right axis for elevation
plot(et_vecWin2 / cspice_spd(), El_TROLL, 'DisplayName', 'Elevation')
plot(et_vis2 / cspice_spd(), El_TROLL(visWinTROLL), 'DisplayName', 'Visible Elevation', 'Color',[85, 107, 47] / 255, 'LineStyle','-')
ylabel('Elevation [deg]','Color','k') 
ax.YColor = 'k';


title('TROLL')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');

subplot(1,2,2);
plot(Az_TROLL(visWinTROLL), El_TROLL(visWinTROLL), 'o')
axis([-180, 180, 0, 90])


xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')
title('TROLL Azimuth and Elevation')

figure
subplot(1,2,1);
hold on
% SVALBARD
yyaxis left % Left axis for azimuth
plot(et_vecWin3 / cspice_spd(), Az_SVALBARD, 'DisplayName', 'Azimuth')
plot(et_vis3 / cspice_spd(), Az_SVALBARD(visWinSVALBARD), 'DisplayName', 'Visible Azimuth', 'Color',[216, 191, 216] / 255, 'LineStyle','-')
ylabel('Azimuth [deg]','Color','k') 
ax = gca;

ax.YColor = 'k';

yyaxis right % Right axis for elevation
plot(et_vecWin3 / cspice_spd(), El_SVALBARD, 'DisplayName', 'Elevation')
plot(et_vis3 / cspice_spd(), El_SVALBARD(visWinSVALBARD), 'DisplayName', 'Visible Elevation', 'Color',[85, 107, 47] / 255, 'LineStyle','-')
ylabel('Elevation [deg]','Color','k') 
ax.YColor = 'k';


title('SVALBARD')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');


subplot(1,2,2);
plot(Az_SVALBARD(visWinSVALBARD), El_SVALBARD(visWinSVALBARD), 'o')
axis([-180, 180, 0, 90])
ax = gca;

xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')
title('SVALBARD Azimuth and Elevation')

%% 2.2 a) Simulate Measurements

[AzSGP4_KOUROU, ElSGP4_KOUROU, rangeSGP4_KOUROU, ~, ~] = antennaPointing(station1, etref, et0, etf, x0, SMOS, 'SGP4', 0);
[AzSGP4_TROLL, ElSGP4_TROLL, rangeSGP4_TROLL, ~, ~] = antennaPointing(station2, etref, et0, etf, x0, SMOS, 'SGP4', 0);
[AzSGP4_SVALBARD, ElSGP4_SVALBARD, rangeSGP4_SVALBARD, ~, ~] = antennaPointing(station3, etref, et0, etf, x0, SMOS, 'SGP4', 0);

% Compute the Elevation and Azimuth within the visibility time windows
AzSGP4Vis_KOUROU = AzSGP4_KOUROU .* visWinKOUROU;
ElSGP4Vis_KOUROU = ElSGP4_KOUROU .* visWinKOUROU;
AzSGP4Vis_TROLL = AzSGP4_TROLL .* visWinTROLL;
ElSGP4Vis_TROLL = ElSGP4_TROLL .* visWinTROLL;
AzSGP4Vis_SVALBARD = AzSGP4_SVALBARD .* visWinSVALBARD;
ElSGP4Vis_SVALBARD = ElSGP4_SVALBARD .* visWinSVALBARD;

figure()
plot(Az_KOUROU(visWinKOUROU), El_KOUROU(visWinKOUROU), 'o')
hold on
plot(AzSGP4_KOUROU(visWinKOUROU), ElSGP4_KOUROU(visWinKOUROU), 'o');

axis([-180,180,0, 90])
xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')


plot(Az_TROLL(visWinTROLL), El_TROLL(visWinTROLL), 'o')
plot(AzSGP4_TROLL(visWinTROLL), ElSGP4_TROLL(visWinTROLL), 'o');

axis([-180,180,0, 90])
xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')

plot(Az_SVALBARD(visWinSVALBARD), El_SVALBARD(visWinSVALBARD), 'o')
plot(AzSGP4_SVALBARD(visWinSVALBARD), ElSGP4_SVALBARD(visWinSVALBARD), 'o');
legend('Visibility from KOUROU (Keplerian)', 'Visibility from KOUROU (SGP4)', 'Visibility from TROLL (Keplerian)', 'Visibility from TROLL (SGP4)', 'Visibility from SVALBARD (Keplerian)', 'Visibility from SVALBARD (SGP4)');
axis([-180,180,0, 90])
xlabel('Azimuth [deg]')
ylabel('Elevation [deg]')

%% 2.2 b)

% Random errors
sigma_AzEl  = 125e-3; %[deg]
sigma_r = 0.01; %[km]

measIdealKOUROU = [rangeSGP4_KOUROU', AzSGP4_KOUROU', ElSGP4_KOUROU'];
measIdealTROLL = [rangeSGP4_TROLL', AzSGP4_TROLL', ElSGP4_TROLL'];
measIdealSVALBARD = [rangeSGP4_SVALBARD', AzSGP4_SVALBARD', ElSGP4_SVALBARD'];
measNoiseCov = diag(ones(1,3).*[sigma_r^2, sigma_AzEl^2, sigma_AzEl^2]);

% Compute the real measurements
measRealKOUROU = mvnrnd(measIdealKOUROU,measNoiseCov);
measRealTROLL = mvnrnd(measIdealTROLL,measNoiseCov);
measRealSVALBARD = mvnrnd(measIdealSVALBARD,measNoiseCov);

% Compute the visibility window
visWinKOUROUnoise = measRealKOUROU(:,3) > min_El_KOUROU;
visWinTROLLnoise = measRealTROLL(:,3) > min_El_TROLL;
visWinSVALBARDnoise = measRealSVALBARD(:,3) > min_El_SVALBARD; 

% Compute the measurements within the visibility window
measRealKOUROUfinal = measRealKOUROU(visWinKOUROUnoise, :);
measRealTROLLfinal = measRealTROLL(visWinTROLLnoise, :);
measRealSVALBARDfinal = measRealSVALBARD(visWinSVALBARDnoise, :);

%% 2.3 a)
refEpoch = et0;

options = odeset('reltol', 1e-12, 'abstol', 1e-12);
[~, xxGUESS] = ode113(@(t,x)Kepler(t,x,SMOS), [etref refEpoch], x0ECI, options);
x0Guess = xxGUESS(end,:)';

% Compute the Weight Matrix
W_m = inv(sqrtm(measNoiseCov));

% Cost function
fun = @(x) objFunSingle(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, W_m, SMOS, station1, 0);

% Call lsqnonlin and set the options
options = optimoptions('lsqnonlin', 'Algorithm', 'levenberg-marquardt', 'Display', 'iter', 'StepTolerance',1e-10);
[x,resnorm,residual,exitflag,~,~,jacobian] = lsqnonlin(fun, x0Guess,[],[],options);

% Covariance computation
Jac = full(jacobian);
P_ls = resnorm/(length(residual)-length(x0Guess)).*inv(Jac.'*Jac);

NavSolKOUROUpos = sqrt(trace(P_ls(1:3,1:3)));
NavSolKOUROUvel = sqrt(trace(P_ls(4:6,4:6)));

%% 2.3 b)

% Now find the minimum variance considering all the simulated measurements

station = {station1, station2, station3};
% Cost function
fun2 = @(x) objFunMultiple(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, visWinTROLLnoise, measRealTROLLfinal, visWinSVALBARDnoise, measRealSVALBARDfinal, W_m, SMOS, station, 0, 'KTS');

% Call lsqnonlin
[x2,resnorm2,residual2,exitflag2,~,~,jacobian2] = lsqnonlin(fun2, x0Guess,[],[],options);

% Covariance computation
Jac2 = full(jacobian2);
P_ls2 = resnorm2/(length(residual2) - length(x0Guess)).*inv(Jac2.'*Jac2);

NavSolALLpos = sqrt(trace(P_ls2(1:3,1:3)));
NavSolALLvel = sqrt(trace(P_ls2(4:6,4:6)));

%% 2.3 c)

% Now find the minimum variance considering all the simulated measurements and the J2 perturbation

optionsJ2 = odeset('reltol', 1e-12, 'abstol', 1e-12);
[~, xxGUESSJ2] = ode113(@(t,x)KeplerJ2(t,x,SMOS), [etref refEpoch], x0ECI, optionsJ2);
x0GuessJ2 = xxGUESSJ2(end,:)';

fun3 = @(x) objFunMultiple(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, visWinTROLLnoise, measRealTROLLfinal, visWinSVALBARDnoise, measRealSVALBARDfinal, W_m, SMOS, station, 1, 'KTS');

[x3,resnorm3,residual3,exitflag3,~,~,jacobian3] = lsqnonlin(fun3, x0GuessJ2,[],[],options);

% Covariance computation
Jac3 = full(jacobian3);
P_ls3 = resnorm3/(length(residual3)-length(x0GuessJ2)).*inv(Jac3.'*Jac3);

NavSolALLposJ2 = sqrt(trace(P_ls3(1:3,1:3)));
NavSolALLvelJ2 = sqrt(trace(P_ls3(4:6,4:6)));

% Linear Mapping

[~, std_a_KOUROU, std_i_KOUROU] = linearMapping(x, P_ls, SMOS);
[~, std_a_ALL, std_i_ALL] = linearMapping(x2, P_ls2, SMOS);
[~, std_a_ALLJ2, std_i_ALLJ2] = linearMapping(x3, P_ls3, SMOS);

% RESULTS
% 3.a
fprintf('Results considering only KOUROU Station:\n')
fprintf('Navigation Solution (Cartesian State):\n POSITION in ECI: %.10f %.10f %.10f\n VELOCITY in ECI: %.10f %.10f %.10f\n\n',...
        x(1),x(2),x(3),x(4),x(5),x(6))

fprintf('Square root of the trace of the estimated covariance submatrix:\n POSITION SUBMATRIX: %.10f\n VELOCITY SUBMATRIX: %.10f\n\n',...
        NavSolKOUROUpos,NavSolKOUROUvel)

fprintf('Standard Deviation:\n SEMI-MAJOR AXIS: %.10f\n INCLINATION: %.10f\n\n',...
        std_a_KOUROU,std_i_KOUROU)

% 3.b
fprintf('Results considering all the Stations (KOUROU, TROLL, SVALBARD):\n')
fprintf('Navigation Solution (Cartesian State):\n POSITION in ECI: %.10f %.10f %.10f\n VELOCITY in ECI: %.10f %.10f %.10f\n\n',...
        x2(1),x2(2),x2(3),x2(4),x2(5),x2(6))

fprintf('Square root of the trace of the estimated covariance submatrix:\n POSITION SUBMATRIX: %.10f\n VELOCITY SUBMATRIX: %.10f\n\n',...
        NavSolALLpos,NavSolALLvel)

fprintf('Standard Deviation:\n SEMI-MAJOR AXIS: %.10f\n INCLINATION: %.10f\n\n',...
        std_a_ALL,std_i_ALL)

% 3.c
fprintf('Results considering all the Stations (KOUROU, TROLL, SVALBARD) and J2 Perturbation:\n')
fprintf('Navigation Solution (Cartesian State):\n POSITION in ECI: %.10f %.10f %.10f\n VELOCITY in ECI: %.10f %.10f %.10f\n\n',...
        x3(1),x3(2),x3(3),x3(4),x3(5),x3(6))

fprintf('Square root of the trace of the estimated covariance submatrix:\n POSITION SUBMATRIX: %.10f\n VELOCITY SUBMATRIX: %.10f\n\n',...
        NavSolALLposJ2,NavSolALLvelJ2)

fprintf('Standard Deviation:\n SEMI-MAJOR AXIS: %.10f\n INCLINATION: %.10f\n\n',...
        std_a_ALLJ2,std_i_ALLJ2)


%% 2.4 - TRADEOFF

% Find the best case of the trade-off.

% Case KOUROU - TROLL
funTRADE1 = @(x) objFunMultiple(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, visWinTROLLnoise, measRealTROLLfinal, visWinSVALBARDnoise, measRealSVALBARDfinal, W_m, SMOS, station, 1, 'KT');
[xTRADE1,resnormTRADE1,residualTRADE1,exitflagTRADE1,~,~,jacobianTRADE1] = lsqnonlin(funTRADE1, x0GuessJ2,[],[],options);

% Covariance computation
JacTRADE1 = full(jacobianTRADE1);
P_lsTRADE1 = resnormTRADE1/(length(residualTRADE1)-length(x0GuessJ2)).*inv(JacTRADE1.'*JacTRADE1);

% Case KOUROU - SVALBARD
funTRADE2 = @(x) objFunMultiple(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, visWinTROLLnoise, measRealTROLLfinal, visWinSVALBARDnoise, measRealSVALBARDfinal, W_m, SMOS, station, 1, 'KS');
[xTRADE2,resnormTRADE2,residualTRADE2,exitflagTRADE2,~,~,jacobianTRADE2] = lsqnonlin(funTRADE2, x0GuessJ2,[],[],options);

% Covariance computation
JacTRADE2 = full(jacobianTRADE2);
P_lsTRADE2 = resnormTRADE2/(length(residualTRADE2)-length(x0GuessJ2)).*inv(JacTRADE2.'*JacTRADE2);

% Case TROLL-SVALBARD
funTRADE3 = @(x) objFunMultiple(x, etref, refEpoch, etf, visWinKOUROUnoise, measRealKOUROUfinal, visWinTROLLnoise, measRealTROLLfinal, visWinSVALBARDnoise, measRealSVALBARDfinal, W_m, SMOS, station, 1, 'TS');
[xTRADE3,resnormTRADE3,residualTRADE3,exitflagTRADE3,~,~,jacobianTRADE3] = lsqnonlin(funTRADE3, x0GuessJ2,[],[],options);

% Covariance computation
JacTRADE3 = full(jacobianTRADE3);
P_lsTRADE3 = resnormTRADE3/(length(residualTRADE3)-length(x0GuessJ2)).*inv(JacTRADE3.'*JacTRADE3);

% Compute the linear mapping in the 3 different cases to evaluate the best
% solution
[~, stdTRADE1_a, stdTRADE1_i] = linearMapping(xTRADE1, P_lsTRADE1, SMOS);
[~, stdTRADE2_a, stdTRADE2_i] = linearMapping(xTRADE2, P_lsTRADE2, SMOS);
[~, stdTRADE3_a, stdTRADE3_i] = linearMapping(xTRADE3, P_lsTRADE3, SMOS);

% WIN KOUROU - SVALBARD - 65 k$
 %% 2.5
optionsDay = optimoptions('lsqnonlin', 'Algorithm', 'levenberg-marquardt', 'Display', 'iter', 'StepTolerance', 1e-7);
 %scrivere - Try per un giorno e vediamo cosa succede
refEpoch = etref - 5*60*60;
refEpochDayPlus1 = etref + 5*60*60;

[AzSGP4_KOUROU, ElSGP4_KOUROU, rangeSGP4_KOUROU, etKourouSixHours, ~] = antennaPointing(station1, etref, refEpoch, refEpochDayPlus1, x0, SMOS, 'SGP4');
[AzSGP4_TROLL, ElSGP4_TROLL, rangeSGP4_TROLL, etTrollSixHours, ~] = antennaPointing(station2, etref, refEpoch, refEpochDayPlus1, x0, SMOS, 'SGP4');
[AzSGP4_SVALBARD, ElSGP4_SVALBARD, rangeSGP4_SVALBARD, etSvalbardSixHours, ~] = antennaPointing(station3, etref, refEpoch, refEpochDayPlus1, x0, SMOS, 'SGP4');

measIdealKOUROU = [rangeSGP4_KOUROU', AzSGP4_KOUROU', ElSGP4_KOUROU'];
measIdealTROLL = [rangeSGP4_TROLL', AzSGP4_TROLL', ElSGP4_TROLL'];
measIdealSVALBARD = [rangeSGP4_SVALBARD', AzSGP4_SVALBARD', ElSGP4_SVALBARD'];
measNoiseCov = diag(ones(1,3).*[sigma_r^2, sigma_AzEl^2, sigma_AzEl^2]);
measRealKOUROU = mvnrnd(measIdealKOUROU,measNoiseCov);
measRealTROLL = mvnrnd(measIdealTROLL,measNoiseCov);
measRealSVALBARD = mvnrnd(measIdealSVALBARD,measNoiseCov);

visWinKOUROUnoise = measRealKOUROU(:,3) > min_El_KOUROU;
visWinTROLLnoise = measRealTROLL(:,3) > min_El_TROLL;
visWinSVALBARDnoise = measRealSVALBARD(:,3) > min_El_SVALBARD; 

measRealKOUROUfinal = measRealKOUROU(visWinKOUROUnoise, :);
measRealTROLLfinal = measRealTROLL(visWinTROLLnoise, :);
measRealSVALBARDfinal = measRealSVALBARD(visWinSVALBARDnoise, :);

figure()
hold on
plot(etKourouSixHours / cspice_spd(), ElSGP4_KOUROU, 'DisplayName','Elevation of Kourou')
yline(min_El_KOUROU, 'DisplayName', 'Minimum Elevation of Kourou', 'Color','k', 'LineStyle','--', 'LineWidth',2)
xline(etref/cspice_spd(), 'DisplayName', 'Reference Epoch', 'Color','k', 'LineStyle','-.', 'LineWidth',2)
ylabel('Elevation [deg]','Color','k') 
title('KOUROU')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');

figure()
hold on
plot(etTrollSixHours / cspice_spd(), ElSGP4_TROLL, 'DisplayName','Elevation of Troll')
yline(min_El_TROLL, 'DisplayName', 'Minimum Elevation of Troll', 'Color','k', 'LineStyle','--', 'LineWidth',2)
xline(etref/cspice_spd(), 'DisplayName', 'Reference Epoch', 'Color','k', 'LineStyle','-.', 'LineWidth',2)
ylabel('Elevation [deg]','Color','k') 
title('TROLL')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');

figure()
hold on
plot(etSvalbardSixHours / cspice_spd(), ElSGP4_SVALBARD, 'DisplayName','Elevation of Svalbard')
yline(min_El_SVALBARD, 'DisplayName', 'Minimum Elevation of Svalbard', 'Color','k', 'LineStyle','--', 'LineWidth',2)
xline(etref/cspice_spd(), 'DisplayName', 'Reference Epoch', 'Color','k', 'LineStyle','-.', 'LineWidth',2)
ylabel('Elevation [deg]','Color','k') 
title('SVALBARD')
xlabel('Epoch [MJD2000]')
legend('Location', 'best');

%% FUNCTION
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',24);
    set(groot, 'defaultAxesLabelFontSizeMultiplier', 1.2)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx]  = propagateKepler(t0,x0,tf, shift, SMOS, onlyVis)
% Propagate the satellite's state assuming Keplerian motion
% for a given station and its measurement frequency.
%
% INPUT:
%   t0        : [1, 1] Initial epoch in seconds (ET)
%   tf        : [1, 1] Final epoch in seconds (ET)
%   x0        : [6, 1] Initial state vector in ECI frame (km)
%   mu        : [1, 1] Gravitational parameter of the central body (km^3/s^2)
%   shift     : [1, 1] Measurement time of the given station (seconds)
%   onlyVis   : [1, 1] == 1 if evaluate only the propagator in the visbility
%   window, == 0 otherwise
% OUTPUT:
%   tt      : [N, 1] Time vector of propagation (s)
%   xx      : [N, 6] Propagated state matrix where each row contains:
%                        [x, y, z, vx, vy, vz]
%

    if nargin < 6
        onlyVis = 0;
    end
    
if onlyVis == 0
    npoints = round((tf-t0)/shift)+1;
    tvec = linspace(t0, tf, npoints);
    % Perform integration
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode113(@(t,x)Kepler(t,x,SMOS), tvec, x0, options);
elseif onlyVis == 1
    % Perform integration
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode113(@(t,x)Kepler(t,x,SMOS), [t0 tf], x0, options); 
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dxdt = Kepler(~, xx, SMOS)
% Computes the time derivative of the state vector for Keplerian
% motion. 
%
% INPUT:
%   et          : [1, 1] Ephemeris time (TDB) in seconds.
%   xx          : [6, 1] State vector [x, y, z, vx, vy, vz] in ECI where:
%                 x, y, z   - Position components in Cartesian coordinates (km)
%                 vx, vy, vz - Velocity components in Cartesian coordinates (km/s)
%   SMOS.mu     : [1, 1] Standard gravitational parameter of the central body (km^3/s^2)

%
% OUTPUT:
%   dxdt        : [6, 1] Time derivative of the state vector, representing:
%                 dxdt = [vx, vy, vz, ax, ay, az], where:
%                 ax, ay, az - Acceleration components due to gravity (km/s^2)
    r = norm(xx(1:3));
    dxdt = zeros(6,1);
    dxdt(1:3) = xx(4:6);
    dxdt(4:6) = -SMOS.mu/r^3 * xx(1:3);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Az, El, range, et_vec, xx] = antennaPointing(station, etref, et0, etf, x0, SMOS, propagator, J2, onlyVis, visibility)

%       Calculate the range, azimuth, and elevation of a satellite relative to a ground station.
%       The spacecraft dynamics can be modeled using
%       J2-perturbed Keplerian motion or unperturbed Keplerian motion
% INPUT:
%   station     : [string] Name and Measurement time of the ground station
%   etref       : [1, 1] Reference Epoch for TLE in seconds (UTC)
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   x0          : [6, 1] State vector of the satellite in ECI frame 
%   SMOS.mu     : [1, 1] Gravitational parameter of the central body (km^3/s^2)
%   propagator  : [string] Define the type of propagator among 'Kepler'
%   or 'SGP4'
%   J2          : If == 1 takes into account J2 perturbation, if == 0 it does not.
%   onlyVis     : [1, 1] == 1 if evaluate only the propagator in the visbility
%   window, == 0 otherwise
%   visibility  : [N, 1] visibility logical vector
% OUTPUT:
%   range       : [N, 1] Range between satellite and station (km)
%   Az          : [N, 1] Azimuth angle (degrees)
%   El          : [N, 1] Elevation angle (degrees)
%   et_vec      : [N, 1] time interval considered
%   xx          : [N, 6] Propagated state vector

if nargin < 9
    onlyVis = 0;
    visibility = 0;
end

stationName = station.name;
shift = station.shift;

% Create the ephemeris time vector
npoints = round((etf-et0)/shift)+1;
et_vec = linspace(et0, etf, npoints);

% Find the ddpsi and ddeps
arcsec2rad = pi/(180*3600);
ddpsi = -0.114752*arcsec2rad; %  [rad]
ddeps = -0.007529*arcsec2rad; %  [rad]
rECI = zeros(3, npoints);
vECI = zeros(3, npoints);
xx = zeros(npoints, 6);

% Choose the propagator
if strcmpi(propagator, 'Kepler')
    % Include J2 perturbation or not
    if onlyVis == 0
        if J2 == 0
           [~, xx]  = propagateKepler(et0,x0,etf, shift, SMOS, onlyVis);
        elseif J2 == 1
           [~, xx]  = propagateKeplerJ2(et0,x0,etf, shift, SMOS, onlyVis);
        end
    elseif onlyVis == 1
        et_vec = et_vec(visibility);
        if J2 == 0
           [~, xx]  = propagateKepler(et0,x0,et_vec, shift, SMOS, onlyVis);
        elseif J2 == 1
           [~, xx]  = propagateKeplerJ2(et0,x0,et_vec, shift, SMOS, onlyVis); 
        end
        xx = xx(2:end, :);
    end

elseif strcmpi(propagator, 'SGP4')
  for i = 1:npoints
    % SGP4 propagation
    tsince = (et_vec(i) - etref)/60.0; % minutes from TLE epoch
    [SMOS, TEME.r , TEME.v] = sgp4(SMOS,  tsince);
    
    % Compute centuries from 2000-01-01T00:00:00.00 TDT
    ttt = cspice_unitim(et_vec(i), 'ET', 'TDT')/cspice_jyear()/100;
    
    % TEME to ECI conversion
    [rECI(:,i), vECI(:,i)] = teme2eci(TEME.r, TEME.v, [0.0;0.0;0.0], ttt, ddpsi, ddeps);
    xx(i,:) = [rECI(:,i); vECI(:,i)]';
  end
end

 % Define station name
topoFrame = [stationName, '_TOPO'];

Az = zeros(1, length(et_vec));
El = zeros(1, length(et_vec));
range = zeros(1, length(et_vec));

  for i = 1 : length(et_vec)

    % Compute station position in ECI
    rv_station_ECI = cspice_spkezr(stationName, et_vec(i), 'J2000', 'NONE', 'EARTH');
    ROT_ECI2TOPO= cspice_sxform('J2000', topoFrame, et_vec(i));

    % Compute station-satellite vector in ECI
    rv_station_sat_eci = xx(i,:)' - rv_station_ECI;
    
    % Convert state into topocentric frame
    rv_station_sat_topo = ROT_ECI2TOPO*rv_station_sat_eci;
 
    % Compute range, azimuth and elevation using cspice_xfmsta
    rll_sat = cspice_xfmsta(rv_station_sat_topo,'RECTANGULAR','LATITUDINAL','EARTH');
    
    Az(i) = rll_sat(2)*cspice_dpr;   % [deg]
    El(i) = rll_sat(3)*cspice_dpr;   % [deg]
    range(i) = rll_sat(1); % [km]
  end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function residual = objFunSingle(x0, etref, et0, etf, visibility, measReal, W_m, SMOS, station, J2)
%       Computes the residuals for lsqnonlin optimization.
%       The spacecraft dynamics can be modeled using
%       J2-perturbed Keplerian motion or unperturbed Keplerian motion
%
% INPUT:
%   x0          : [6, 1] State vector [x, y, z, vx, vy, vz] at initial time
%   etref       : [1, 1] Reference Epoch for TLE in seconds (UTC)
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   W_m         : [3, 3] Weighting matrix for measurements
%   measReal    : [N, 3] Real measurements [range, azimuth, elevation]
%   visibility   : [N, 1] Visibility time window
%   SMOS.mu     : [1, 1] Gravitational constant of the central body
%   station     : [string] Name and Measurement time of the ground station
%   J2          : If == 1 takes into account J2 perturbation, if == 0 it does not.
%
% OUTPUT:
%   residuals   : [Nx3] Residuals flattened into a vector for lsqnonlin [range, azimuth, elevation]
%

npoints = round((etf-et0)/60)+1;
et_vec = linspace(et0, etf, npoints);
et_vec = et_vec(visibility);

residual = zeros(size(measReal));
[Az, El, range, ~, ~] = antennaPointing(station, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility);
predictedMeas = [range; 
                 Az; 
                 El];

predictedMeas = predictedMeas';


% Compute the residuals
for i=1:length(et_vec)
    predictedMeas(i,2) = deg2rad(predictedMeas(i,2));
    predictedMeas(i,3) = deg2rad(predictedMeas(i,3));
    measReal(i,2) = deg2rad(measReal(i,2));
    measReal(i,3) = deg2rad(measReal(i,3));
    weightedDiff = W_m * [predictedMeas(i,1) - measReal(i,1), rad2deg(angdiff(predictedMeas(i,2),measReal(i,2))), rad2deg(angdiff(predictedMeas(i,3),measReal(i,3)))]';
    residual(i,:) = weightedDiff';
end
end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function residual = objFunMultiple(x0, etref, et0, etf, visibility1, measReal1 , visibility2, measReal2, visibility3, measReal3, W_m, SMOS, station, J2, cases)
%       Computes the residuals for lsqnonlin optimization for multiple
%       ground stations.
%       The spacecraft dynamics can be modeled using
%       J2-perturbed Keplerian motion or unperturbed Keplerian motion
%
% INPUT:
%   x0          : [6, 1] State vector [x, y, z, vx, vy, vz] at initial time
%   etref       : [1, 1] Reference Epoch for TLE in seconds (UTC)
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   W_m         : [3, 3] Weighting matrix for measurements
%   measReal    : [N, 3] Real measurements [range, azimuth, elevation]
%   visibility   : [N, 1] Visibility time window
%   SMOS.mu     : [1, 1] Gravitational constant of the central body
%   station     : [string] Name and Measurement time of the ground station
%   J2          : If == 1 takes into account J2 perturbation, if == 0 it does not.
%   cases       : [string] define which ground stations the function will
%   take into account to compute the residuals
% OUTPUT:
%   residuals   : [Nx3] Residuals flattened into a vector for lsqnonlin [range, azimuth, eleva

npoints1 = round((etf-et0)/60)+1;
et_vec1 = linspace(et0, etf, npoints1);
npoints2 = round((etf-et0)/30)+1;
et_vec2 = linspace(et0, etf, npoints2);
et_vec3 = et_vec1;

et_vec1 = et_vec1(visibility1);
et_vec2 = et_vec2(visibility2);
et_vec3 = et_vec3(visibility3);

station1 = station{1};
station2 = station{2};
station3 = station{3};
if strcmpi('KTS', cases)
% KOUROU
[Az1, El1, range1, ~, ~] = antennaPointing(station1, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility1);
predictedMeas1 =          [range1; 
                           Az1; 
                           El1];

predictedMeas1 = predictedMeas1';



% TROLL
[Az2, El2, range2, ~, ~] = antennaPointing(station2, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility2);
predictedMeas2 =          [range2; 
                           Az2; 
                           El2];

predictedMeas2 = predictedMeas2';



% SVALBARD
[Az3, El3, range3, ~, ~] = antennaPointing(station3, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility3);
predictedMeas3 =          [range3; 
                           Az3; 
                           El3];

predictedMeas3 = predictedMeas3';



predictedMeas = [predictedMeas1;predictedMeas2;predictedMeas3];
etvecIter = [et_vec1';et_vec2';et_vec3'];
measReal = [measReal1; measReal2; measReal3];
residual = zeros(size(measReal));
for i=1:length(etvecIter)
    predictedMeas(i,2) = deg2rad(predictedMeas(i,2));
    predictedMeas(i,3) = deg2rad(predictedMeas(i,3));
    measReal(i,2) = deg2rad(measReal(i,2));
    measReal(i,3) = deg2rad(measReal(i,3));
    weightedDiff = W_m * [predictedMeas(i,1) - measReal(i,1), rad2deg(angdiff(predictedMeas(i,2),measReal(i,2))), rad2deg(angdiff(predictedMeas(i,3),measReal(i,3)))]';
    residual(i,:) = weightedDiff';
end
end

% Kourou - Troll
if strcmpi('KT', cases)
    % KOUROU
    [Az1, El1, range1] = antennaPointing(station1, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility1);
    predictedMeas1 =          [range1; 
                              Az1; 
                              El1];
    
    predictedMeas1 = predictedMeas1';
    
    
    % TROLL
    [Az2, El2, range2] = antennaPointing(station2, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility2);
    predictedMeas2 =          [range2; 
                              Az2; 
                              El2];
    
    predictedMeas2 = predictedMeas2';
    

    predictedMeas = [predictedMeas1;predictedMeas2];
    etvecIter = [et_vec1';et_vec2'];
    measReal = [measReal1; measReal2];
    residual = zeros(size(measReal));
for i=1:length(etvecIter)
    predictedMeas(i,2) = deg2rad(predictedMeas(i,2));
    predictedMeas(i,3) = deg2rad(predictedMeas(i,3));
    measReal(i,2) = deg2rad(measReal(i,2));
    measReal(i,3) = deg2rad(measReal(i,3));
    weightedDiff = W_m * [predictedMeas(i,1) - measReal(i,1), rad2deg(angdiff(predictedMeas(i,2),measReal(i,2))), rad2deg(angdiff(predictedMeas(i,3),measReal(i,3)))]';
    residual(i,:) = weightedDiff';
end

end

% Kourou - Svalbard
if strcmpi('KS', cases)
    % KOUROU
    [Az1, El1, range1] = antennaPointing(station1, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility1);
    predictedMeas1 =          [range1; 
                              Az1; 
                              El1];
    
    predictedMeas1 = predictedMeas1';
    

    % SVALBARD
    [Az3, El3, range3] = antennaPointing(station3, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility3);
    predictedMeas3 =          [range3; 
                              Az3; 
                              El3];
    
    predictedMeas3 = predictedMeas3';
   


        predictedMeas = [predictedMeas1;predictedMeas3];
        etvecIter = [et_vec1';et_vec3'];
        measReal = [measReal1; measReal3];
        residual = zeros(size(measReal));
for i=1:length(etvecIter)
    predictedMeas(i,2) = deg2rad(predictedMeas(i,2));
    predictedMeas(i,3) = deg2rad(predictedMeas(i,3));
    measReal(i,2) = deg2rad(measReal(i,2));
    measReal(i,3) = deg2rad(measReal(i,3));
    weightedDiff = W_m * [predictedMeas(i,1) - measReal(i,1), rad2deg(angdiff(predictedMeas(i,2),measReal(i,2))), rad2deg(angdiff(predictedMeas(i,3),measReal(i,3)))]';
    residual(i,:) = weightedDiff';
end
end

% Troll - Svalbard
if strcmpi('TS', cases)
    % TROLL
    [Az2, El2, range2] = antennaPointing(station2, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility2);
    predictedMeas2 =          [range2; 
                              Az2; 
                              El2];
    
    predictedMeas2 = predictedMeas2';

    % SVALBARD
    [Az3, El3, range3] = antennaPointing(station3, etref, et0, etf, x0, SMOS, 'Kepler', J2, 1, visibility3);
    predictedMeas3 =          [range3; 
                              Az3; 
                              El3];
    
    predictedMeas3 = predictedMeas3';


        predictedMeas = [predictedMeas2;predictedMeas3];
        etvecIter = [et_vec2';et_vec3'];
        measReal = [measReal2; measReal3];
        residual = zeros(size(measReal));
for i=1:length(etvecIter)
    predictedMeas(i,2) = deg2rad(predictedMeas(i,2));
    predictedMeas(i,3) = deg2rad(predictedMeas(i,3));
    measReal(i,2) = deg2rad(measReal(i,2));
    measReal(i,3) = deg2rad(measReal(i,3));
    weightedDiff = W_m * [predictedMeas(i,1) - measReal(i,1), rad2deg(angdiff(predictedMeas(i,2),measReal(i,2))), rad2deg(angdiff(predictedMeas(i,3),measReal(i,3)))]';
    residual(i,:) = weightedDiff';
end
end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dxdt = KeplerJ2(t,xx, SMOS)
% Computes the time derivative of the state vector for Keplerian taking
% into account the J2 perturbation
% motion. 
%
% INPUT:
%   et          : [1, 1] Ephemeris time (TDB) in seconds.
%   xx          : [6, 1] State vector [x, y, z, vx, vy, vz] in ECI where:
%                 x, y, z   - Position components in Cartesian coordinates (km)
%                 vx, vy, vz - Velocity components in Cartesian coordinates (km/s)
%   SMOS.mu     : [1, 1] Standard gravitational parameter of the central body (km^3/s^2)

%
% OUTPUT:
%   dxdt        : [6, 1] Time derivative of the state vector, representing:
%                 dxdt = [vx, vy, vz, ax, ay, az], where:
%                 ax, ay, az - Acceleration components due to gravity (km/s^2)

mu = SMOS.mu;
R_EARTH = cspice_bodvrd('EARTH','RADII',3);
RE = R_EARTH(1);
% State :

rECInorm = norm(xx(1:3)) ;
rECI = xx(1:3) ;
M_ROT = cspice_pxform('J2000', 'ITRF93', t);
rECEF = M_ROT * rECI ;
rECEFnorm   = norm(rECEF) ;


J2 = 0.0010826269;
Coeff_J2 = (3/2 * J2 * mu * RE^2/rECEFnorm^5);

aJ2ECEF =   [Coeff_J2*rECEF(1)*(5*rECEF(3)^2/rECEFnorm^2 - 1); 
             Coeff_J2*rECEF(2)*(5*rECEF(3)^2/rECEFnorm^2 - 1);
             Coeff_J2*rECEF(3)*(5*rECEF(3)^2/rECEFnorm^2 - 3)];

aJ2ECI = M_ROT' * aJ2ECEF ;

dxdt = zeros(6,1);
dxdt(1:3) = xx(4:6);
dxdt(4) = -mu/rECInorm^3*xx(1) +  aJ2ECI(1);
dxdt(5) = -mu/rECInorm^3*xx(2) +  aJ2ECI(2);
dxdt(6) = -mu/rECInorm^3*xx(3) +  aJ2ECI(3);
      
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx]  = propagateKeplerJ2(t0,x0,tf, shift, SMOS, onlyVis)
% Propagate the satellite's state assuming Keplerian motion
% for a given station and its measurement frequency. It takes into account
% the J2 perturbation
%
% INPUT:
%   t0        : [1, 1] Initial epoch in seconds (ET)
%   tf        : [1, 1] Final epoch in seconds (ET)
%   x0        : [6, 1] Initial state vector in ECI frame (km)
%   mu        : [1, 1] Gravitational parameter of the central body (km^3/s^2)
%   shift     : [1, 1] Measurement time of the given station (seconds)
%   onlyVis   : [1, 1] == 1 if evaluate only the propagator in the visbility
%   window, == 0 otherwise
% OUTPUT:
%   tt      : [N, 1] Time vector of propagation (s)
%   xx      : [N, 6] Propagated state matrix where each row contains:
%                        [x, y, z, vx, vy, vz]
%
    
    % Perform integration
   if onlyVis == 0
    npoints = round((tf-t0)/shift)+1;
    tvec = linspace(t0, tf, npoints);
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode113(@(t,x)KeplerJ2(t,x,SMOS), tvec, x0, options);
   elseif onlyVis == 1
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode113(@(t,x)KeplerJ2(t,x,SMOS), [t0 tf], x0, options);
   end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Pkep, std_a, std_i] = linearMapping(state, Pcar, SMOS)
% Compute the linear mapping in terms of standard deviation of semimajor
% axis and inclination.
%
% INPUT:
%   state      : [6x1] Cartesian state vector [x, y, z, vx, vy, vz]
%   Pcar       : [6x6] Covariance matrix of the cartesian state vector
%   SMOS.mu    : [1x1] Gravitational parameter of the central body [km^3/s^2].
%
% OUTPUT:
%   Pkep       : [6x6] Covariance matrix mapping Cartesian to Keplerian elements.
%   std_a      : [1x1] standard deviation of semimajor axis [km]
%   std_i      : [1x1] standard deviation of inclination [deg]
    mu = SMOS.mu;
     % Initialize Jacobian
    J = zeros(6, 6);
    r = state(1:3);
    v = state(4:6);
 
    % Perturb position
    for k = 1:3
        epsR = zeros(3,1);
        epsR(k) = sqrt(eps) * max(1, abs(r(k)));

        % Forward perturbation
        [afin, efin, ifin, OMfin, omfin, thfin] = car2kep(r + epsR, v, mu);
        [ain, ein, iin, OMin, omin, thin] = car2kep(r, v, mu);
    % Computes the Jacobian from Cartesian to Keplerian elements using finite differences.
        % Numerical derivative
        J(:, k) = ([afin, efin, ifin, OMfin, omfin, thfin]' - [ain, ein, iin, OMin, omin, thin]') ./ epsR(k);
    end

    % Perturb velocity
    for k = 1:3
        epsV = zeros(3,1);
        epsV(k) = sqrt(eps) * max(1, abs(v(k)));

        % Forward and backward perturbation
        [afin, efin, ifin, OMf, omfin, thfin] = car2kep(r, v + epsV, mu);
        [ain, ein, iin, OMin, omin, thin] = car2kep(r, v, mu);
    % Computes the Jacobian from Cartesian to Keplerian elements using finite differences.
        % Numerical derivative
        J(:, k+3) = ([afin, efin, ifin, OMf, omfin, thfin]'- [ain, ein, iin, OMin, omin, thin]') ./ epsV(k);
    end

    % Compute the covariance
    Pkep = J * Pcar * J';

    std_a = sqrt(Pkep(1,1)); % Standard deviation of semimajor axis [km]
    std_i = rad2deg(sqrt(Pkep(3,3))); % Standard deviation of inclination [deg]
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [a, e, i, OM, om, th,N] = car2kep(r, v, mu)
% car2par_rad Converts Cartesian coordinates to Keplerian parameters (Output in radians)
%
% INPUT:
%   r [3x1] : Position vector [km]
%   v [3x1] : Velocity vector [km/s]
%   mu [1x1] : Gravitational parameter [km^3/s^2]
%
% OUTPUT:
%   a  [1x1] : Semi-major axis [km]
%   e  [1x1] : Eccentricity [-]
%   i  [1x1] : Inclination [rad]
%   OM [1x1] : Right Ascension of the Ascending Node (RAAN) [rad]
%   om [1x1] : Argument of periapsis [rad]
%   th [1x1] : True anomaly [rad]

I = [1 0 0]';
J = [0 1 0]';
K = [0 0 1]';

r_norm = norm(r);
v_norm = norm(v);

h = cross(r,v);
h_norm = norm(h);


i = acos(dot(h,K)/h_norm);


e = 1/mu * ((v_norm^2 - mu/r_norm)*r - (dot(r,v))*v);
e_norm = norm(e);


Eps = 1/2 * v_norm^2 - mu/r_norm;
a = -mu/(2*Eps);

N = cross(K,h);
N_norm = norm(N);


if dot(N,J) >= 0
 OM = acos(dot(N,I)/N_norm);
else
    OM = 2*pi - acos(dot(N,I)/N_norm);
end
if i == 0
    OM = 0;
    N = [1;0;0];
    N_norm = norm(N);
end

if dot(e,K) >= 0
    om = acos(dot(N,e)/(N_norm * e_norm));
else
    om = 2*pi -acos(dot(N,e)/(N_norm * e_norm));
end

if dot(v,r)/r_norm >=0
    th = acos(dot(r,e)/(r_norm * e_norm));
else
    th = 2*pi - acos(dot(r,e)/(r_norm * e_norm));
end

e = e_norm;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%