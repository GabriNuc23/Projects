% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 2, Exercise 1
% Author: Gabriele Nuccio

clc
clearvars
close all

cspice_kclear();
applyDefaultSettings();
cspice_furnsh('assignment02.tm');
format long g;

% Mean initial State
ri_mean = [-0.011965533749906,-0.017025663128129];
vi_mean = [10.718855256727338, 0.116502348513671];
meanState = [ri_mean, vi_mean]';

% Initial time and Final time
ti =  1.282800225339865; 
tf =  9.595124551366348; 

% Initial Covariance [4x4]
P0 = [+1.041e-15, +6.026e-17, +5.647e-16, +4.577e-15; 
      +6.026e-17, +4.287e-18, +4.312e-17, +1.855e-16;
      +5.647e-16, +4.312e-17, +4.432e-16, +1.455e-15;
      +4.577e-15, +1.855e-16, +1.455e-15, +2.822e-14];

% Constants
parameters.m_s = 3.28900541e5; % Scaled Mass of the Sun
parameters.rho = 3.88811143e2; % Scaled Sun-(Earth+Moon) distance
parameters.om_s = -9.25195985e-1; % Scaled Sun Angular Velocity
parameters.om_em = 2.66186135e-06; % Earth-Moon angular velocity [s^-1]

% Find mu
GM_E = cspice_bodvrd('Earth', 'GM',1);
GM_M = cspice_bodvrd('Moon', 'GM',1);
parameters.mu = GM_M/(GM_E + GM_M);

%% 1.1 - LinCov and UT
%%----------------------Linearized Approach-------------------%%
n = 4;
tvec = linspace(ti,tf,5);

% Initialize the propagated mean and propagated covariance
X_lincov = zeros(length(tvec), n);
X_lincov(1,:) = meanState;

P_lincov = zeros(n, n, length(tvec));
P_lincov(:, :, 1) = P0;

for i = 1:length(tvec)-1
    [tt, xx, PHIf, xf]  = propagatePCR4BP_STM(ti,meanState,tvec(i+1),parameters);
    X_lincov(i+1, :) = xf;
    P_lincov(:, :, i+1) = PHIf * P0 * PHIf';
end

% Extract the covariance for the position and build the ellipse
EllipseLinCov = errorEllipse(X_lincov(end,1:2), P_lincov(1:2,1:2, end));

%%------------------Unscented Transform (UT)---------------------%%
[X_UT, P_UT] = UT(meanState, P0, ti, tvec, parameters);
% Extract the covariance for the position and build the ellipse
EllipseUT = errorEllipse(X_UT(end, 1:2), P_UT(1:2,1:2, end));

% Plot the mean and the ellipses at the final time
figure()   
plot(X_lincov(end, 1), X_lincov(end, 2), "o", 'MarkerSize',10)
hold on

plot(EllipseLinCov(:,1), EllipseLinCov(:,2), '--b');

plot(X_UT(end,1), X_UT(end,2), 'o', 'MarkerSize',10);
plot(EllipseUT(:,1), EllipseUT(:,2), '--r');
title('Mean Position and Covariance Ellipse at final time')
xlabel('Position X [-]')
ylabel('Position Y [-]')
legend('Mean Position LinCov',  'Covariance Ellipse LinCov', 'Mean Position UT', 'Covariance Ellipse UT')
%% 1.2 - Montecarlo simulation

[X_MC, P_MC, Y_samples] = MC(meanState, P0, ti, tvec, parameters);
EllipseMC = errorEllipse(X_MC(end, 1:2), P_MC(1:2,1:2, end));

% Compare the three methods 
figure()   
plot(X_lincov(end, 1), X_lincov(end, 2), 'o', 'MarkerSize',10)
hold on
plot(X_UT(end,1), X_UT(end,2), 'o', 'MarkerSize',10);
plot(X_MC(end,1), X_MC(end,2), 'o', 'MarkerSize',10);
plot(EllipseLinCov(:,1), EllipseLinCov(:,2));
plot(EllipseUT(:,1), EllipseUT(:,2));
plot(EllipseMC(:,1), EllipseMC(:,2));
scatter(Y_samples(1,:,end), Y_samples(2,:,end), 10, 'b', 'filled', 'DisplayName', 'MC Propagated Samples');
xlabel('Position X [-]')
ylabel('Position Y [-]')
legend('LinCov Mean', 'UT Mean', 'MC Mean', 'LinCov Ellipse', 'UT Ellipse', 'MC Ellipse', 'MC samples');

% Plot of Time Evolution of 3*sqrt(max(lambda_i)) for each approach for the
% two sub-matrices Pr, Pv

% Preallocate arrays for maximum eigenvalues
maxEig_Pr_MC = zeros(1, length(tvec));
maxEig_Pr_LinCov = zeros(1, length(tvec));
maxEig_Pr_UT = zeros(1, length(tvec));

maxEig_Pv_MC = zeros(1, length(tvec));
maxEig_Pv_LinCov = zeros(1, length(tvec));
maxEig_Pv_UT = zeros(1, length(tvec));

% Calculate maximum eigenvalues for each time step
for t = 1:length(tvec)
    maxEig_Pr_MC(t) = 3*sqrt(max(eig(P_MC(1:2,1:2,t))));
    maxEig_Pr_LinCov(t) = 3 * sqrt(max(eig(P_lincov(1:2,1:2,t))));
    maxEig_Pr_UT(t) = 3 * sqrt(max(eig(P_UT(1:2,1:2,t))));
    
    maxEig_Pv_MC(t) = 3 * sqrt(max(eig(P_MC(3:4,3:4,t))));
    maxEig_Pv_LinCov(t) = 3 * sqrt(max(eig(P_lincov(3:4,3:4,t))));
    maxEig_Pv_UT(t) = 3 * sqrt(max(eig(P_UT(3:4,3:4,t))));
end

% Plotting
figure;
% Plot for Position Covariance
subplot(1,2,1);
hold on;
plot(tvec, maxEig_Pr_LinCov, 'go-', 'DisplayName', 'LinCov');
plot(tvec, maxEig_Pr_UT, 'b*-', 'DisplayName', 'UT');
plot(tvec, maxEig_Pr_MC, 'rd-', 'DisplayName', 'MC');
hold off;
xlabel('Time [TU]');
ylabel('$3 \cdot \sqrt{\max(\lambda_i)}$ (Position)[-]', 'Interpreter', 'latex', 'FontWeight', 'bold');
title('Position Covariance');
grid on;
legend('Location', 'best');

% Plot for Velocity Covariance
subplot(1,2,2);
hold on;
plot(tvec, maxEig_Pv_LinCov, 'go-', 'DisplayName', 'LinCov');
plot(tvec, maxEig_Pv_UT, 'b*-', 'DisplayName', 'UT');
plot(tvec, maxEig_Pv_MC, 'rd-', 'DisplayName', 'MC');
xlabel('Time [TU]');
ylabel('$3 \cdot \sqrt{\max(\lambda_i)}$ (Velocity)[-]', 'Interpreter', 'latex', 'FontWeight', 'bold');
title('Velocity Covariance');
grid on;
legend('Location', 'best');

% Quantile-Quantile Plot for each component

figure
stateLabels = {'x', 'y', '$v_x$', '$v_y$'};
for i = 1:4
    subplot(2,2,i);
    qqplot(Y_samples(i,:,end));
    title(['QQ-Plot of ', stateLabels{i}, ' at Final Time'], 'Interpreter','latex');
    grid on;
end

%% FUNCTION
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',24);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx, PHIf, xf]  = propagatePCR4BP_STM(t0,x0,tf,parameters)

% propagatePCR4BP_STM is needed to propagate the state for the PCR4BP
%
% INPUTS: 
%   x0          : [4, 1] Initial State vector
%   t0          : [1, 1] Initial time
%   tf          : [1, 1] Final time
%   parameters  : [5, 1] [mu; om_em; m_s; rho; om_s]

%
% OUTPUTS:

%   xx         : [*, 4] State Vector
%   tt         : [*, 1] Integration time vector
%   PHIf       : [4, 4] Final State Transion Matrix (@ the end of the propagation)
%   xf         : [1, 4] Final State Vector (@ the end of the propagation)
% Initialize State Transition Matrix at t0

    Phi0 = eye(4);

    % Append to initial conditions the conditions for the STM
    x0Phi0 = [x0; Phi0(:)];
   
    % Perform integration
    optset = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode78(@(t,x) PCR4BP_STM(t, x, parameters), [t0 tf], x0Phi0, optset);
    
    PHIf = reshape(xx(end,5:end),4,4);
    xf = xx(end, 1:4);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [dxdt] = PCR4BP_STM(t, xx, parameters)
% PCRFBP propagates the Planar Circular Restricted 3-Body Problem with the
% STM
% 
% 
% INPUTS:
%   t               : [1, 1] scaled initial time
%   xx              : [4, 1] initial transfer state
%   parameters      : [5, 1] [mu; om_em; m_s; rho; om_s]
%
% OUTPUTS
%   dxdt            : [20, 1] derivative of the state [ vx, vy, ax, ay]
%

% Extract variables   
x = xx(1);
y = xx(2);
vx =xx(3);
vy = xx(4);

% Extract parameters

mu = parameters.mu;
ms = parameters.m_s;
rho = parameters.rho;
om_s = parameters.om_s;

% Put PHI in matrix form
Phi = reshape(xx(5:end),4,4);

% The accelerations are given by the equations of dynamics of PCRFBP
dUdx = x - (ms*cos(om_s*t))/rho^2 - (mu*(mu + x - 1))/((mu + x - 1)^2 + y^2)^(3/2) + ((2*mu + 2*x) * (mu - 1))/(2*((mu + x)^2 + y^2)^(3/2)) - (ms*(2*x - 2*rho*cos(om_s*t)))/(2*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2));
dUdy = y - (ms*sin(om_s*t))/rho^2 - (mu*y)/((mu + x - 1)^2 + y^2)^(3/2) - (ms*(2*y - 2*rho*sin(om_s*t)))/(2*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2)) + (y*(mu - 1))/((mu + x)^2 + y^2)^(3/2);

% Assemble the matrix A(t)=dfdx 4x4 matrix
dfdx =[0,  0,  1, 0;                                                                                                                                                                                                         
       0,  0,  0, 1;
      (mu - 1)/((mu + x)^2 + y^2)^(3/2) - mu/((mu + x - 1)^2 + y^2)^(3/2) - ms/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2) - (3*(mu + x)^2*(mu - 1))/((mu + x)^2 + y^2)^(5/2) + (3*ms*(x - rho*cos(om_s*t))^2)/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2) + (3*mu*(2*mu + 2*x - 2)*(mu + x - 1))/(2*((mu + x - 1)^2 + y^2)^(5/2)) + 1, (3*ms*(2*x - 2*rho*cos(om_s*t))*(2*y - 2*rho*sin(om_s*t)))/(4*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2)) + (3*mu*y*(mu + x - 1))/((mu + x - 1)^2 + y^2)^(5/2) - (3*y*(2*mu + 2*x)*(mu - 1))/(2*((mu + x)^2 + y^2)^(5/2)), 0, 2;
      (3*ms*(2*x - 2*rho*cos(om_s*t))*(2*y - 2*rho*sin(om_s*t)))/(4*((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2)) + (3*mu*y*(2*mu + 2*x - 2))/(2*((mu + x - 1)^2 + y^2)^(5/2)) - (3*y*(2*mu + 2*x)*(mu - 1))/(2*((mu + x)^2 + y^2)^(5/2)), (mu - 1)/((mu + x)^2 + y^2)^(3/2) - mu/((mu + x - 1)^2 + y^2)^(3/2) - ms/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(3/2) - (3*y^2*(mu - 1))/((mu + x)^2 + y^2)^(5/2) + (3*ms*(y - rho*sin(om_s*t))^2)/((x - rho*cos(om_s*t))^2 + (y - rho*sin(om_s*t))^2)^(5/2) + (3*mu*y^2)/((mu + x - 1)^2 + y^2)^(5/2) + 1, -2, 0];

% Compute the derivative of the STM
Phidot = dfdx*Phi;

% Assemble right-hand side
dxdt = zeros(20,1);

dxdt(1:2) = xx(3:4);
dxdt(3)   = dUdx + 2*vy;
dxdt(4)   = dUdy - 2*vx;
dxdt(5:end) = Phidot(:);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ellipseCoordinates = errorEllipse(meanState, P)
% This function constructs an ellipse based on the input covariance matrix.
% Inputs:
%   P : 2x2 covariance matrix (position covariance)
%   meanState: mean position
% Output:
%   ellipseCoordinates : Nx2 points defining the ellipse


% Compute eigenvectors and eigenvalues
[eigvec, eigval] = eig(P);

% Generate the ellipse
theta = linspace(0,2*pi,100);

% Scale the ellipse for 3-sigma
sigmaFactor = 3;

% Parametric ellipse shifted to mean position
ellipseCoordinates = sigmaFactor * eigvec * sqrt(eigval) * [cos(theta);sin(theta)] + meanState';
ellipseCoordinates = ellipseCoordinates';
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X_UT, P_UT] = UT(meanState, P0, t0, tvec, parameters)
        
    % Propagate the uncertainty with the Unscented Transform (UT) method
    n = 4;
    k = 0; beta = 2; alpha = 1;
    lambda = alpha^2 * (n+k) - n;

    % Compute the weights
    W0m = lambda / (n+lambda);
    W0c = W0m + (1 - alpha^2 + beta);
    Wim = 1 / (2 * (n+lambda));
    Wic = Wim;
    
    % Set the initial values of mean and covariance
    X_UT = zeros(5, n);
    X_UT(1,:) = meanState';
    P_UT = zeros(4, 4, 5);
    P_UT(:, :, 1) = P0;
    
    % Compute and propagate the sigma points
    x_p = sigma_points(n, meanState, P0);
    y_p = zeros(n, 2*n + 1, 5);
    y_p(:, :, 1) = x_p;
    for j = 1:size(x_p, 2)
        for i = 1:4
        [~, ~, ~, ypf]  = propagatePCR4BP_STM(t0,x_p(:,j),tvec(i+1),parameters);
        y_p(:, j, i+1) = ypf';
        end
    end
     
  % Compute the mean and covariance
  for i = 1:4
  Y_mean_UT = y_p(:, 1, i+1) * W0m + sum(y_p(:, 2:end, i+1) * Wim, 2);
  P_mean_UT = zeros(4, 4);
        for j = 1:2*n+1
            if j == 1
                P_mean_UT = P_mean_UT + W0c * (y_p(:, j, i+1) - Y_mean_UT) * (y_p(:, j, i+1) - Y_mean_UT)';
            else
                P_mean_UT = P_mean_UT + Wic * (y_p(:, j, i+1) - Y_mean_UT) * (y_p(:, j, i+1) - Y_mean_UT)';
            end
        end
        P_UT(:, :, i+1) = P_mean_UT;
        X_UT(i+1,:) = Y_mean_UT;
  end
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sigma_p = sigma_points(n, X0, P0)

    % Compute the sigma points from mean and covariance
    sigma_p = zeros(n, 2*n+1);
    sigma_p(:, 1) = X0;
    k = 0; alpha = 1;
    lambda = alpha^2 * (n+k) - n;
    Pn = sqrtm((n+lambda) * P0);
    
    for i = 1:n
        sigma_p(:, i+1) = X0 + Pn(:, i);
        sigma_p(:, i+1+n) = X0 - Pn(:, i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [X_MC, P_MC, Y_samples] = MC(xi, P0, t0, tvec, parameters)
    
    % Propagate the uncertainty with the Monte Carlo (MC) simulation
    X_MC = zeros(5, 4);
    P_MC = zeros(4, 4, 5);
    X_MC(1,:) = xi';
    P_MC(:,:,1) = P0;
    
    % Define the number of samples
    samples = 1000;

    % Generate the samples
    X_samples = mvnrnd(xi, P0, samples)';
    Y_samples = zeros(4, samples, 5);
    Y_samples(:,:,1) = X_samples;
    tMC = tvec(2:end);
    
    for k = 1:4
        % Initialize a temporary variable to hold results for this iteration
        Y_temp = zeros(size(X_samples, 1), samples);
        tSample = tMC(k);
        % Propagate the samples
        parfor i = 1:samples
            [~, ~, ~, xf] = propagatePCR4BP_STM(t0, X_samples(:, i), tSample, parameters);
            Y_temp(:, i) = xf';
        end
        % Assign the results to the appropriate slice of Y_samples
        Y_samples(:, :, k + 1) = Y_temp;
    end

    % Compute Mean and Covariance from the propagated samples
    for k = 1:5
        X_MC(k, :) = 1/samples * (sum(Y_samples(:, :, k), 2));
        P_MC(:, :, k) = 1/(samples-1) * ((Y_samples(:, :, k) - X_MC(k, :)') * ((Y_samples(:, :, k) - X_MC(k, :)')'));
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%