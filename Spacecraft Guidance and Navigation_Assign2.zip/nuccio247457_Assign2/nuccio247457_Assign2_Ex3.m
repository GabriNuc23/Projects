% Spacecraft Guidance and Navigation (2024/2025)
% Assignment # 2, Exercise 3
% Author: Gabriele Nuccio

clc
clearvars
close all

cspice_kclear();
applyDefaultSettings();
format long g;
cspice_furnsh('assignment02.tm');

addpath(genpath('sgp4\'))


% Inizialize data
arcsec2rad = pi/(180*3600);
typerun    = 'u';  % user-provided inputs to SGP4 Matlab function
opsmode    = 'a';  % afspc approach ('air force space command')
whichconst =  72;  % WGS72 constants (radius, gravitational parameter)

% Initial Mean State
r0 = [4307.844185282820,-1317.980749248651, 2109.210101634011];
v0 = [-0.110997301537882,-0.509392750828585, 0.815198807994189];
x0 = [r0, v0]';

% Initialize data in UTC
t0 = '2024-11-18T16:30:00.000';
tf = '2024-11-18T20:30:00.000';

% Epoch
et0=cspice_str2et(t0);
etf=cspice_str2et(tf);

% Define the measurement noise
sigma_m = 0.1; %[km]

% Define the initial covatiance
P0 = diag([10,1,1,0.001,0.001,0.001,0.00001,0.00001]);

% Define the lander features
lander.name = 'MOONLANDER';
lander.LAT = 78;
lander.LON = 15;
lander.ALT = 0; % [m]
lander.MinEl = 0; % [deg]
shift = 30; % [s]

%% 3.1

% Propagate in the Moon-Centred Inertial Reference Frace
muMoon = cspice_bodvrd('MOON', 'GM',1);
[tt, xx]  = propagateKepler(et0,x0,etf, shift, muMoon);

% Find the Moon Radius
rMoon = cspice_bodvrd('MOON','RADII',3);
rMoon = rMoon(1);
[X, Y, Z] = sphere(50);
% texture = imread('moon_texture.jpg');

figure()
hold on
plot3(xx(:,1), xx(:,2), xx(:,3));
plot3(xx(1,1), xx(1,2), xx(1,3), 'Marker','o','MarkerSize',6);
plot3(xx(end,1), xx(end,2), xx(end,3), 'Marker','o','MarkerSize',6);
hSurface = surf(X*rMoon, Y*rMoon, Z*rMoon, 'EdgeColor','none');
colormap('gray'); 
set(gca, 'CLim', [0, 255]); 
surface = findobj(gca, 'Type', 'Surface'); 
% set(hSurface, 'FaceColor', 'texturemap', 'CData', texture); 
legend('Trajectory', 'Initial Position', 'Final Position', 'Moon')
axis equal;
xlabel('Position X [km]');
ylabel('Position Y [km]');
zlabel('Position Z [km]');

lander.R = rMoon + lander.ALT;

% Compute the measurements to check visibility
[Az, El, range, et_vec, xMoonlander] = landerPointing(shift, et0, etf, xx, lander);

% Visibility window
visibility = El > lander.MinEl;


% Verify that all measurements are within the visibility window
if any(~visibility)
    error('condition not met')
end

El_real = El(visibility);
Az_real = Az(visibility);
range_Real = range(visibility);
et_vecReal = et_vec(visibility);

figure()
plot(et_vecReal/cspice_spd, El_real, 'DisplayName', 'Elevation of the Satellite');
yline(lander.MinEl, 'DisplayName', 'Minimum Elevation of Lander', 'Color','k', 'LineStyle','--', 'LineWidth',2)
ylabel('Elevation [deg]','Color','k') 
xlabel('Epoch [MJD2000]')
legend('Location', 'best');

%% 3.2

% Simulate the measurements
[AzKernel, ElKernerl, rangeKernel, et_vecKernel, long, lat] = landerPointingKernel(shift, et0, etf, xx, lander);

% Add the measurements noise
posIdeal = xx(:,1:3);
posReal = mvnrnd(posIdeal, diag([sigma_m^2, sigma_m^2, sigma_m^2]));
rangeReal = mvnrnd(rangeKernel', sigma_m^2);

% Plot the range over time
figure()
hold on
plot(et_vecKernel/cspice_spd, rangeKernel, 'DisplayName','Range [km]');
plot(et_vecKernel/cspice_spd, xx(:,1), 'DisplayName','X Coordinate [km]');
plot(et_vecKernel/cspice_spd, xx(:,2), 'DisplayName','Y Coordinate [km]');
plot(et_vecKernel/cspice_spd, xx(:,3), 'DisplayName','Z Coordinate [km]');
ylabel('Measuremnts [km]')
xlabel('Epoch [MJD2000]')
legend;

% Plot the error with the 3sigma
figure()
plot(et_vecKernel/cspice_spd, rangeReal - rangeKernel');
hold on
yline(3*sigma_m, 'LineWidth',1, 'Color','r')
yline(-3*sigma_m, 'LineWidth',1, 'Color','b')
legend('Range [km', '3$\sigma$', '-3$\sigma$')
xlabel('Epoch [MJD2000]')
ylabel('Noise Level [km]') 

figure()
plot(et_vecKernel/cspice_spd, posReal(:,1) - xx(:,1))
hold on
plot(et_vecKernel/cspice_spd, posReal(:,2) - xx(:,2))
plot(et_vecKernel/cspice_spd, posReal(:,3) - xx(:,3))
yline(3*sigma_m, 'LineWidth',1, 'Color','r')
yline(-3*sigma_m, 'LineWidth',1, 'Color','b')
legend('Position X [km]', 'Position Y [km]', 'Position Z [km]', '3$\sigma$', '-3$\sigma$')
xlabel('Epoch [MJD2000]')
ylabel('Noise Level [km]') 
%% 3.3

% Estimate the absolute state of the lunar orbiter

% Define mean and covariance
P0filter = P0(1:6, 1:6);
x0Perturb = mvnrnd(x0, P0filter)';

% Define the noise matrix
Rk = diag([sigma_m^2, sigma_m^2, sigma_m^2]);
tic
% Use the Unscented Kalman Filter (UKF)
[X_UKF, P_UKF] = UKF(x0Perturb, P0filter, et0, etf, shift, muMoon, Rk, posReal);
toc
% Compute Position and Velocity errors and standard deviations.
errPos = zeros(1,length(et_vec));
errVel = zeros(1,length(et_vec));
stdPos = zeros(1,length(et_vec));
stdVel = zeros(1,length(et_vec));
for i = 1:length(et_vec)
    errPos(i) = sqrt((xx(i,1) - X_UKF(1,i))^2 + (xx(i,2) - X_UKF(2,i))^2 +(xx(i,3) - X_UKF(3,i))^2 );
    errVel(i) = sqrt((xx(i,4) - X_UKF(4,i))^2 + (xx(i,5) - X_UKF(5,i))^2 +(xx(i,6) - X_UKF(6,i))^2 );
    stdPos(i) = 3 * sqrt(trace(P_UKF(1:3,1:3, i)));
    stdVel(i) = 3 * sqrt(trace(P_UKF(4:6,4:6, i)));
end

% Plot the results in subplots
figure('Name', 'Errors', 'NumberTitle', 'off', 'Color', 'w');

% Subplot 1: Position Error
subplot(1, 2, 1); % 1 row, 2 columns, 1st subplot
semilogy(et_vec/cspice_spd, errPos, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
semilogy(et_vec/cspice_spd, stdPos, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Position Error [km]', 'Interpreter', 'latex');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
title('Position Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Subplot 2: Velocity Error
subplot(1, 2, 2); % 1 row, 2 columns, 2nd subplot
semilogy(et_vec/cspice_spd, errVel, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
semilogy(et_vec/cspice_spd, stdVel, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Velocity Error [km/s]', 'Interpreter', 'latex');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
title('Velocity Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;


%%  3.4
% Define the mean and the covariance
P0_lander = P0;

% Latitude and longitude in radians
xNew = [x0; lander.LAT * cspice_rpd; lander.LON * cspice_rpd];
x0_lander = mvnrnd(xNew, P0_lander)';
% Define the noise matrix
Rk2 = diag([sigma_m^2, sigma_m^2, sigma_m^2, sigma_m^2]);

% Use the Unscented Kalman Filter (UKF)
[X_UKF_2, P_UKF_2] = UKFwithLatAndLong(x0_lander, P0_lander, et0, etf, shift, muMoon, Rk2, posReal, rangeReal, lander);

% Compute Position and Velocity errors and standard deviations
errPos2 = zeros(1,length(et_vec));
errVel2 = zeros(1,length(et_vec));
stdPos2 = zeros(1,length(et_vec));
stdVel2 = zeros(1,length(et_vec));
stdLat = zeros(1, length(et_vec));
stdLong = zeros(1, length(et_vec));
errLat = zeros(1, length(et_vec));
errLong = zeros(1, length(et_vec));
for i = 1:length(et_vec)
    errPos2(i) = sqrt((xx(i,1) - X_UKF_2(1,i))^2 + (xx(i,2) - X_UKF_2(2,i))^2 +(xx(i,3) - X_UKF_2(3,i))^2 );
    errVel2(i) = sqrt((xx(i,4) - X_UKF_2(4,i))^2 + (xx(i,5) - X_UKF_2(5,i))^2 +(xx(i,6) - X_UKF_2(6,i))^2 );
    stdPos2(i) = 3 * sqrt(trace(P_UKF_2(1:3,1:3, i)));
    stdVel2(i) = 3 * sqrt(trace(P_UKF_2(4:6,4:6, i)));
    stdLat(i) = 3 * sqrt(P_UKF_2(7,7,i)) * cspice_dpr;
    stdLong(i) = 3 * sqrt(P_UKF_2(8,8,i)) * cspice_dpr;
    errLat(i) = abs(lat(i)*cspice_dpr - X_UKF_2(7,i)*cspice_dpr);
    errLong(i) = abs(long(i)*cspice_dpr - X_UKF_2(8,i)*cspice_dpr);
end

% Creazione di un'unica figura con due subplot
figure('Name', 'Errors', 'NumberTitle', 'off', 'Color', 'w');

% Subplot 1: Position Error
subplot(1, 2, 1); % 1 riga, 2 colonne, primo subplot
semilogy(et_vec/cspice_spd, errPos2, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
semilogy(et_vec/cspice_spd, stdPos2, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Position Error [km]', 'Interpreter', 'latex');
title('Position Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Subplot 2: Velocity Error
subplot(1, 2, 2); % 1 riga, 2 colonne, secondo subplot
semilogy(et_vec/cspice_spd, errVel2, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
semilogy(et_vec/cspice_spd, stdVel2, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Velocity Error [km/s]', 'Interpreter', 'latex');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
title('Velocity Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;



% Creazione di un'unica figura con due subplot
figure('Name', 'Latitude and Longitude Errors', 'NumberTitle', 'off', 'Color', 'w');

% Subplot 1: Latitude Error
subplot(1, 2, 1); % 1 riga, 2 colonne, primo subplot
plot(et_vec / cspice_spd, errLat, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
plot(et_vec / cspice_spd, stdLat, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Latitude Error [deg]', 'Interpreter', 'latex');
title('Latitude Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;

% Subplot 2: Longitude Error
subplot(1, 2, 2); % 1 riga, 2 colonne, secondo subplot
plot(et_vec / cspice_spd, errLong, 'b-', 'LineWidth', 1.8, 'DisplayName', 'Error'); hold on;
plot(et_vec / cspice_spd, stdLong, 'r--', 'LineWidth', 1.5, 'DisplayName', '3$\sigma$');
xlim([et_vec(1)/cspice_spd, et_vec(end)/cspice_spd])
xlabel('Epoch [MJD2000]', 'Interpreter', 'latex');
ylabel('Longitude Error [deg]', 'Interpreter', 'latex');
title('Longitude Error and $3\sigma$', 'Interpreter', 'latex');
legend('Location', 'best', 'Interpreter', 'latex');
grid on;




%% FUNCTION
function applyDefaultSettings()
    set(groot, 'defaultTextInterpreter', 'latex')
    set(groot,'defaultAxesXMinorGrid','on','defaultAxesXMinorGridMode','manual');
    set(groot,'defaultAxesYMinorGrid','on','defaultAxesYMinorGridMode','manual');
    set(groot, 'defaultLegendLocation', 'northeast')
    set(groot, 'defaultLegendInterpreter', 'latex')
    set(groot, 'defaultAxesTickLabelInterpreter', 'latex')
    set(groot, 'defaultAxesFontWeight', 'bold')
    set(groot, 'defaultFigurePosition', [470, 360, 900, 530]-100)
    set(groot, 'defaultFigureColormap', turbo(256));
    set(groot, 'defaultAxesFontName', 'Palatino Linotype', 'defaultTextFontName', 'Palatino Linotype');
    set(groot, 'defaultSurfaceEdgeAlpha', 0.3);
    set(groot, 'defaultLineLineWidth', 2);
    set(groot, 'defaultFigureColor', [1; 1; 1]);
    set(groot, 'defaultAxesColor', 'none');
    set(groot,'DefaultAxesYLimitMethod',"padded")
    set(groot, 'defaultAxesFontSize',24);
    set(groot, 'defaultAxesLabelFontSizeMultiplier', 1.2)
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [tt, xx]  = propagateKepler(t0,x0,tf, shift, mu)
% Propagate the satellite's state assuming Keplerian motion
% for a given station and its measurement frequency.
%
% INPUT:
%   t0        : [1, 1] Initial epoch in seconds (ET)
%   tf        : [1, 1] Final epoch in seconds (ET)
%   x0        : [6, 1] Initial state vector in ECI frame (km)
%   mu        : [1, 1] Gravitational parameter of the central body (km^3/s^2)
%   shift     : [1, 1] Measurement time of the given station (seconds)
%
% OUTPUT:
%   tt      : [N, 1] Time vector of propagation (s)
%   xx      : [N, 6] Propagated state matrix where each row contains:
%                        [x, y, z, vx, vy, vz]
%
    npoints = round((tf-t0)/shift)+1;
    tvec = linspace(t0, tf, npoints);
    % Perform integration
    options = odeset('reltol', 1e-12, 'abstol', 1e-12);
    [tt, xx] = ode113(@(t,x)Kepler(t,x,mu), tvec, x0, options);

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function dxdt = Kepler(~, xx, mu)
% Computes the time derivative of the state vector for Keplerian
% motion. 
%
% INPUT:
%   et          : [1, 1] Ephemeris time (TDB) in seconds.
%   xx          : [6, 1] State vector [x, y, z, vx, vy, vz] in ECI where:
%                 x, y, z   - Position components in Cartesian coordinates (km)
%                 vx, vy, vz - Velocity components in Cartesian coordinates (km/s)
%   mu     : [1, 1] Standard gravitational parameter of the central body (km^3/s^2)

%
% OUTPUT:
%   dxdt        : [6, 1] Time derivative of the state vector, representing:
%                 dxdt = [vx, vy, vz, ax, ay, az], where:
%                 ax, ay, az - Acceleration components due to gravity (km/s^2)
    r = norm(xx(1:3));

    dxdt = zeros(6,1);
    dxdt(1:3) = xx(4:6);
    dxdt(4:6) = -mu/r^3 * xx(1:3);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Az, El, range, et_vec, xMoonlander] = landerPointing(shift, et0, etf, xx, lander)

%       Calculate the range, azimuth, and elevation of a satellite relative
%       to the Moonlander estimating its state with the latitudinal coordinates.

% INPUTS:
%   shift       : [1, 1] time step [s]
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   xx          : [N, 6] Propagated state vector of the satellite in ECI frame 
%   lander      : [string] Characteristics of the Moonlander

% OUTPUTS:
%   range       : [N, 1] Range between satellite and station (km)
%   Az          : [N, 1] Azimuth angle (degrees)
%   El          : [N, 1] Elevation angle (degrees)
%   et_vec      : [N, 1] time interval considered
%   xMoonlander : [6, 1] Moonlander State vector founded with latrec

npoints = round((etf-et0)/shift)+1;
et_vec = linspace(et0, etf, npoints);

Az = zeros(1, npoints);
El = zeros(1, npoints);
range = zeros(1, npoints);


landerPosIAUmoon = cspice_latrec(lander.R, lander.LON * cspice_rpd, lander.LAT * cspice_rpd);
landerVelIAUmoon = zeros(3,1);
landerStateIAUmoon = [landerPosIAUmoon; landerVelIAUmoon];

topoFrame = [lander.name, '_TOPO'];

  for i = 1 : length(et_vec)

    ROTMCMF2MCI = cspice_sxform('IAU_MOON', 'J2000', et_vec(i));
   
    xMoonlander = ROTMCMF2MCI * landerStateIAUmoon;

    % Compute satellite - lander vector in ECI
    rv_sat_eci = xx(i,:)' - xMoonlander;

    % Transformation from ECI to topocentric frame
    ROTMCI2TOPO = cspice_sxform('J2000', topoFrame, et_vec(i));

    rv_sat_topo = ROTMCI2TOPO * rv_sat_eci;
 
    % Compute range, azimuth and elevation using cspice_xfmsta
    rll_sat = cspice_xfmsta(rv_sat_topo,'RECTANGULAR','LATITUDINAL','MOON');
    
    Az(i) = rll_sat(2)*cspice_dpr;   % [deg]
    El(i) = rll_sat(3)*cspice_dpr;   % [deg]
    range(i) = rll_sat(1); % [km]
  end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Az, El, range, et_vec, long, lat] = landerPointingKernel(shift, et0, etf, xx, lander)

%       Calculate the range, azimuth, and elevation of a satellite relative
%       to the Moonlander deriving its state from kernels.

% INPUTS:
%   shift       : [1, 1] time step [s]
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   xx          : [N, 6] Propagated state vector of the satellite in ECI frame 
%   lander      : [string] Characteristics of the Moonlander

% OUTPUTS:
%   range       : [N, 1] Range between satellite and station (km)
%   Az          : [N, 1] Azimuth angle (degrees)
%   El          : [N, 1] Elevation angle (degrees)
%   et_vec      : [N, 1] time interval considered

npoints = round((etf-et0)/shift)+1;
et_vec = linspace(et0, etf, npoints);

Az = zeros(1, npoints);
El = zeros(1, npoints);
range = zeros(1, npoints);
topoFrame = [lander.name, '_TOPO'];


  for i = 1 : length(et_vec)
    % Compute satellite - lander vector in ECI
  
    xMoonlander = cspice_spkezr(lander.name, et_vec(i), 'J2000', 'NONE', 'MOON');
    rv_sat_eci = xx(i,:)' - xMoonlander;

    % ROTMCMF2MCI = cspice_sxform('IAU_MOON', 'J2000', et_vec(i));
    ROTMCI2TOPO = cspice_sxform('J2000', topoFrame, et_vec(i));

    rv_sat_topo = ROTMCI2TOPO *  rv_sat_eci;
 
    % Compute range, azimuth and elevation using cspice_xfmsta
    rll_sat = cspice_xfmsta(rv_sat_topo,'RECTANGULAR','LATITUDINAL','MOON');
    

    Az(i) = rll_sat(2)*cspice_dpr;   % [deg]
    El(i) = rll_sat(3)*cspice_dpr;   % [deg]
    range(i) = rll_sat(1); % [km]
  end
xMoonlanderIau =   cspice_spkezr(lander.name, et_vec, 'IAU_MOON', 'NONE', 'MOON');
[~, long, lat] = cspice_reclat(xMoonlanderIau(1:3,:));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function[X_UKF, P_UKF] = UKF(x0, P0, et0, etf, shift, mu, Rk, posReal)

%-----------------------Unscented Kalman Filter (UKF)---------------------%
%       Calculate the range, azimuth, and elevation of a satellite relative
%       to the Moonlander deriving its state from kernels.

% INPUTS:
%   shift       : [1, 1] time step [s]
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   x0          : [6, 1] Initial State vector of the orbiter in MCI frame 
%   P0          : [6, 6] Initial Covariance matrix of the orbiter in MCI
%   frame.
%   Rk          : [3, 3] Noise Matrix
%   posReal     : [N, 3] Real Position vector. 

% OUTPUTS:
%   X_UKF       : [6, N] Lunar Orbiter absolute state estimated with UKF
%   P_UKF       : [6, 6, N] Lunar Orbiter covariance matrix estimated with UKF

    npoints = round((etf-et0)/shift)+1;
    et_vec = linspace(et0, etf, npoints);

    n = 6;
    
    % For UT
    alpha = 0.01; beta = 2; k = 0;
   
    % Compute the weights
    W0m = 1 - n/(alpha^2 * (n+k));
    W0c = (2-alpha^2 + beta) - n/(alpha^2 * (n+k));
    Wim = 1 / (2 * alpha^2 * (n+k));
    Wic = Wim;
 
    % Define initial Mean and Covariance
    X_UKF = zeros(n, length(et_vec));
    P_UKF = zeros(n, n, length(et_vec));
    P_UKF(:,:,1)= P0;
    X_UKF(:,1) = x0;
    x_k = x0;
    P_k = P0;
   
    y_p = zeros(n, 2*n+1);
    
   for k = 1:length(et_vec)-1
    % Compute sigma points
    x_p = sigma_points(n, x_k, P_k);
     
    for j = 1:2*n+1
        % Propagate sigma points
        [~, yyp]  = propagateKepler(et_vec(k), x_p(1:6,j), et_vec(k+1), shift, mu);
        y_p(:,j) = yyp(end,:)'; 
    end

  % Apply the measurement function
  gamma_p = y_p(1:3,:);

  % Apply UT to compute Mean and Covariance
  x_k_minus = y_p(:, 1) * W0m + Wim * sum(y_p(:, 2:end), 2); 
  P_k_minus = W0c * (y_p(:, 1) - x_k_minus) * (y_p(:, 1) - x_k_minus)';
  for j = 2:2*n+1
  P_k_minus = P_k_minus  +  Wic * (y_p(:, j) - x_k_minus) * (y_p(:, j) - x_k_minus)';
  end
  
  y_mean_UT = gamma_p(:, 1) * W0m + Wim * sum(gamma_p(:, 2:end), 2);
  
  P_eek = W0c * (gamma_p(:, 1) - y_mean_UT) * (gamma_p(:, 1) - y_mean_UT)';
  P_xyk = W0c * (y_p(:, 1) - x_k_minus) * (gamma_p(:, 1) - y_mean_UT)';
  for j = 2:2*n+1
  P_eek = P_eek +  Wic * (gamma_p(:, j) - y_mean_UT) * (gamma_p(:, j) - y_mean_UT)';
  P_xyk = P_xyk + Wic * (y_p(:, j) - x_k_minus) * (gamma_p(:, j) - y_mean_UT)';
  end
  P_eek = P_eek + Rk;

  % Update State
  K_k = P_xyk/P_eek;
  x_k = x_k_minus + K_k * (posReal(k+1,:)'  - y_mean_UT);
  P_k = P_k_minus - K_k * P_eek * K_k';

  X_UKF(:,k+1) = x_k';
  P_UKF(:,:,k+1) = P_k;
   end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function sigma_p = sigma_points(n, X0, P0)
% Compute the sigma points given the state dimension, initial state, and initial covariance.
% 
% Inputs:
%   n   - Dimension of the state vector.
%   X0  - Initial state vector (nx1 vector).
%   P0  - Initial covariance matrix (nxn matrix).
% 
% Output:
%   sigma_p - Matrix of sigma points (nx(2*n+1) matrix), where each column is a sigma point.

    sigma_p = zeros(n, 2*n+1);
    sigma_p(:, 1) = X0;
    k = 0;
    alpha = 0.01;
    lambda = alpha^2 * (n+k) - n;
    Pn = sqrtm((n+lambda) * P0);
    
    for i = 1:n
        sigma_p(:, i+1) = X0 + Pn(:, i);
        sigma_p(:, i+1+n) = X0 - Pn(:, i);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function[X_UKF, P_UKF] = UKFwithLatAndLong(x0, P0, et0, etf, shift, mu, Rk, posReal, rangeReal, lander)
%-----------------------Unscented Kalman Filter (UKF)---------------------%
%       Calculate the range, azimuth, and elevation of a satellite relative
%       to the Moonlander deriving its state and its latitude and longitude.

% INPUTS:
%   shift       : [1, 1] time step [s]
%   et0         : [1, 1] Initial Epoch time in seconds (UTC)
%   etf         : [1, 1] Final Epoch time in seconds (UTC)
%   x0          : [8, 1] Initial State vector of the orbiter in MCI frame 
%   P0          : [8, 8] Initial Covariance matrix of the orbiter in MCI
%   frame.
%   Rk          : [3, 3] Noise Matrix
%   posReal     : [N, 3] Real Position vector. 
%   rangeReal   : [N, 1] Real range.
%   lander      : [string] lander features.

% OUTPUTS:
%   X_UKF       : [8, N] Lunar Orbiter absolute state estimated with UKF
%   P_UKF       : [8, 8, N] Lunar Orbiter covariance matrix estimated with UKF

    npoints = round((etf-et0)/shift)+1;
    et_vec = linspace(et0, etf, npoints);

    n = 8;
    
    % For UT
    alpha = 0.01; beta = 2; k = 0;
    
    % Compute the weights
    W0m = 1 - n/(alpha^2 * (n+k));
    W0c = (2-alpha^2 + beta) - n/(alpha^2 * (n+k));
    Wim = 1 / (2 * alpha^2 * (n+k));
    Wic = Wim;
    
    % Define initial Mean and Covariance
    X_UKF = zeros(n, length(et_vec));
    P_UKF = zeros(n, n, length(et_vec));
    P_UKF(:,:,1)= P0;
    X_UKF(:,1) = x0;
    x_k = x0;
    P_k = P0;
   
    y_p = zeros(n, 2*n+1);
    range_p = zeros(1, 2*n+1);
   for k = 1:length(et_vec)-1
    % Compute sigma points
    x_p = sigma_points(n, x_k, P_k);
    y_p(7:8, :) = x_p(7:8, :);   
    for j = 1:2*n+1
        % Propagate sigma points
        [~, yyp]  = propagateKepler(et_vec(k), x_p(1:6,j), et_vec(k+1), shift, mu);
        y_p(1:6,j) = yyp(end,:)';
        lander.LAT = y_p(7,j) * cspice_dpr;
        lander.LON = y_p(8,j) * cspice_dpr;
        % Compute the range from the propagated sigma points
        range_p(j) = computeRange(et_vec(k+1), y_p(1:6,j), lander);
    end
  
  % Apply the measurement function
  gamma_p = [y_p(1:3,:); range_p];

  % Apply UT to compute Mean and Covariance
  x_k_minus = y_p(:, 1) * W0m + Wim * sum(y_p(:, 2:end), 2);
  
  P_k_minus = W0c * (y_p(:, 1) - x_k_minus) * (y_p(:, 1) - x_k_minus)';
  for j = 2:2*n+1
  P_k_minus = P_k_minus  +  Wic * (y_p(:, j) - x_k_minus) * (y_p(:, j) - x_k_minus)';
  end
  
  y_mean_UT = gamma_p(:, 1) * W0m + Wim * sum(gamma_p(:, 2:end), 2);
  
  P_eek = W0c * (gamma_p(:, 1) - y_mean_UT) * (gamma_p(:, 1) - y_mean_UT)';
  P_xyk = W0c * (y_p(:, 1) - x_k_minus) * (gamma_p(:, 1) - y_mean_UT)';
  for j = 2:2*n+1
  P_eek = P_eek +  Wic * (gamma_p(:, j) - y_mean_UT) * (gamma_p(:, j) - y_mean_UT)';
  P_xyk = P_xyk + Wic * (y_p(:, j) - x_k_minus) * (gamma_p(:, j) - y_mean_UT)';
  end
  P_eek = P_eek + Rk;

  % Update State
  K_k = P_xyk/P_eek;
  x_k = x_k_minus + K_k * ([posReal(k+1,:)'; rangeReal(k+1)] - y_mean_UT);
  P_k = P_k_minus - K_k * P_eek * K_k';

  X_UKF(:,k+1) = x_k';
  P_UKF(:,:,k+1) = P_k;
  end
  
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [range] = computeRange(et, sigmaPropagated, lander)
% Compute the relative range between the orbiter and the lander given the state, 
% the lander features, and the epoch time in seconds.
%
% Inputs:
%   et               - Epoch time in seconds (scalar).
%   sigmaPropagated  - Orbiter's state vector in ECI coordinates (6x1 vector).
%   lander           - Structure containing the lander's parameters:
%                      - lander.R   : Radius from the moon center to the lander (km).
%                      - lander.LON : Longitude of the lander (degrees).
%                      - lander.LAT : Latitude of the lander (degrees).
%                      - lander.name: Name of the lander for the topocentric frame.
%
% Output:
%   range - The relative range between the orbiter and the lander in kilometers (scalar).

landerPosIAUmoon = cspice_latrec(lander.R, lander.LON * cspice_rpd, lander.LAT * cspice_rpd);
landerVelIAUmoon = zeros(3,1);
landerStateIAUmoon = [landerPosIAUmoon; landerVelIAUmoon];

topoFrame = [lander.name, '_TOPO'];


    ROTMCEF2MCI = cspice_sxform('IAU_MOON', 'J2000', et);
   
    xMoonlander = ROTMCEF2MCI * landerStateIAUmoon;

    % Compute satellite - lander vector in ECI
    rv_sat_eci = sigmaPropagated - xMoonlander;

    % Transformation from ECI to topocentric frame
    ROTMCI2TOPO = cspice_sxform('J2000', topoFrame, et);

    rv_sat_topo = ROTMCI2TOPO * rv_sat_eci;
 
    % Compute range using cspice_xfmsta
    rll_sat = cspice_xfmsta(rv_sat_topo,'RECTANGULAR','LATITUDINAL','MOON');
    
    range = rll_sat(1); % [km]

end